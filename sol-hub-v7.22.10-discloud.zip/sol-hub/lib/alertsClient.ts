export type AlertMode="SMART"|"CUSTOM";
export type SolAlert={
 id:string;watchlistId:string;itemId:string;name:string;route:string;mode:AlertMode;
 minScore?:number;minRoi?:number;maxBuyPrice?:number;minEntryAdvantage?:number;
 createdAt:string;enabled:boolean;
};
export type AlertNotification={
 id:string;alertId:string;watchlistId:string;itemId:string;name:string;route:string;
 titleEn:string;titlePt:string;detailEn:string;detailPt:string;triggeredAt:string;read:boolean;
 score?:number;roi?:number;buyPrice?:number;
};
export const ALERTS_KEY="sol-hub-alerts-v1";
export const ALERT_NOTIFICATIONS_KEY="sol-hub-alert-notifications-v1";
export const ALERTS_EVENT="sol-hub-alerts-changed";
const read=<T,>(key:string,fallback:T):T=>{if(typeof window==="undefined")return fallback;try{const x=JSON.parse(localStorage.getItem(key)??"");return x??fallback}catch{return fallback}};
const write=(key:string,value:unknown)=>{if(typeof window==="undefined")return;localStorage.setItem(key,JSON.stringify(value));window.dispatchEvent(new CustomEvent(ALERTS_EVENT))};
export const loadAlerts=()=>{const x=read<SolAlert[]>(ALERTS_KEY,[]);return Array.isArray(x)?x:[]};
export const loadAlertNotifications=()=>{const x=read<AlertNotification[]>(ALERT_NOTIFICATIONS_KEY,[]);return Array.isArray(x)?x:[]};
export function saveAlert(input:Omit<SolAlert,"id"|"createdAt"|"enabled">){
 const rows=loadAlerts().filter(x=>x.watchlistId!==input.watchlistId);
 const row:SolAlert={...input,id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,createdAt:new Date().toISOString(),enabled:true};
 write(ALERTS_KEY,[row,...rows]);return row;
}
export function removeAlert(id:string){const next=loadAlerts().filter(x=>x.id!==id);write(ALERTS_KEY,next);return next}
export function toggleAlert(id:string){const next=loadAlerts().map(x=>x.id===id?{...x,enabled:!x.enabled}:x);write(ALERTS_KEY,next);return next}
export function markNotificationRead(id:string){write(ALERT_NOTIFICATIONS_KEY,loadAlertNotifications().map(x=>x.id===id?{...x,read:true}:x))}
export function markAllNotificationsRead(){write(ALERT_NOTIFICATIONS_KEY,loadAlertNotifications().map(x=>({...x,read:true})))}
export function clearNotifications(){write(ALERT_NOTIFICATIONS_KEY,[])}
export function evaluateAlerts(alerts:SolAlert[],watchlist:Record<string,{itemId:string;name:string;route:string;intelligenceScore?:number;entryAdvantagePct?:number}>,quotes:Record<string,{buyPrice?:number|null;currentRoi?:number|null;currentIntelligenceScore?:number|null}>){
 const existing=loadAlertNotifications(),created:AlertNotification[]=[];
 for(const a of alerts.filter(x=>x.enabled)){
  const w=watchlist[a.watchlistId],q=quotes[a.watchlistId];if(!w||!q)continue;
  const score=q.currentIntelligenceScore??w.intelligenceScore,roi=q.currentRoi,buy=q.buyPrice;
  let hit=false,whyEn="",whyPt="";
  if(a.mode==="SMART"){
   hit=(score??0)>=85&&(roi??0)>=12&&(w.entryAdvantagePct??0)>=0;
   whyEn=`SOL Score ${score??"—"} • Return ${roi!=null?roi.toFixed(1)+"%":"—"} • entry quality is healthy.`;
   whyPt=`SOL Score ${score??"—"} • Rentabilidade ${roi!=null?roi.toFixed(1)+"%":"—"} • qualidade de entrada saudável.`;
  }else{
   const tests=[a.minScore==null||(score??-Infinity)>=a.minScore,a.minRoi==null||(roi??-Infinity)>=a.minRoi,a.maxBuyPrice==null||(buy??Infinity)<=a.maxBuyPrice,a.minEntryAdvantage==null||(w.entryAdvantagePct??-Infinity)>=a.minEntryAdvantage];
   hit=tests.every(Boolean);
   whyEn=`Your custom targets are now satisfied: Score ${score??"—"}, Return ${roi!=null?roi.toFixed(1)+"%":"—"}, Buy ${buy??"—"}.`;
   whyPt=`Os seus alvos personalizados foram atingidos: Score ${score??"—"}, Rentabilidade ${roi!=null?roi.toFixed(1)+"%":"—"}, Compra ${buy??"—"}.`;
  }
  if(!hit)continue;
  const recently=existing.some(n=>n.alertId===a.id&&Date.now()-new Date(n.triggeredAt).getTime()<6*60*60*1000);if(recently)continue;
  created.push({id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,alertId:a.id,watchlistId:a.watchlistId,itemId:a.itemId,name:a.name,route:a.route,titleEn:a.mode==="SMART"?"Strong opportunity detected":"Alert target reached",titlePt:a.mode==="SMART"?"Oportunidade forte detectada":"Alvo do alerta atingido",detailEn:whyEn,detailPt:whyPt,triggeredAt:new Date().toISOString(),read:false,score:score??undefined,roi:roi??undefined,buyPrice:buy??undefined});
 }
 if(created.length)write(ALERT_NOTIFICATIONS_KEY,[...created,...existing].slice(0,100));
 return created;
}
