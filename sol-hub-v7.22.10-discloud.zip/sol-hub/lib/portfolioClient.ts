export type PortfolioType="FLIP"|"CRAFT"|"REFINE";
export type PortfolioStatus="OPEN"|"CLOSED";
export type PortfolioEntry={
 id:string;type:PortfolioType;itemId:string;name:string;route?:string;qty:number;
 investment:number;expectedProfit:number;expectedRoi:number;focusUsed:number;
 createdAt:string;status:PortfolioStatus;closedAt?:string;realRevenue?:number;
 realProfit?:number;realRoi?:number;notes?:string;solScore?:number;source?:string;
};
export const PORTFOLIO_KEY="notag_portfolio_v1";
export const PORTFOLIO_EVENT="sol-hub-portfolio-changed";
export function loadPortfolio():PortfolioEntry[]{
 if(typeof window==="undefined")return[];
 try{const x=JSON.parse(localStorage.getItem(PORTFOLIO_KEY)??"[]");return Array.isArray(x)?x:[]}catch{return[]}
}
export function savePortfolio(rows:PortfolioEntry[]){
 if(typeof window!=="undefined"){
  localStorage.setItem(PORTFOLIO_KEY,JSON.stringify(rows));
  window.dispatchEvent(new CustomEvent(PORTFOLIO_EVENT));
 }
}
export function addPortfolio(input:Omit<PortfolioEntry,"id"|"createdAt"|"status">){
 const rows=loadPortfolio();
 const row:PortfolioEntry={...input,id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,createdAt:new Date().toISOString(),status:"OPEN"};
 savePortfolio([row,...rows]);return row;
}
export function closePortfolio(id:string,realRevenue:number,notes=""){
 const rows=loadPortfolio().map(x=>{
  if(x.id!==id)return x;
  const realProfit=realRevenue-x.investment;
  return {...x,status:"CLOSED" as const,closedAt:new Date().toISOString(),realRevenue,realProfit,realRoi:x.investment?realProfit/x.investment*100:0,notes};
 });
 savePortfolio(rows);return rows;
}
export function removePortfolio(id:string){const rows=loadPortfolio().filter(x=>x.id!==id);savePortfolio(rows);return rows}
