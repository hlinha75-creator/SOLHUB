"use client";

import {useEffect,useState} from "react";

export type SolHubLanguage="pt-BR"|"en";
export type SaleMode="sell_order"|"instant_sell";

export type SolHubSettings={
  premium:boolean;
  focus:number;
  stationFee:number;
  marketCity:string;
  craftCity:string;
  craftSellCity:string;
  refineCity:string;
  refineSellCity:string;
  saleMode:SaleMode;
  maxAgeHours:number;
  language:SolHubLanguage;
};

export const SETTINGS_KEY="sol-hub-settings-v1";

export const DEFAULT_SETTINGS:SolHubSettings={
  premium:true,
  focus:10000,
  stationFee:0,
  marketCity:"all",
  craftCity:"Fort Sterling",
  craftSellCity:"Black Market",
  refineCity:"Thetford",
  refineSellCity:"Thetford",
  saleMode:"sell_order",
  maxAgeHours:4,
  language:"en"
};

function num(value:unknown,fallback:number,min:number,max:number){
  const n=Number(value);
  return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;
}

export function loadSolHubSettings():SolHubSettings{
  if(typeof window==="undefined")return DEFAULT_SETTINGS;
  try{
    const raw=JSON.parse(localStorage.getItem(SETTINGS_KEY)??"{}");
    const language=(localStorage.getItem("sol-language")==="pt-BR"?"pt-BR":"en") as SolHubLanguage;
    return {
      ...DEFAULT_SETTINGS,
      ...raw,
      premium:raw?.premium!==false,
      focus:num(raw?.focus,DEFAULT_SETTINGS.focus,0,30000),
      stationFee:num(raw?.stationFee,DEFAULT_SETTINGS.stationFee,0,100000),
      maxAgeHours:num(raw?.maxAgeHours,DEFAULT_SETTINGS.maxAgeHours,1,48),
      saleMode:raw?.saleMode==="instant_sell"?"instant_sell":"sell_order",
      language
    };
  }catch{
    return {
      ...DEFAULT_SETTINGS,
      language:(localStorage.getItem("sol-language")==="pt-BR"?"pt-BR":"en") as SolHubLanguage
    };
  }
}

export function saveSolHubSettings(settings:SolHubSettings){
  if(typeof window==="undefined")return;
  localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));
  localStorage.setItem("sol-language",settings.language);
  window.dispatchEvent(new CustomEvent("sol-hub-settings-changed",{detail:settings}));
}

export function updateSolHubLanguage(language:SolHubLanguage){
  if(typeof window==="undefined")return;
  const next={...loadSolHubSettings(),language};
  localStorage.setItem(SETTINGS_KEY,JSON.stringify(next));
  localStorage.setItem("sol-language",language);
  window.dispatchEvent(new CustomEvent("sol-hub-settings-changed",{detail:next}));
}

export function resetSolHubSettings(){
  if(typeof window==="undefined")return;
  localStorage.removeItem(SETTINGS_KEY);
  localStorage.setItem("sol-language",DEFAULT_SETTINGS.language);
  window.dispatchEvent(new CustomEvent("sol-hub-settings-changed",{detail:DEFAULT_SETTINGS}));
}

export function useSolHubSettings(){
  const [settings,setSettings]=useState<SolHubSettings>(DEFAULT_SETTINGS);
  const [ready,setReady]=useState(false);

  useEffect(()=>{
    const refresh=()=>setSettings(loadSolHubSettings());
    refresh();
    setReady(true);
    window.addEventListener("sol-hub-settings-changed",refresh);
    window.addEventListener("storage",refresh);
    return()=>{
      window.removeEventListener("sol-hub-settings-changed",refresh);
      window.removeEventListener("storage",refresh);
    };
  },[]);

  return {settings,ready};
}

export function settingsFormKey(settings:SolHubSettings,ready:boolean){
  return ready?`saved-${JSON.stringify(settings)}`:"defaults";
}
