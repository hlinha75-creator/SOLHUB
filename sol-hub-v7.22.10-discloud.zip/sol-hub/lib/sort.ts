export type SortDir = "asc" | "desc";

const rank: Record<string, number> = {
  "Sem dados": 0,
  "Baixa": 1, "Baixo": 1,
  "Média": 2, "Médio": 2,
  "Alta": 3, "Alto": 3,
  "FLIP": 1, "CRAFT": 2
};

function comparable(v: unknown): string | number {
  if (v == null) return -Infinity;
  if (typeof v === "number") return Number.isFinite(v) ? v : -Infinity;
  if (typeof v === "boolean") return v ? 1 : 0;
  const s = String(v);
  if (s in rank) return rank[s];
  return s.toLocaleLowerCase("pt-PT");
}

export function sortRows<T>(rows: T[], key: string, dir: SortDir): T[] {
  const copy = [...rows];
  copy.sort((a:any,b:any)=>{
    const av=comparable(a?.[key]), bv=comparable(b?.[key]);
    let c=0;
    if(typeof av==="number" && typeof bv==="number") c=av-bv;
    else c=String(av).localeCompare(String(bv),"pt-PT",{numeric:true,sensitivity:"base"});
    return dir==="asc"?c:-c;
  });
  return copy;
}

export function nextSort(currentKey:string,currentDir:SortDir,key:string):{key:string;dir:SortDir}{
  return currentKey===key?{key,dir:currentDir==="desc"?"asc":"desc"}:{key,dir:"desc"};
}
