export type CraftKind="equipment"|"potion"|"food";

export type CraftCategory="weapon"|"armor"|"offhand"|"cape"|"bag"|"gathering"|"potion"|"food";

export function craftCategory(id:string,shopcategory?:string):CraftCategory|null{
  const u=id.toUpperCase();
  const shop=(shopcategory??"").toLowerCase();
  if(u.includes("_POTION_"))return "potion";
  if(u.includes("_MEAL_"))return "food";
  if(shop==="gathering")return "gathering";
  if(/_CAPE(?:_|$)/.test(u)||u.endsWith("_CAPE"))return "cape";
  if(/_BAG(?:_|$)/.test(u)||u.endsWith("_BAG"))return "bag";
  if(/(?:^|_)OFF_/.test(u))return "offhand";
  if(/(?:^|_)(MAIN_|2H_)/.test(u))return "weapon";
  if(/(?:^|_)(HEAD_|ARMOR_|SHOES_)/.test(u))return "armor";
  return null;
}

export function craftKind(id:string):CraftKind|null{
  const u=id.toUpperCase();
  if(u.includes("_POTION_"))return "potion";
  if(u.includes("_MEAL_"))return "food";
  if(/(?:^|_)(HEAD_|ARMOR_|SHOES_|MAIN_|2H_|OFF_)/.test(u)||/(?:^|_)BAG(?:_|$)/.test(u)||/(?:^|_)CAPE(?:_|$)/.test(u))return "equipment";
  return null;
}

export function craftCityFor(id:string,shopcategory?:string,subcategory?:string){
  const kind=craftKind(id);
  if(kind==="potion")return "Brecilien";
  if(kind==="food")return "Caerleon";

  const SUB:Record<string,string>={
    sword:"Lymhurst",bow:"Lymhurst",arcanestaff:"Lymhurst",
    axe:"Martlock",quarterstaff:"Martlock",froststaff:"Martlock",
    mace:"Thetford",firestaff:"Thetford",naturestaff:"Thetford",
    hammer:"Fort Sterling",spear:"Fort Sterling",holystaff:"Fort Sterling",
    crossbow:"Bridgewatch",dagger:"Bridgewatch",cursestaff:"Bridgewatch",
    knuckles:"Caerleon",shapeshifterstaff:"Caerleon",
    cloth_armor:"Fort Sterling",plate_helmet:"Fort Sterling",
    leather_helmet:"Lymhurst",leather_shoes:"Lymhurst",
    plate_armor:"Bridgewatch",cloth_shoes:"Bridgewatch",
    leather_armor:"Thetford",cloth_helmet:"Thetford",plate_shoes:"Martlock"
  };
  const CAT:Record<string,string>={
    offhands:"Martlock",bags:"Brecilien",capes:"Brecilien",gathering:"Caerleon"
  };
  return CAT[shopcategory??""]??SUB[subcategory??""]??"Caerleon";
}

export function isSupportedCraftId(id:string,tierMin=3,tierMax=8){
  const tier=Number(id.match(/^T(\d)_/)?.[1]??0);
  return tier>=tierMin&&tier<=tierMax&&craftKind(id)!==null;
}
