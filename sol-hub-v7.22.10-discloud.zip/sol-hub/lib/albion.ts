import {localizedItemName,type ItemLanguage} from "./localizedNames";
export const CITIES = [
  "Bridgewatch",
  "Martlock",
  "Lymhurst",
  "Thetford",
  "Fort Sterling",
  "Caerleon",
  "Brecilien",
  "Black Market"
] as const;

export type City = (typeof CITIES)[number];
export type SaleMode = "sell_order" | "instant_sell";

export type MarketPrice = {
  item_id: string;
  city: string;
  quality: number;
  sell_price_min: number;
  sell_price_min_date: string;
  buy_price_max: number;
  buy_price_max_date: string;
};

export type MarketHistoryPoint = {
  item_count: number;
  avg_price: number;
  timestamp: string;
};

export type MarketHistory = {
  location: string;
  item_id: string;
  quality: number;
  data: MarketHistoryPoint[];
};

export type ItemDump = {
  UniqueName?: string;
  LocalizedNames?: Record<string, string>;
};

const ITEM_DUMP = "https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const API_BASE = "https://europe.albion-online-data.com/api/v2/stats";

const categoryTests: Record<string, (id: string) => boolean> = {
  all: (id) => /_(ARMOR|HEAD|SHOES|MAIN|2H|OFF|BAG|CAPE|MOUNT|POTION|MEAL)/.test(id),
  armor: (id) => /_(ARMOR|HEAD|SHOES)_/.test(id),
  weapons: (id) => /_(MAIN|2H)_/.test(id),
  offhands: (id) => /_OFF_/.test(id),
  bags: (id) => /_BAG/.test(id),
  capes: (id) => /_CAPE/.test(id),
  gathering: (id) => /_(HEAD|ARMOR|SHOES)_GATHERER_/.test(id) || /_GATHERER_(HEAD|ARMOR|SHOES)_/.test(id),
  food: (id) => /_MEAL_/.test(id),
  mounts: (id) => /_MOUNT_/.test(id),
  potions: (id) => /_POTION_/.test(id)
};

export function canSellOnBlackMarket(id:string){
  return !/_MOUNT_/.test(id) && !/_POTION_/.test(id);
}

export function itemTier(id: string) {
  const m = /^T([4-8])_/.exec(id);
  return m ? Number(m[1]) : 0;
}

export function itemEnchant(id: string) {
  const m = /@(\d)$/.exec(id);
  return m ? Number(m[1]) : 0;
}

export async function loadItems(category: string, tiers: number[], enchants: number[], lang: ItemLanguage="en") {
  const response = await fetch(ITEM_DUMP, { next: { revalidate: 86400 } });
  if (!response.ok) throw new Error("Não foi possível carregar o catálogo de itens.");
  const dump = (await response.json()) as ItemDump[];
  const test = categoryTests[category] ?? categoryTests.all;
  const dedup = new Map<string, string>();

  for (const row of dump) {
    const id = row.UniqueName;
    if (!id || !/^T[4-8]_/.test(id) || !test(id)) continue;
    if (!tiers.includes(itemTier(id)) || !enchants.includes(itemEnchant(id))) continue;
    if (id.includes("_NONTRADABLE") || id.includes("_QUEST") || id.includes("_TOKEN")) continue;
    const name = localizedItemName(row,lang) || id;
    dedup.set(id, name);
  }

  return [...dedup.entries()].map(([id, name]) => ({ id, name }));
}

function makePriceBatches(ids: string[], locations: string[]) {
  const suffix = `?locations=${encodeURIComponent(locations.join(","))}&qualities=1,2,3,4,5`;
  const batches: string[][] = [];
  let batch: string[] = [];

  for (const id of ids) {
    const candidate = [...batch, id];
    const url = `${API_BASE}/prices/${candidate.join(",")}.json${suffix}`;
    if (url.length > 3600 && batch.length) {
      batches.push(batch);
      batch = [id];
    } else {
      batch = candidate;
    }
  }
  if (batch.length) batches.push(batch);
  return batches;
}

const sleep=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));

async function fetchAlbion(url:string,revalidate:number){
  const maxAttempts=3;
  for(let attempt=0;attempt<maxAttempts;attempt++){
    const r=await fetch(url,{next:{revalidate}});
    if(r.ok)return r;
    if(r.status!==429&&r.status<500)throw new Error(`Albion Data API respondeu ${r.status}.`);
    if(attempt===maxAttempts-1){
      if(r.status===429)throw new Error("Albion Data está temporariamente com demasiados pedidos. Aguarda alguns segundos e tenta novamente.");
      throw new Error(`Albion Data API respondeu ${r.status}.`);
    }
    const retryAfter=Number(r.headers.get("retry-after"));
    const waitMs=Number.isFinite(retryAfter)&&retryAfter>0?Math.min(3000,retryAfter*1000):700*(attempt+1);
    await sleep(waitMs);
  }
  throw new Error("Falha ao contactar Albion Data.");
}

export async function loadMarketPrices(ids: string[], locations: string[]) {
  const batches = makePriceBatches(ids, locations);
  const chunks:MarketPrice[][]=[];
  // Sequential requests avoid short bursts that can trigger AODP rate limiting.
  for(const batch of batches){
    const url = `${API_BASE}/prices/${batch.join(",")}.json?locations=${encodeURIComponent(locations.join(","))}&qualities=1,2,3,4,5`;
    const r=await fetchAlbion(url,60);
    chunks.push((await r.json()) as MarketPrice[]);
  }
  return chunks.flat();
}

function isoDay(date: Date) {
  return date.toISOString().slice(0, 10);
}

export async function loadMarketHistory(ids: string[], locations: string[], days = 8) {
  if (!ids.length || !locations.length) return [] as MarketHistory[];
  const end = new Date();
  const start = new Date(end.getTime() - days * 86400000);
  const dateParams = `date=${isoDay(start)}&end_date=${isoDay(end)}&time-scale=24`;
  const batches: string[][] = [];
  let batch: string[] = [];

  for (const id of [...new Set(ids)]) {
    const candidate = [...batch, id];
    const url = `${API_BASE}/history/${candidate.join(",")}.json?locations=${encodeURIComponent(locations.join(","))}&qualities=1,2,3,4,5&${dateParams}`;
    if ((url.length > 3400 || candidate.length > 18) && batch.length) {
      batches.push(batch);
      batch = [id];
    } else batch = candidate;
  }
  if (batch.length) batches.push(batch);

  const chunks:MarketHistory[][]=[];
  // History is enrichment only. Keep requests sequential and fail soft if AODP is busy.
  for(const idsBatch of batches){
    const url = `${API_BASE}/history/${idsBatch.join(",")}.json?locations=${encodeURIComponent(locations.join(","))}&qualities=1,2,3,4,5&${dateParams}`;
    try{
      const r=await fetchAlbion(url,900);
      chunks.push((await r.json()) as MarketHistory[]);
    }catch{
      chunks.push([]);
    }
  }
  return chunks.flat();
}

export function ageMinutes(date: string) {
  if (!date || date.startsWith("0001-")) return Number.POSITIVE_INFINITY;
  const normalized = /Z$|[+-]\d\d:\d\d$/.test(date) ? date : `${date}Z`;
  return Math.max(0, (Date.now() - new Date(normalized).getTime()) / 60000);
}

export function qualityName(q: number) {
  return ["", "Normal", "Good", "Outstanding", "Excellent", "Masterpiece"][q] ?? String(q);
}
