export type WatchlistType="FLIP"|"CRAFT"|"REFINE";
export type WatchlistSource="MARKET_SCANNER"|"SOL_OPTIMIZER"|"CRAFT_SCANNER"|"REFINE_SCANNER"|"DASHBOARD"|"LEGACY";
export type WatchlistEntry={
 id:string;type:WatchlistType;itemId:string;name:string;route:string;
 buyCity?:string;sellCity?:string;quality?:number;craftCity?:string;refineCity?:string;
 investment:number;profit:number;roi:number;dataAgeMin?:number;sellPrice?:number;buyPrice?:number;
 source?:WatchlistSource;
 intelligenceScore?:number;entryAdvantagePct?:number;trendPct?:number;marketCondition?:string;
 volatilityPct?:number;liquidity?:string;risk?:string;avgDailyVolume?:number;buyHistoryAvgPrice?:number;
 createdAt:string;
};
export const WATCHLIST_KEY="sol-hub-watchlist-v1";
export const WATCHLIST_EVENT="sol-hub-watchlist-changed";

export function watchlistKey(x:Pick<WatchlistEntry,"type"|"itemId"|"route"> & {source?:WatchlistSource}){
 return `${x.source??"LEGACY"}|${x.type}|${x.itemId}|${x.route}`;
}
export function loadWatchlist():WatchlistEntry[]{
 if(typeof window==="undefined")return[];
 try{
  const x=JSON.parse(localStorage.getItem(WATCHLIST_KEY)??"[]");
  return Array.isArray(x)?x:[];
 }catch{return[]}
}
export function saveWatchlist(rows:WatchlistEntry[]){
 if(typeof window==="undefined")return;
 localStorage.setItem(WATCHLIST_KEY,JSON.stringify(rows));
 window.dispatchEvent(new CustomEvent(WATCHLIST_EVENT));
}
export function isWatchlisted(input:Pick<WatchlistEntry,"type"|"itemId"|"route"> & {source?:WatchlistSource}){
 const rows=loadWatchlist(),key=watchlistKey(input);
 return rows.some(x=>watchlistKey(x)===key || (!!input.source && !x.source && x.type===input.type&&x.itemId===input.itemId&&x.route===input.route));
}
export function addWatchlist(input:Omit<WatchlistEntry,"id"|"createdAt">){
 const rows=loadWatchlist(),key=watchlistKey(input);
 if(rows.some(x=>watchlistKey(x)===key))return rows;
 const row:WatchlistEntry={...input,id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,createdAt:new Date().toISOString()};
 const next=[row,...rows];saveWatchlist(next);return next;
}
export function removeWatchlistByKey(input:Pick<WatchlistEntry,"type"|"itemId"|"route"> & {source?:WatchlistSource}){
 const key=watchlistKey(input),next=loadWatchlist().filter(x=>watchlistKey(x)!==key && !(!!input.source&&!x.source&&x.type===input.type&&x.itemId===input.itemId&&x.route===input.route));saveWatchlist(next);return next;
}
export function removeWatchlist(id:string){const next=loadWatchlist().filter(x=>x.id!==id);saveWatchlist(next);return next}
export function toggleWatchlist(input:Omit<WatchlistEntry,"id"|"createdAt">){
 return isWatchlisted(input)?removeWatchlistByKey(input):addWatchlist(input);
}
