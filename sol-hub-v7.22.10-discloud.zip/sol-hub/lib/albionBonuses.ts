
export const BASE_ROYAL_CRAFTING_BONUS=18;
export const SPECIALTY_CRAFTING_BONUS=15;
export const FOCUS_BONUS=59;

export const cityCraftingSpecialties:Record<string,string[]>={
  "Bridgewatch":["Crossbows","Daggers","Cursed Staffs","Plate Armor","Cloth Shoes"],
  "Martlock":["Axes","Quarterstaffs","Frost Staffs","Plate Shoes","Offhands"],
  "Lymhurst":["Swords","Bows","Arcane Staffs","Leather Helmets","Leather Shoes"],
  "Thetford":["Maces","Fire Staffs","Nature Staffs","Leather Armor","Cloth Helmets"],
  "Fort Sterling":["Hammers","Spears","Holy Staffs","Cloth Armor","Plate Helmets"],
  "Caerleon":["War Gloves","Shapeshifter Staffs","Gathering Gear"],
  "Brecilien":["Bags","Capes"]
};

export const rrrFromBonus=(bonus:number)=>bonus/(100+bonus);

export function cityRRR(city:string,hasSpecialty:boolean,focus=false,daily=0){
  const bonus=BASE_ROYAL_CRAFTING_BONUS+(hasSpecialty?SPECIALTY_CRAFTING_BONUS:0)+(focus?FOCUS_BONUS:0)+daily;
  return rrrFromBonus(bonus);
}

export const cityRRRReference=[
  {label:"Cidade Real — sem bónus específico",bonus:18,rrr:rrrFromBonus(18)},
  {label:"Cidade Real — com bónus específico",bonus:33,rrr:rrrFromBonus(33)},
  {label:"Cidade Real — sem bónus + Focus",bonus:77,rrr:rrrFromBonus(77)},
  {label:"Cidade Real — com bónus + Focus",bonus:92,rrr:rrrFromBonus(92)}
];

export const dailyBonusOptions=[
  {value:0,label:"Sem Daily Bonus"},
  {value:10,label:"+10% — item/grupo com bónus diário"},
  {value:20,label:"+20% — item/grupo com bónus diário"}
];


export function craftBonusBreakdown(opts:{
  hasSpecialty:boolean;
  focus?:boolean;
  dailyBonus?:number;
}){
  const base=BASE_ROYAL_CRAFTING_BONUS;
  const specialty=opts.hasSpecialty?SPECIALTY_CRAFTING_BONUS:0;
  const focus=opts.focus?FOCUS_BONUS:0;
  const daily=Math.max(0,Number(opts.dailyBonus??0));
  const total=base+specialty+focus+daily;
  return {base,specialty,focus,daily,total,rrr:rrrFromBonus(total)};
}
