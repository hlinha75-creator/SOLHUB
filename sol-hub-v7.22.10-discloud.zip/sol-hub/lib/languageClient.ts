export type SiteLanguage="pt-BR"|"en";

export function currentSiteLanguage():SiteLanguage{
  if(typeof window==="undefined")return "en";
  return localStorage.getItem("sol-language")==="pt-BR"?"pt-BR":"en";
}

export function withSiteLanguage(params:URLSearchParams){
  params.set("lang",currentSiteLanguage());
  return params;
}
