export type DataHealthLevel="freshNow"|"freshOk"|"freshAging"|"freshStale";
export function dataHealthLevel(ageMin:number|null|undefined):DataHealthLevel{
 if(ageMin==null)return "freshStale";
 const a=Number(ageMin);
 if(!Number.isFinite(a))return "freshStale";
 if(a<=30)return "freshNow";
 if(a<=120)return "freshOk";
 if(a<=240)return "freshAging";
 return "freshStale";
}
export function dataHealthLabel(ageMin:number|null|undefined,lang:"pt-BR"|"en"="en"){
 if(ageMin==null)return lang==="en"?"No data":"Sem dados";
 const a=Number(ageMin);
 if(!Number.isFinite(a))return lang==="en"?"No data":"Sem dados";
 if(a<=30)return "Fresh";
 if(a<=120)return "Recent";
 if(a<=240)return "Aging";
 return "Stale";
}
export function ageText(ageMin:number|null|undefined){
 if(ageMin==null)return "—";
 const a=Number(ageMin);
 if(!Number.isFinite(a))return "—";
 return a<60?`${Math.round(a)}m`:`${(a/60).toFixed(1)}h`;
}
export function dataHealthSummary(ages:(number|null|undefined)[]){
 const valid=ages.filter(x=>x!=null).map(Number).filter(Number.isFinite);
 const total=valid.length;
 const counts={freshNow:0,freshOk:0,freshAging:0,freshStale:0};
 for(const a of valid)counts[dataHealthLevel(a)]++;
 const healthy=counts.freshNow+counts.freshOk;
 const healthyPct=total?Math.round(healthy/total*100):0;
 const maxAgeMin=total?Math.max(...valid):null;
 return {total,counts,healthyPct,maxAgeMin};
}
