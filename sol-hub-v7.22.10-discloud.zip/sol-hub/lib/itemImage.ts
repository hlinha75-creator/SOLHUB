export const ITEM_IMAGE_VERSION="7226";

export function itemImageUrl(itemId:string,opts:{quality?:number;size?:number}={}){
  const exact=String(itemId??"").trim();
  const quality=Math.min(5,Math.max(1,Number(opts.quality??1)));
  const size=Math.min(160,Math.max(32,Number(opts.size??80)));
  // Include the exact item id in both the path and cache signature. This prevents
  // a stale response for one item from being reused for a different item.
  return `/api/item-image/${encodeURIComponent(exact)}?quality=${quality}&size=${size}&itemKey=${encodeURIComponent(exact)}&v=${ITEM_IMAGE_VERSION}`;
}
