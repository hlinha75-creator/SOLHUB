export type ParsedCraftResource={
  id:string;
  count:number;
  ret:boolean;
};

function priceId(id:string,enchantment:any){
  const e=String(enchantment??"0");
  return e!=="0"&&!id.includes("@")?`${id}@${e}`:id;
}

function one(r:any):ParsedCraftResource|null{
  const raw=String(r?.["@uniquename"]??"");
  const count=Number(r?.["@count"]??0);
  if(!raw||!Number.isFinite(count)||count<=0)return null;
  return {
    id:priceId(raw,r?.["@enchantmentlevel"]),
    count,
    ret:r?.["@maxreturnamount"]!=="0"
  };
}

/**
 * ao-bin represents craftresource in more than one shape depending on item type:
 * - array of resource objects
 * - a single resource object
 * - a flattened object using @uniquename0/@count0, @uniquename1/@count1, ...
 *
 * Normalise all three into the same structure.
 */
export function parseCraftResources(value:any):ParsedCraftResource[]{
  if(!value)return [];

  if(Array.isArray(value)){
    return value.map(one).filter((x):x is ParsedCraftResource=>x!==null);
  }

  const direct=one(value);
  if(direct)return [direct];

  if(typeof value!=="object")return [];

  const indexes=new Set<number>();
  for(const key of Object.keys(value)){
    const m=/^@uniquename(\d+)$/.exec(key);
    if(m)indexes.add(Number(m[1]));
  }

  return [...indexes].sort((a,b)=>a-b).map(i=>one({
    "@uniquename":value[`@uniquename${i}`],
    "@count":value[`@count${i}`],
    "@enchantmentlevel":value[`@enchantmentlevel${i}`],
    "@maxreturnamount":value[`@maxreturnamount${i}`]
  })).filter((x):x is ParsedCraftResource=>x!==null);
}
