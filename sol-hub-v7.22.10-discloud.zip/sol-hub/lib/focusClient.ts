import {calculatedFce,calculatedQualityPoints,calculatedRefiningFce,normalizedItemId,type CraftingSpecProfile} from "./specializationModel";

export type FocusProfile=Record<string,number>;
export type CraftingProfileV2={
  version:2;
  updatedAt:string;
  owner:{kind:"local"|"discord";discordUserId?:string};
  masteries:Record<string,number>;
  specs:Record<string,number>;
  legacyFceOverrides:FocusProfile;
};

const KEY="sol_specialization_profile_v2";
const OLD_KEY="sol_specialization_profile_v1";

function blank():CraftingProfileV2{
  return {version:2,updatedAt:new Date().toISOString(),owner:{kind:"local"},masteries:{},specs:{},legacyFceOverrides:{}};
}
const clamp=(v:any)=>Math.max(0,Math.min(100,Math.floor(Number(v)||0)));

export function loadCraftingProfile():CraftingProfileV2{
  if(typeof window==="undefined")return blank();
  try{
    const raw=localStorage.getItem(KEY);
    if(raw){
      const p=JSON.parse(raw);
      if(p?.version===2)return {...blank(),...p,masteries:p.masteries??{},specs:p.specs??{},legacyFceOverrides:p.legacyFceOverrides??{}};
    }
    const old=localStorage.getItem(OLD_KEY);
    if(old){
      const p=JSON.parse(old);
      const migrated={...blank(),legacyFceOverrides:p?.focusEfficiency??{}};
      saveCraftingProfile(migrated);
      return migrated;
    }
  }catch{}
  return blank();
}
export function saveCraftingProfile(profile:CraftingProfileV2){
  if(typeof window==="undefined")return;
  localStorage.setItem(KEY,JSON.stringify({...profile,updatedAt:new Date().toISOString()}));
}
export function saveMastery(familyId:string,level:number){
  const p=loadCraftingProfile();p.masteries[familyId]=clamp(level);saveCraftingProfile(p);
}
export function saveSpec(familyId:string,itemId:string,level:number){
  const p=loadCraftingProfile();p.specs[`${familyId}:${normalizedItemId(itemId)}`]=clamp(level);saveCraftingProfile(p);
}
export function specLevel(familyId:string,itemId:string){
  return loadCraftingProfile().specs[`${familyId}:${normalizedItemId(itemId)}`]??0;
}
export function focusEfficiencyFor(itemId:string){return calculatedFce(itemId,loadCraftingProfile())}
export function refiningFocusEfficiencyFor(itemId:string){return calculatedRefiningFce(itemId,loadCraftingProfile())}
export function qualityPointsFor(itemId:string){return calculatedQualityPoints(itemId,loadCraftingProfile())}
export function loadFocusProfile():FocusProfile{return {...loadCraftingProfile().legacyFceOverrides}}
export function exportSpecializationProfile(){return JSON.stringify(loadCraftingProfile(),null,2)}
export function importSpecializationProfile(raw:string){
  const p=JSON.parse(raw);if(p?.version!==2)throw new Error("Perfil incompatível");
  const clean=blank();
  clean.owner=p.owner?.kind==="discord"?{kind:"discord",discordUserId:p.owner.discordUserId}:{kind:"local"};
  for(const [k,v] of Object.entries(p.masteries??{}))clean.masteries[k]=clamp(v);
  for(const [k,v] of Object.entries(p.specs??{}))clean.specs[k]=clamp(v);
  clean.legacyFceOverrides=p.legacyFceOverrides??{};
  saveCraftingProfile(clean);return clean;
}
export const loadSpecializationProfile=loadCraftingProfile;
// Backwards compatibility for older pages / migrated profiles.
export function saveFocusEfficiency(itemId:string,value:number){const p=loadCraftingProfile();if(value>0)p.legacyFceOverrides[itemId]=Math.floor(value);else delete p.legacyFceOverrides[itemId];saveCraftingProfile(p)}
export function removeFocusEfficiency(itemId:string){const p=loadCraftingProfile();delete p.legacyFceOverrides[itemId];saveCraftingProfile(p)}
