import {calculatedFce,calculatedRefiningFce,type CraftingSpecProfile} from "./specializationModel";
export type FocusProfile=Record<string,number>;

export function parseFocusProfile(raw:string|null):FocusProfile{
  if(!raw)return {};
  try{const x=JSON.parse(raw);const out:FocusProfile={};for(const[k,v]of Object.entries(x??{})){const n=Math.max(0,Number(v)||0);if(n>0)out[k]=n}return out}catch{return {}}
}
export function parseCraftingSpecProfile(raw:string|null):CraftingSpecProfile{
  if(!raw)return {masteries:{},specs:{}};
  try{const x=JSON.parse(raw);return {masteries:x?.masteries??{},specs:x?.specs??{},legacyFceOverrides:x?.legacyFceOverrides??{}}}catch{return {masteries:{},specs:{}}}
}
export function profileFce(itemId:string,p:CraftingSpecProfile,subcategory?:string){return calculatedFce(itemId,p,subcategory)}
export function profileRefiningFce(itemId:string,p:CraftingSpecProfile){return calculatedRefiningFce(itemId,p)}
export function focusCostPerCraft(baseFocus:number|undefined|null,focusEfficiency:number){
  const base=Math.max(0,Number(baseFocus??0));if(!base)return 0;
  const fce=Math.max(0,Number(focusEfficiency??0));
  return Math.ceil(base*Math.pow(0.5,fce/10000));
}
