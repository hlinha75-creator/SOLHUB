export type CraftFamilyType=
  "weapon"|"armor"|"offhand"|"gathering"|"bag"|"cape"|"potion"|"food"|"refining"|"other";

export type CraftFamily={
  id:string;
  name:string;
  icon:string;
  type:CraftFamilyType;
};

export type CraftingSpecProfile={
  masteries:Record<string,number>;
  specs:Record<string,number>;
  legacyFceOverrides?:Record<string,number>;
};

const WEAPONS:[string,string,string][]=[
  ["bow","Bow Crafter","🏹"],["dagger","Dagger Crafter","🗡️"],["spear","Spear Crafter","🔱"],
  ["sword","Sword Crafter","⚔️"],["axe","Axe Crafter","🪓"],["crossbow","Crossbow Crafter","🏹"],
  ["fire","Fire Staff Crafter","🔥"],["frost","Frost Staff Crafter","❄️"],["holy","Holy Staff Crafter","✨"],
  ["nature","Nature Staff Crafter","🌿"],["curse","Cursed Staff Crafter","☠️"],["arcane","Arcane Staff Crafter","🔮"],
  ["quarterstaff","Quarterstaff Crafter","🥋"],["hammer","Hammer Crafter","🔨"],["mace","Mace Crafter","🔨"],
  ["knuckles","War Gloves Crafter","🥊"],["shapeshifter","Shapeshifter Staff Crafter","🐾"]
];

export function normalizedItemId(itemId:string){
  return itemId.replace(/^T\d+_/,"").replace(/@\d+$/,"");
}
function includesAny(id:string,xs:string[]){return xs.some(x=>id.includes(x))}

function gatheringFamily(id:string):CraftFamily|null{
  if(!id.includes("_GATHERER_"))return null;
  const map:[string,string,string,string][]=[
    ["FIBER","gather_fiber","Harvester Crafter","🌾"],
    ["WOOD","gather_wood","Lumberjack Crafter","🪵"],
    ["ORE","gather_ore","Miner Crafter","⛏️"],
    ["HIDE","gather_hide","Skinner Crafter","🦌"],
    ["ROCK","gather_rock","Quarrier Crafter","🪨"],
  ];
  for(const [token,fid,name,icon] of map)if(id.includes(token))return {id:fid,name,icon,type:"gathering"};
  return null;
}

function offhandFamily(id:string,subcategory?:string):CraftFamily|null{
  if(!id.startsWith("OFF_"))return null;
  const sub=(subcategory??"").toLowerCase();
  if(sub.includes("torch"))return {id:"offhand_torch",name:"Torch Crafter",icon:"🔥",type:"offhand"};
  if(sub.includes("book")||sub.includes("tome"))return {id:"offhand_tome",name:"Tome Crafter",icon:"📖",type:"offhand"};
  if(sub.includes("shield"))return {id:"offhand_shield",name:"Shield Crafter",icon:"🛡️",type:"offhand"};

  // Fallbacks for the three simple off-hands and the long-standing artifact IDs.
  if(id==="OFF_TORCH"||includesAny(id,["HORN_KEEPER","JESTERCANE","LAMP_"]))return {id:"offhand_torch",name:"Torch Crafter",icon:"🔥",type:"offhand"};
  if(id==="OFF_BOOK"||includesAny(id,["ORB_","CENSER","TAPROOT","MUISAK","GRIMOIRE"]))return {id:"offhand_tome",name:"Tome Crafter",icon:"📖",type:"offhand"};
  if(id==="OFF_SHIELD"||includesAny(id,["SHIELD","SARCOPHAGUS","FACEBREAKER","AEGIS","WARD"]))return {id:"offhand_shield",name:"Shield Crafter",icon:"🛡️",type:"offhand"};
  return {id:"offhand",name:"Off-Hand Crafter",icon:"◈",type:"offhand"};
}

export function craftFamilyFor(itemId:string,subcategory?:string):CraftFamily|null{
  const id=normalizedItemId(itemId).toUpperCase();

  if(id.startsWith("POTION_")||id.includes("_POTION_"))return {id:"potion",name:"Alchemist",icon:"🧪",type:"potion"};
  if(id.startsWith("MEAL_")||id.includes("_MEAL_"))return {id:"food",name:"Chef",icon:"🍲",type:"food"};

  const gather=gatheringFamily(id);
  if(gather)return gather;

  if(id==="BAG"||id.startsWith("BAG_"))return {id:"bag",name:"Bag Tailor",icon:"🎒",type:"bag"};
  if(id==="CAPE"||id.startsWith("CAPE_")||id.startsWith("CAPEITEM_"))return {id:"cape",name:"Cape Tailor",icon:"🦸",type:"cape"};

  const off=offhandFamily(id,subcategory);
  if(off)return off;

  const armorMaterial=id.includes("_CLOTH_")?"cloth":id.includes("_LEATHER_")?"leather":id.includes("_PLATE_")?"plate":null;
  if(armorMaterial){
    const matName=armorMaterial==="cloth"?"Cloth":armorMaterial==="leather"?"Leather":"Plate";
    if(id.startsWith("HEAD_"))return {id:`${armorMaterial}_head`,name:`${matName} Helmet Crafter`,icon:"🪖",type:"armor"};
    if(id.startsWith("ARMOR_"))return {id:`${armorMaterial}_armor`,name:`${matName} Armor Crafter`,icon:"🛡️",type:"armor"};
    if(id.startsWith("SHOES_"))return {id:`${armorMaterial}_shoes`,name:`${matName} Shoes Crafter`,icon:"🥾",type:"armor"};
  }

  const map:Record<string,string[]>={
    bow:["BOW"], dagger:["DAGGER","CLAW","RAPIER","SICKLE","KATAR"],
    spear:["SPEAR","GLAIVE","TRIDENT","HARPOON"], sword:["SWORD","CLAYMORE","SCIMITAR","CLEAVER"],
    axe:["AXE","HALBERD","SCYTHE"], crossbow:["CROSSBOW"],
    fire:["FIRESTAFF","INFERNOSTAFF"], frost:["FROSTSTAFF","GLACIALSTAFF","ICECRYSTAL","ICEGAUNTLETS"],
    holy:["HOLYSTAFF","DIVINESTAFF"], nature:["NATURESTAFF","WILDSTAFF"],
    curse:["CURSEDSTAFF","DEMONICSTAFF","SKULLORB"], arcane:["ARCANESTAFF","ENIGMATICSTAFF"],
    quarterstaff:["QUARTERSTAFF","IRONCLADEDSTAFF","DOUBLEBLADEDSTAFF","COMBATSTAFF","TWINSCYTHE"],
    hammer:["HAMMER","POLEHAMMER","RAM_KEEPER"], mace:["MACE","FLAIL"],
    knuckles:["KNUCKLES","BRAWLER","GLOVES"], shapeshifter:["SHAPESHIFTER"]
  };
  for(const [fam,name,icon] of WEAPONS){
    if(includesAny(id,map[fam]??[]))return {id:fam,name,icon,type:"weapon"};
  }
  return null;
}


export function refiningFamilyFor(itemId:string):CraftFamily|null{
  const id=itemId.toUpperCase();
  if(id.includes("_METALBAR"))return {id:"refine_metal",name:"Ore Refiner",icon:"⛏️",type:"refining"};
  if(id.includes("_PLANKS"))return {id:"refine_wood",name:"Wood Refiner",icon:"🪵",type:"refining"};
  if(id.includes("_LEATHER"))return {id:"refine_leather",name:"Hide Refiner",icon:"🦌",type:"refining"};
  if(id.includes("_CLOTH"))return {id:"refine_cloth",name:"Fiber Refiner",icon:"🌾",type:"refining"};
  if(id.includes("_STONEBLOCK"))return {id:"refine_stone",name:"Stone Refiner",icon:"🪨",type:"refining"};
  return null;
}

export function refiningTierKey(itemId:string){
  const m=itemId.toUpperCase().match(/^T([4-8])_/);
  return m?`T${m[1]}`:"";
}

export function calculatedRefiningFce(itemId:string,profile:CraftingSpecProfile){
  const family=refiningFamilyFor(itemId);
  const target=refiningTierKey(itemId);
  if(!family||!target)return 0;
  let total=0;
  for(const [key,raw] of Object.entries(profile.specs)){
    if(!key.startsWith(`${family.id}:`))continue;
    const node=key.slice(family.id.length+1);
    const lvl=clamp(raw);
    total+=lvl*30;
    if(node===target)total+=lvl*250;
  }
  return Math.round(total*100)/100;
}

export function isArtifactLike(itemId:string){
  const id=normalizedItemId(itemId).toUpperCase();
  return includesAny(id,["_MORGANA","_HELL","_UNDEAD","_KEEPER","_AVALON","_ROYAL"]);
}

const SPECIALIZED_POTION_TOKENS=[
  "CALMING","CLEANSE","CLEANSING","ACID","BERSERK","HELLFIRE",
  "GATHER","TORNADO","LIFEWARD"
];
export function isSpecializedPotion(itemId:string){
  const id=normalizedItemId(itemId).toUpperCase();
  return SPECIALIZED_POTION_TOKENS.some(x=>id.includes(x));
}
function isSatchel(itemId:string){return normalizedItemId(itemId).toUpperCase().includes("BAG_INSIGHT")}
function isSimpleOffhand(itemId:string){
  const id=normalizedItemId(itemId).toUpperCase();
  return id==="OFF_TORCH"||id==="OFF_BOOK"||id==="OFF_SHIELD";
}

export function specNodeKey(itemId:string,family:CraftFamily){
  if(family.type==="refining")return refiningTierKey(itemId);
  if(family.type==="cape")return "CAPE";
  return normalizedItemId(itemId);
}

export function uniqueFcePerLevel(itemId:string,family?:CraftFamily){
  if(family?.type==="refining")return 250;
  if(family?.type==="cape")return 370;
  if(family?.type==="bag")return isSatchel(itemId)?310:340;
  return 250;
}
export function masteryFcePerLevel(family:CraftFamily){
  if(family.type==="refining")return 0;
  if(family.type==="gathering")return 60;
  return 30;
}
export function mutualFcePerLevel(itemId:string,family:CraftFamily){
  if(family.type==="refining")return 30;
  if(family.type==="potion")return isSpecializedPotion(itemId)?11.25:22.5;
  if(family.type==="food")return 30;
  if(family.type==="gathering")return 30;
  if(family.type==="bag")return isSatchel(itemId)?30:0;
  if(family.type==="cape")return 0;
  if(family.type==="offhand")return isSimpleOffhand(itemId)?90:15;
  if(family.type==="weapon"||family.type==="armor")return isArtifactLike(itemId)?15:30;
  return 0;
}

export function uniqueQualityPerLevel(family:CraftFamily,itemId?:string){
  if(family.type==="cape")return 9;
  if(family.type==="bag")return itemId&&isSatchel(itemId)?7.5:8.3;
  if(["weapon","armor","offhand","gathering"].includes(family.type))return 6;
  return 0;
}
export function masteryQualityPerLevel(family:CraftFamily){
  if(family.type==="gathering")return 1.5;
  if(["weapon","armor","offhand","bag","cape"].includes(family.type))return 0.75;
  return 0;
}
export function mutualQualityPerLevel(itemId:string,family:CraftFamily){
  if(family.type==="gathering")return 0.75;
  if(family.type==="bag")return isSatchel(itemId)?0.75:0;
  if(family.type==="cape")return 0;
  if(family.type==="offhand")return isSimpleOffhand(itemId)?2.3:0.38;
  if(family.type==="weapon"||family.type==="armor")return isArtifactLike(itemId)?0.38:0.75;
  return 0;
}

function hasQuality(family:CraftFamily){
  return ["weapon","armor","offhand","gathering","bag","cape"].includes(family.type);
}
function clamp(v:any){return Math.max(0,Math.min(100,Number(v)||0))}

export function calculatedFceForFamily(itemId:string,family:CraftFamily,profile:CraftingSpecProfile){
  let total=clamp(profile.masteries[family.id])*masteryFcePerLevel(family);
  const target=specNodeKey(itemId,family);

  for(const [key,raw] of Object.entries(profile.specs)){
    if(!key.startsWith(`${family.id}:`))continue;
    const specItem=key.slice(family.id.length+1);
    const lvl=clamp(raw);
    total += lvl*mutualFcePerLevel(specItem,family);
    if(specItem===target)total += lvl*uniqueFcePerLevel(specItem,family);
  }
  return Math.round(total*100)/100;
}

export function calculatedFce(itemId:string,profile:CraftingSpecProfile,subcategory?:string){
  const family=craftFamilyFor(itemId,subcategory);
  if(!family)return profile.legacyFceOverrides?.[itemId]??0;
  return calculatedFceForFamily(itemId,family,profile)||(profile.legacyFceOverrides?.[itemId]??0);
}

export function calculatedQualityPointsForFamily(itemId:string,family:CraftFamily,profile:CraftingSpecProfile){
  if(!hasQuality(family))return 0;
  let total=clamp(profile.masteries[family.id])*masteryQualityPerLevel(family);
  const target=specNodeKey(itemId,family);

  for(const [key,raw] of Object.entries(profile.specs)){
    if(!key.startsWith(`${family.id}:`))continue;
    const specItem=key.slice(family.id.length+1);
    const lvl=clamp(raw);
    total += lvl*mutualQualityPerLevel(specItem,family);
    if(specItem===target)total += lvl*uniqueQualityPerLevel(family,specItem);
  }
  return Math.round(total*100)/100;
}

export function calculatedQualityPoints(itemId:string,profile:CraftingSpecProfile,subcategory?:string){
  const family=craftFamilyFor(itemId,subcategory);
  if(!family)return 0;
  return calculatedQualityPointsForFamily(itemId,family,profile);
}
