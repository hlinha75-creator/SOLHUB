export type RecommendationTone="positive"|"caution"|"negative"|"neutral";
export type SolRecommendation={
 code:string;
 tone:RecommendationTone;
 label:string;
 headline:string;
 reason:string;
 action:string;
};

type Lang="en"|"pt-BR";

export function marketRecommendation(input:{
 roi:number;profit:number;risk:"Baixo"|"Médio"|"Alto";liquidity:"Alta"|"Média"|"Baixa"|"Sem dados";
 volatilityPct:number;priceDeviationPct:number;trendPct?:number;dataAgeMin:number;recommendedQty:number;
},lang:Lang):SolRecommendation{
 const en=lang==="en";
 const trend=input.trendPct??0;

 if(input.risk==="Alto"||input.dataAgeMin>240||input.volatilityPct>35){
  return {
   code:"AVOID",tone:"negative",
   label:en?"Avoid":"Evitar",
   headline:en?"Risk is too high right now":"Risco alto demais neste momento",
   reason:en
    ?`Risk, volatility or data age is outside SOL's conservative range. Volatility is ${input.volatilityPct.toFixed(1)}% and the oldest market input is ${Math.round(input.dataAgeMin)} min.`
    :`O risco, a volatilidade ou a idade dos dados está fora da faixa conservadora do SOL. A volatilidade é ${input.volatilityPct.toFixed(1)}% e o dado de mercado mais antigo tem ${Math.round(input.dataAgeMin)} min.`,
   action:en?"Wait for fresher data or a safer route.":"Aguarde dados mais recentes ou uma rota mais segura."
  };
 }
 if(input.priceDeviationPct>=20){
  return {
   code:"WAIT",tone:"caution",
   label:en?"Wait":"Aguardar",
   headline:en?"Exit price looks overheated":"O preço de saída parece aquecido",
   reason:en
    ?`The sell price is ${input.priceDeviationPct.toFixed(1)}% above its 7d average. The margin may be real, but execution risk is higher.`
    :`O preço de venda está ${input.priceDeviationPct.toFixed(1)}% acima da média de 7 dias. A margem pode ser real, mas o risco de execução é maior.`,
   action:en?"Recheck the market before buying inventory.":"Confira o mercado novamente antes de comprar estoque."
  };
 }
 if(input.liquidity==="Baixa"||input.liquidity==="Sem dados"||input.recommendedQty<=1){
  return {
   code:"LIMIT",tone:"caution",
   label:en?"Limit quantity":"Limitar quantidade",
   headline:en?"Good margin, limited exit liquidity":"Boa margem, liquidez de saída limitada",
   reason:en
    ?`Return is ${input.roi.toFixed(1)}%, but liquidity is ${input.liquidity==="Sem dados"?"unconfirmed":"low"}. SOL recommends keeping the position small.`
    :`A rentabilidade é ${input.roi.toFixed(1)}%, mas a liquidez é ${input.liquidity==="Sem dados"?"não confirmada":"baixa"}. O SOL recomenda manter a posição pequena.`,
   action:en?`Start with up to ${Math.max(1,input.recommendedQty)} unit(s).`:`Comece com até ${Math.max(1,input.recommendedQty)} un.`
  };
 }
 if(input.risk==="Baixo"&&input.roi>=12&&trend>=-7){
  return {
   code:"GOOD_BUY",tone:"positive",
   label:en?"Good opportunity":"Boa oportunidade",
   headline:en?"Healthy margin with manageable risk":"Margem saudável com risco controlado",
   reason:en
    ?`Return is ${input.roi.toFixed(1)}%, liquidity is ${input.liquidity==="Alta"?"high":"acceptable"}, and the route remains inside SOL's conservative risk limits.`
    :`A rentabilidade é ${input.roi.toFixed(1)}%, a liquidez é ${input.liquidity==="Alta"?"alta":"aceitável"} e a rota permanece dentro dos limites conservadores de risco do SOL.`,
   action:en?`Consider up to ${Math.max(1,input.recommendedQty)} unit(s), then validate prices in-game.`:`Considere até ${Math.max(1,input.recommendedQty)} un. e depois valide os preços no jogo.`
  };
 }
 return {
  code:"WATCH",tone:"neutral",
  label:en?"Watch":"Observar",
  headline:en?"Promising, but not a strong signal yet":"Promissor, mas ainda sem sinal forte",
  reason:en
   ?`The route is profitable, but one or more quality signals are only moderate. Current return is ${input.roi.toFixed(1)}%.`
   :`A rota é lucrativa, mas um ou mais sinais de qualidade ainda são moderados. A rentabilidade atual é ${input.roi.toFixed(1)}%.`,
  action:en?"Keep it on the Watchlist and recheck later.":"Mantenha na Watchlist e confira novamente mais tarde."
 };
}

export function craftRecommendation(input:{
 roi:number;profit:number;score:number;dataAgeMin:number;focus:boolean;daily:number;rrr:number;
},lang:Lang):SolRecommendation{
 const en=lang==="en";
 if(input.dataAgeMin>240||input.roi<5){
  return {code:"WAIT",tone:"caution",label:en?"Wait":"Aguardar",headline:en?"Recheck prices before crafting":"Confira os preços antes de craftar",
   reason:en?`Market inputs are old or the return is too thin. Current return is ${input.roi.toFixed(1)}%.`:`Os dados de mercado estão antigos ou a margem está muito apertada. A rentabilidade atual é ${input.roi.toFixed(1)}%.`,
   action:en?"Refresh the scanner before committing materials.":"Atualize o scanner antes de comprometer materiais."};
 }
 if(input.roi>=15&&input.score>=70){
  return {code:"CRAFT_NOW",tone:"positive",label:en?"Craft now":"Craftar agora",headline:en?"Strong crafting setup":"Configuração forte de crafting",
   reason:en?`Return is ${input.roi.toFixed(1)}% with a score of ${input.score}/100${input.daily?` and a +${input.daily}% Daily Bonus`:""}.`:`A rentabilidade é ${input.roi.toFixed(1)}% com score ${input.score}/100${input.daily?` e Daily Bonus de +${input.daily}%`:""}.`,
   action:en?"Validate station fee and material stock, then craft.":"Valide a taxa da estação e o estoque de materiais, depois faça o craft."};
 }
 return {code:"SMALL_BATCH",tone:"neutral",label:en?"Small batch":"Lote pequeno",headline:en?"Profitable, but scale carefully":"Lucrativo, mas aumente a escala com cuidado",
  reason:en?`Return is ${input.roi.toFixed(1)}%. The setup is positive, but SOL would test execution before scaling.`:`A rentabilidade é ${input.roi.toFixed(1)}%. A configuração é positiva, mas o SOL testaria a execução antes de aumentar a escala.`,
  action:en?"Start with a small batch and confirm sell-through.":"Comece com um lote pequeno e confirme a velocidade de venda."};
}

export function refineRecommendation(input:{
 roi:number;profit:number;score:number;risk:"Baixo"|"Médio"|"Alto";dataAgeMin:number;useFocus:boolean;roiNoFocus:number;roiFocus:number;
},lang:Lang):SolRecommendation{
 const en=lang==="en";
 if(input.risk==="Alto"||input.dataAgeMin>240){
  return {code:"WAIT",tone:"caution",label:en?"Wait":"Aguardar",headline:en?"Refining signal is too risky":"Sinal de refino arriscado demais",
   reason:en?"Risk or market data age is outside SOL's preferred range.":"O risco ou a idade dos dados de mercado está fora da faixa preferida do SOL.",
   action:en?"Refresh prices before refining.":"Atualize os preços antes de refinar."};
 }
 if(input.useFocus&&input.roiFocus-input.roiNoFocus>=5){
  return {code:"USE_FOCUS",tone:"positive",label:en?"Use Focus":"Usar Focus",headline:en?"Focus materially improves this refine":"O Focus melhora bastante este refino",
   reason:en?`Return improves from ${input.roiNoFocus.toFixed(1)}% to ${input.roiFocus.toFixed(1)}% with Focus.`:`A rentabilidade melhora de ${input.roiNoFocus.toFixed(1)}% para ${input.roiFocus.toFixed(1)}% com Focus.`,
   action:en?"Use Focus here before lower-efficiency refines.":"Priorize o uso de Focus aqui antes de refinos menos eficientes."};
 }
 if(input.roi>=12&&input.risk==="Baixo"){
  return {code:"REFINE_NOW",tone:"positive",label:en?"Refine now":"Refinar agora",headline:en?"Healthy refine with low risk":"Refino saudável com baixo risco",
   reason:en?`Return is ${input.roi.toFixed(1)}% and the route is classified as low risk.`:`A rentabilidade é ${input.roi.toFixed(1)}% e a rota está classificada como baixo risco.`,
   action:en?"Confirm material availability, then refine.":"Confirme a disponibilidade dos materiais e depois refine."};
 }
 return {code:"SMALL_BATCH",tone:"neutral",label:en?"Small batch":"Lote pequeno",headline:en?"Positive refine, moderate conviction":"Refino positivo, convicção moderada",
  reason:en?`Return is ${input.roi.toFixed(1)}%, but SOL would avoid scaling aggressively yet.`:`A rentabilidade é ${input.roi.toFixed(1)}%, mas o SOL ainda evitaria aumentar muito a escala.`,
  action:en?"Test a small batch and refresh prices before scaling.":"Teste um lote pequeno e atualize os preços antes de aumentar a escala."};
}
