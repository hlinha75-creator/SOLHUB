export type IntelligenceCondition=
  |"POTENTIALLY_UNDERVALUED"|"FAIR_PRICE"|"POTENTIALLY_OVERPRICED"
  |"RISING_TREND"|"FALLING_TREND"|"UNSTABLE_MARKET"|"NO_HISTORY";

export type IntelligenceComponents={
  profit:number;return:number;liquidity:number;stability:number;freshness:number;capitalEfficiency:number;
};

export type MarketIntelligence={
  score:number;
  components:IntelligenceComponents;
  trendPct:number;
  entryAdvantagePct:number;
  condition:IntelligenceCondition;
};

const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));

export function historyTrendPct(points:{avg_price:number}[]){
  const valid=points.filter(x=>Number(x.avg_price)>0);
  if(valid.length<2)return 0;
  const first=valid[0].avg_price,last=valid[valid.length-1].avg_price;
  return first>0?(last-first)/first*100:0;
}

export function marketIntelligence(input:{
  roi:number;profit:number;avgDailyVolume:number;volatilityPct:number;dataAgeMin:number;
  buyPrice:number;buyHistoryAvgPrice?:number;trendPct?:number;recommendedInvestment?:number;recommendedProfit?:number;
}):MarketIntelligence{
  const trendPct=Number.isFinite(input.trendPct)?Number(input.trendPct):0;
  const entryAdvantagePct=(input.buyHistoryAvgPrice??0)>0
    ?((input.buyHistoryAvgPrice??0)-input.buyPrice)/(input.buyHistoryAvgPrice??1)*100:0;
  const profit=clamp(input.profit/50000*100);
  const ret=clamp(input.roi/25*100);
  const liquidity=clamp(input.avgDailyVolume/20*100);
  const stability=clamp(100-input.volatilityPct*3);
  const freshness=clamp(100-input.dataAgeMin/240*100);
  const investment=input.recommendedInvestment&&input.recommendedInvestment>0?input.recommendedInvestment:input.buyPrice;
  const projected=input.recommendedProfit&&input.recommendedProfit>0?input.recommendedProfit:input.profit;
  const capitalEfficiency=clamp(investment>0?(projected/investment*100)/25*100:0);
  const components={profit,return:ret,liquidity,stability,freshness,capitalEfficiency};
  const score=Math.round(
    ret*.22+profit*.16+liquidity*.20+stability*.16+freshness*.14+capitalEfficiency*.12
  );
  const condition:IntelligenceCondition=
    input.volatilityPct>=28?"UNSTABLE_MARKET":
    entryAdvantagePct>=12?"POTENTIALLY_UNDERVALUED":
    entryAdvantagePct<=-12?"POTENTIALLY_OVERPRICED":
    trendPct>=7?"RISING_TREND":
    trendPct<=-7?"FALLING_TREND":
    (input.buyHistoryAvgPrice??0)>0?"FAIR_PRICE":"NO_HISTORY";
  return {score,components,trendPct,entryAdvantagePct,condition};
}

export function intelligenceBand(score:number,lang:"pt-BR"|"en"){
  if(score>=85)return lang==="en"?"Strong opportunity":"Oportunidade forte";
  if(score>=72)return lang==="en"?"Good opportunity":"Boa oportunidade";
  if(score>=58)return lang==="en"?"Acceptable":"Aceitável";
  if(score>=42)return lang==="en"?"Watch carefully":"Observar com cuidado";
  return lang==="en"?"Weak opportunity":"Oportunidade fraca";
}

export function conditionLabel(condition:IntelligenceCondition,lang:"pt-BR"|"en"){
  const en:Record<IntelligenceCondition,string>={
    POTENTIALLY_UNDERVALUED:"Potentially undervalued",FAIR_PRICE:"Fair price",POTENTIALLY_OVERPRICED:"Potentially overpriced",
    RISING_TREND:"Rising trend",FALLING_TREND:"Falling trend",UNSTABLE_MARKET:"Unstable market",NO_HISTORY:"No history"
  };
  const pt:Record<IntelligenceCondition,string>={
    POTENTIALLY_UNDERVALUED:"Potencialmente subvalorizado",FAIR_PRICE:"Preço justo",POTENTIALLY_OVERPRICED:"Potencialmente sobrevalorizado",
    RISING_TREND:"Tendência de alta",FALLING_TREND:"Tendência de baixa",UNSTABLE_MARKET:"Mercado instável",NO_HISTORY:"Sem histórico"
  };
  return (lang==="en"?en:pt)[condition];
}

export function watchlistChangeLabel(saved:number,current:number,lang:"pt-BR"|"en"){
  const d=current-saved;
  if(d>=8)return lang==="en"?"Opportunity improved":"Oportunidade melhorou";
  if(d<=-8)return lang==="en"?"Opportunity deteriorated":"Oportunidade piorou";
  return lang==="en"?"Opportunity stable":"Oportunidade estável";
}
