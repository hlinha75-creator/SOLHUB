export type DailyProductionBonus={category:string;bonus:number;city?:string};

const SRC="https://ao-sage.com/today";

function clean(s:string){return s.replace(/<[^>]*>/g," ").replace(/&amp;/g,"&").replace(/&#39;/g,"'").replace(/\s+/g," ").trim()}

export async function getEuropeDailyBonuses():Promise<{
  bonuses:DailyProductionBonus[];source:string;updatedAt:string;available:boolean;
  dateLabel?:string;resetLabel?:string;lastSeen?:string[];events?:{title:string;detail?:string;time?:string}[]
}>{
  try{
    const r=await fetch(SRC,{next:{revalidate:600},headers:{"user-agent":"SOL-HUB/1.0"}});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const html=await r.text();

    // Scope to the Europe "Today's ... production bonus" section and stop before Daily events.
    const main=html.split("Daily events")[0]??html;
    const text=clean(main);

    // Parse each visible AO-SAGE bonus card independently. This prevents the page header
    // ("Daily Production Bonus Europe ... Last seen ...") from leaking into the category name.
    const bonuses:DailyProductionBonus[]=[];
    const cardRe=/Production bonus\s+([A-Za-z][A-Za-z '&-]{0,40}?)\s+\+(10|20)%\s+Best (?:craft|refin(?:e|ing)) city\s+([A-Za-z ]{2,30}?)\s+\+\d+%/gi;
    let m:RegExpExecArray|null;
    while((m=cardRe.exec(text))!==null){
      let category=m[1].trim().replace(/\s+/g," ");
      const bonus=Number(m[2]),city=m[3].trim().replace(/\s+/g," ");
      // Last-resort cleanup for source text duplicated before the first card.
      category=category.replace(/^.*?Production bonus\s+/i,"").trim();
      if(category.length<=40&&!bonuses.some(x=>x.category.toLowerCase()===category.toLowerCase()))
        bonuses.push({category,bonus,city});
      if(bonuses.length>=2)break;
    }

    // Fallback with a strict known-category vocabulary rather than an open-ended capture.
    if(!bonuses.length){
      const known=["Ore","Wood","Hide","Fiber","Stone","Metal Bar","Plank","Leather","Cloth","Stone Block","Potion","Food","Sword","Bow","Arcane Staff","Axe","Quarterstaff","Frost Staff","Mace","Fire Staff","Nature Staff","Hammer","Spear","Holy Staff","Crossbow","Dagger","Cursed Staff","War Gloves","Shapeshifter Staff","Off-hand","Bag","Cape","Plate Helmet","Plate Armor","Plate Boots","Leather Helmet","Leather Armor","Leather Shoes","Cloth Cowl","Cloth Robe","Cloth Sandals"];
      for(const category of known){
        const hit=text.match(new RegExp(`Production bonus\\s+${category.replace(/[.*+?^${}()|[\\]\\]/g,"\\$&")}\\s+\\+(10|20)%`,"i"));
        if(hit)bonuses.push({category,bonus:Number(hit[1])});
        if(bonuses.length>=2)break;
      }
    }
    const dateMatch=text.match(/Daily Production Bonus Europe\s+(.+?)\s+resets/i);
    const resetMatch=text.match(/resets\s+([0-9:]+\s+UTC)/i);
    const seenMatch=text.match(/Last seen\s+(.+?)(?=\s+Production bonus)/i);
    const dateLabel=dateMatch?.[1]?.trim();
    const resetLabel=resetMatch?.[1]?.trim();
    const lastSeen=seenMatch?.[1]?.trim()?.split(" · ").map(x=>x.trim()).filter(Boolean);

    const events:{title:string;detail?:string;time?:string}[]=[];
    const evSection=html.split("Daily events")[1]??"";
    const evText=clean(evSection);
    const bandit=evText.match(/(ends in\s+[^ ]+).*?Bandit Assault advances\s+(.+?)(?=\d+d\s+\d+h left|Gathering Bonus|Bonus Islands|$)/i);
    if(bandit)events.push({title:"Bandit Assault advances",time:bandit[1],detail:bandit[2].trim()});
    const gathering=evText.match(/(\d+d\s+\d+h left).*?Gathering Bonus:\s*([^+]+?)\s+\+(\d+)%\s+([^!]+!)/i);
    if(gathering)events.push({title:`Gathering Bonus: ${gathering[2].trim()}`,time:gathering[1],detail:`+${gathering[3]}% ${gathering[4].trim()}`});

    return {bonuses,source:SRC,updatedAt:new Date().toISOString(),available:bonuses.length>0,dateLabel,resetLabel,lastSeen,events};
  }catch{
    return {bonuses:[],source:SRC,updatedAt:new Date().toISOString(),available:false};
  }
}

const norm=(s:string)=>s.toLowerCase().replace(/[^a-z0-9]/g,"");

export function dailyBonusForItem(
  id:string,
  shopcategory?:string,
  subcategory?:string,
  bonuses:DailyProductionBonus[]=[]
){
  const I=id.toUpperCase(),cat=norm(shopcategory??""),sub=norm(subcategory??"");

  const matches=(label:string)=>{
    const l=norm(label);

    // Armour slots / materials
    if((l==="clothcowl"||l==="clothhelmet")&&I.includes("HEAD_CLOTH"))return true;
    if((l==="clothrobe"||l==="clotharmor")&&I.includes("ARMOR_CLOTH"))return true;
    if((l==="clothsandals"||l==="clothshoes")&&I.includes("SHOES_CLOTH"))return true;
    if((l==="leatherhood"||l==="leatherhelmet")&&I.includes("HEAD_LEATHER"))return true;
    if((l==="leatherjacket"||l==="leatherarmor")&&I.includes("ARMOR_LEATHER"))return true;
    if((l==="leathershoes"||l==="leatherboots")&&I.includes("SHOES_LEATHER"))return true;
    if((l==="platehelmet"||l==="platehelm")&&I.includes("HEAD_PLATE"))return true;
    if((l==="platearmor"||l==="platechest")&&I.includes("ARMOR_PLATE"))return true;
    if((l==="plateboots"||l==="plateshoes")&&I.includes("SHOES_PLATE"))return true;
    if((l==="offhand"||l==="offhands")&&I.includes("OFF_"))return true;
    if((l==="bag"||l==="bags")&&I.includes("BAG"))return true;
    if((l==="cape"||l==="capes")&&I.includes("CAPE"))return true;

    // Weapon families - compare to ao-bin shop subcategory.
    const fam:Record<string,string[]>={
      sword:["sword"],bow:["bow"],arcanestaff:["arcanestaff","arcane"],
      axe:["axe"],quarterstaff:["quarterstaff"],froststaff:["froststaff","frost"],
      mace:["mace"],firestaff:["firestaff","fire"],naturestaff:["naturestaff","nature"],
      hammer:["hammer"],spear:["spear"],holystaff:["holystaff","holy"],
      crossbow:["crossbow"],dagger:["dagger"],cursestaff:["cursestaff","curse"],
      wargloves:["knuckles","wargloves"],shapeshifterstaff:["shapeshifterstaff","shapeshifter"]
    };
    for(const [key,vals] of Object.entries(fam)){
      if(l===key||vals.some(v=>l===norm(v))){
        if(vals.some(v=>sub.includes(norm(v))))return true;
      }
    }

    // Refining / consumables / broad categories for future modules.
    if(["ore","metalbar","metalbars"].includes(l)&&(cat.includes("metal")||I.includes("_METALBAR")))return true;
    if(["wood","plank","planks"].includes(l)&&(cat.includes("wood")||I.includes("_PLANKS")))return true;
    if(["hide","leather"].includes(l)&&(cat.includes("hide")||cat.includes("leather")||I.includes("_LEATHER")))return true;
    if(["fiber","cloth"].includes(l)&&(cat.includes("fiber")||cat.includes("cloth")||I.includes("_CLOTH")))return true;
    if(["stone","stoneblock","stoneblocks"].includes(l)&&(cat.includes("stone")||I.includes("_STONEBLOCK")))return true;
    if(["potion","potions"].includes(l)&&(cat.includes("potion")||I.includes("_POTION_")))return true;
    if(["food","meal","meals"].includes(l)&&(cat.includes("food")||I.includes("_MEAL_")))return true;

    return false;
  };

  return bonuses.find(b=>matches(b.category))?.bonus??0;
}
