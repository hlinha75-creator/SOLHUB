export type ItemLanguage="pt-BR"|"en";

export function itemLanguage(raw:string|null|undefined):ItemLanguage{
  return raw==="en"?"en":"pt-BR";
}

export function localizedItemName(row:any,lang:ItemLanguage){
  const names=row?.LocalizedNames??{};
  if(lang==="pt-BR"){
    return names["PT-BR"]??names["PT"]??names["EN-US"]??names["EN"]??row?.UniqueName??"";
  }
  return names["EN-US"]??names["EN"]??names["PT-BR"]??row?.UniqueName??"";
}

export function buildLocalizedNameMap(rows:any[],lang:ItemLanguage){
  const map=new Map<string,string>();
  for(const row of rows??[]){
    const id=String(row?.UniqueName??"");
    if(!id)continue;
    const name=localizedItemName(row,lang)||id;
    const aliases=new Set<string>([id]);

    // ao-bin/raw recipes and the market API can represent enchanted resources
    // as LEVELx, @x, or LEVELx@x. Index every equivalent spelling.
    const level=id.match(/_LEVEL([1-4])(?:@([1-4]))?$/);
    if(level){
      const lv=level[1];
      const stem=id.replace(/_LEVEL[1-4](?:@[1-4])?$/,"");
      aliases.add(`${stem}_LEVEL${lv}`);
      aliases.add(`${stem}_LEVEL${lv}@${lv}`);
      aliases.add(`${stem}@${lv}`);
    }
    const at=id.match(/@([1-4])$/);
    if(at){
      const lv=at[1];
      const stem=id.replace(/@[1-4]$/,"").replace(/_LEVEL[1-4]$/,"");
      aliases.add(`${stem}@${lv}`);
      aliases.add(`${stem}_LEVEL${lv}`);
      aliases.add(`${stem}_LEVEL${lv}@${lv}`);
    }

    for(const key of aliases)map.set(key,name);
  }
  return map;
}
