"use client";
import {itemImageUrl} from "../../lib/itemImage";
import {itemMatchesSearch} from "../../lib/itemSearch";

import LanguageSelector from "../components/LanguageSelector";
import AppSidebar from "../components/AppSidebar";


import Link from "next/link";
import {useEffect,useMemo,useRef,useState} from "react";
import {currentSiteLanguage} from "../../lib/languageClient";
import {calculatedFceForFamily,calculatedQualityPointsForFamily,mutualFcePerLevel,mutualQualityPerLevel,uniqueFcePerLevel,uniqueQualityPerLevel,masteryFcePerLevel,masteryQualityPerLevel,type CraftFamily} from "../../lib/specializationModel";
import {exportSpecializationProfile,importSpecializationProfile,loadCraftingProfile,saveMastery,saveSpec,type CraftingProfileV2} from "../../lib/focusClient";

type CatalogItem={id:string;baseId:string;name:string};
type CatalogGroup=CraftFamily&{items:CatalogItem[]};
type Filter="all"|"weapon"|"armor"|"offhand"|"gathering"|"bag"|"cape"|"potion"|"food"|"refining";
const imageItemId=(id:string)=>{
  // Spec catalog nodes are normalized (e.g. BOW, ARMOR_CLOTH_SET1).
  // Render Service needs an actual tiered item identifier.
  if(/^T\d+_/i.test(id))return id;
  if(id==="CAPE")return "T8_CAPE";
  return `T8_${id}`;
};
const img=(id:string)=>itemImageUrl(imageItemId(id),{size:72});

export default function SpecializationsPage(){
  const [lang,setLang]=useState<"pt-BR"|"en">("en");
  const [profile,setProfile]=useState<CraftingProfileV2|null>(null);
  const [groups,setGroups]=useState<CatalogGroup[]>([]);
  const [filter,setFilter]=useState<Filter>("all");
  const [search,setSearch]=useState("");
  const [open,setOpen]=useState<string[]>([]);
  const [notice,setNotice]=useState("");
  const fileRef=useRef<HTMLInputElement|null>(null);

  useEffect(()=>{const current=currentSiteLanguage();setLang(current);setProfile(loadCraftingProfile());fetch(`/api/spec-catalog?lang=${encodeURIComponent(current)}`,{cache:"no-store"}).then(r=>r.json()).then(j=>setGroups(j.groups??[])).catch(()=>setGroups([]))},[]);
  function refresh(){setProfile(loadCraftingProfile())}
  function flash(t:string){setNotice(t);setTimeout(()=>setNotice(""),1800)}
  function toggle(id:string){setOpen(x=>x.includes(id)?x.filter(v=>v!==id):[...x,id])}
  function setMastery(id:string,v:number){saveMastery(id,v);refresh()}
  function setNode(g:string,id:string,v:number){saveSpec(g,id,v);refresh()}

  const shown=useMemo(()=>{
    const q=search.trim();
    return groups.filter(g=>(filter==="all"||g.type===filter)&&(!q||g.name.toLowerCase().includes(q.toLowerCase())||g.items.some(i=>itemMatchesSearch(i.id,i.name,q))));
  },[groups,filter,search]);

  const stats=useMemo(()=>profile?{
    trees:Object.values(profile.masteries).filter(v=>v>0).length,
    specs:Object.values(profile.specs).filter(v=>v>0).length,
    maxed:Object.values(profile.specs).filter(v=>v>=100).length
  }:{trees:0,specs:0,maxed:0},[profile]);

  const ui=lang==="en"?{
    loading:"Loading profile…",title:"Specializations",hero:"Replicate your Destiny Board tree: family General Spec + each product's individual Spec.",active:"ACTIVE PROFILE",local:"Local profile",localHint:"Stored in this browser and ready for future Discord linking.",soon:"DISCORD • COMING SOON",configured:"configured",products:"products configured",maxed:"maxed specializations",trees:"Crafting Trees",treesHint:"The General Tree benefits the whole family. Each individual Spec gives the largest bonus to its own product and a smaller bonus to the other items in the same tree.",search:"Search item, e.g. Bag T6.1…",export:"⇩ Export",import:"⇧ Import",imported:"Profile imported.",incompatible:"Incompatible profile.",loadingCatalog:"Loading Albion trees and products…",specsConfigured:"Specs configured",focusPerLevel:"Focus Efficiency / level",tree:"tree",refineChain:"refining chain",qualityOwn:"own",qualityTree:"tree",focusTotal:"Total Focus Efficiency",all:"All",weapons:"⚔ Weapons",armor:"🛡 Armor",gathering:"⛏ Gathering Gear",bags:"🎒 Bags",capes:"🦸 Capes",potions:"🧪 Potions",food:"🍲 Food",refining:"♻️ Refining",
    generalText:"Bow Crafter, Dagger Crafter, Chef, Alchemist, Torch/Tome/Shield, gathering gear, bags, capes and T4–T8 refining chains. Each tree uses its own Destiny Board coefficients.",
    specText:"Each weapon, armor piece, off-hand, gathering gear piece, bag, food or potion has its own Spec. In refining, each material has separate T4–T8 Specs; each level gives +250 Focus Efficiency to its own Tier and +30 to the other Tiers in the same chain. Cape uses its own Cape Crafting node. In Chef and Alchemist, each individual Spec also gives a mutual bonus to the other products. In Alchemist, base potions give +22.5 Focus Efficiency/level to the tree and specialized/artifact potions give +11.25.",
    qualityTitle:"Equipment quality",qualityText:"For weapons, armor, off-hands, gathering gear, bags and capes, Mastery and Specs also increase Quality Points, improving the chances of Good, Outstanding, Excellent and Masterpiece quality.",qualityNotice:"Quality is already part of the profile",qualityNoticeText:"SOL HUB calculates the Quality Points produced by your Specs for weapons, armor, off-hands, gathering gear, bags and capes. We do not yet convert these points into an exact percentage for each quality or use them in expected profit, so we do not invent probabilities.",discordTitle:"Discord login will be implemented soon",discordText:"The crafting profile will be linked to the member account and permissions may follow the guild server roles."
  }:{
    loading:"A carregar perfil…",title:"Especializações",hero:"Replica a tua árvore do Destiny Board: General Spec da família + Spec individual de cada produto.",active:"PERFIL ATIVO",local:"Perfil local",localHint:"Persistente neste browser e preparado para associação ao Discord.",soon:"DISCORD • BREVEMENTE",configured:"configuradas",products:"produtos configurados",maxed:"especializações maxed",trees:"Árvores de Crafting",treesHint:"A General Tree beneficia toda a família. Cada Spec individual dá o maior bónus ao próprio produto e um bónus menor aos restantes itens da mesma árvore.",search:"Procurar item, ex. Bag T6.1…",export:"⇩ Exportar",import:"⇧ Importar",imported:"Perfil importado.",incompatible:"Perfil incompatível.",loadingCatalog:"A carregar árvores e produtos do Albion…",specsConfigured:"Specs configuradas",focusPerLevel:"Eficiência de Focus / nível",tree:"árvore",refineChain:"cadeia de refino",qualityOwn:"próprio",qualityTree:"árvore",focusTotal:"Eficiência de Focus total",all:"Todos",weapons:"⚔ Armas",armor:"🛡 Armaduras",gathering:"⛏ Gear Coleta",bags:"🎒 Bags",capes:"🦸 Capes",potions:"🧪 Poções",food:"🍲 Comida",refining:"♻️ Refino",
    generalText:"Bow Crafter, Dagger Crafter, Chef, Alchemist, Torch/Tome/Shield, gathering gear, bags, capes e cadeias de refino T4–T8. Cada árvore usa os coeficientes próprios do Destiny Board.",
    specText:"Cada arma, peça de armadura, off-hand, peça de gear de coleta, bag, comida ou poção tem a sua Spec. No refino, cada material tem Specs separadas de T4 a T8; cada nível dá +250 de Eficiência de Focus ao próprio Tier e +30 aos restantes Tiers da mesma cadeia. Cape usa o seu nó próprio de Cape Crafting. Em Chef e Alchemist, cada Spec individual também dá bónus mútuo aos restantes produtos. Em Alchemist, as poções base dão +22,5 de Eficiência de Focus/nível à árvore e as poções especializadas/artefacto dão +11,25.",
    qualityTitle:"Qualidade do equipamento",qualityText:"Nas armas, armaduras, off-hands, gathering gear, bags e capes, Mastery e Specs também aumentam os Quality Points, que melhoram as probabilidades de obter Good, Outstanding, Excellent e Masterpiece.",qualityNotice:"Qualidade já faz parte do perfil",qualityNoticeText:"O Consultor calcula os Quality Points resultantes das tuas Specs para armas, armaduras, off-hands, gathering gear, bags e capes. Ainda não convertemos estes pontos numa percentagem exata de cada qualidade nem os usamos no lucro esperado, para não inventar probabilidades.",discordTitle:"Login Discord será implementado brevemente",discordText:"O perfil de crafting será associado à conta do membro e as permissões poderão seguir as roles do servidor da guilda."
  };

  if(!profile)return <main className="shell"><AppSidebar/><p>{ui.loading}</p></main>;

  return <main className="shell specializationShell"><AppSidebar/>
    <header className="hero specializationHero">
      <div><div className="eyebrow">NOTAG • DESTINY BOARD PROFILE</div><h1>{ui.title} <span>Sol</span></h1>
      <p>{ui.hero}</p></div>
      
    <div className="headerTools"><LanguageSelector/></div></header>

    <section className="specOverviewV2">
      <article className="specIdentity"><div className="specIdentityIcon">⚙</div><div><span className="specOverline">{ui.active}</span><h2>{ui.local}</h2><p>{ui.localHint}</p></div><span className="specSoon">{ui.soon}</span></article>
      <article><span>General Trees</span><strong>{stats.trees}</strong><small>{ui.configured}</small></article>
      <article><span>Specs</span><strong>{stats.specs}</strong><small>{ui.products}</small></article>
      <article><span>100 Spec</span><strong>{stats.maxed}</strong><small>{ui.maxed}</small></article>
    </section>

    <section className="specTreePanel">
      <div className="specTreeToolbar">
        <div><span className="specOverline">DESTINY BOARD</span><h2>{ui.trees}</h2>
        <p>{ui.treesHint}</p></div>
        <div className="specToolbarActions">
          <div className="specTreeSearch">⌕ <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={ui.search}/></div>
          <button onClick={()=>{const b=new Blob([exportSpecializationProfile()],{type:"application/json"});const u=URL.createObjectURL(b);const a=document.createElement("a");a.href=u;a.download="consultor-sol-crafting-profile.json";a.click();URL.revokeObjectURL(u)}}>{ui.export}</button>
          <button onClick={()=>fileRef.current?.click()}>{ui.import}</button>
          <input ref={fileRef} type="file" accept="application/json" hidden onChange={async e=>{const f=e.target.files?.[0];if(!f)return;try{importSpecializationProfile(await f.text());refresh();flash(ui.imported)}catch{flash(ui.incompatible)}e.currentTarget.value=""}}/>
        </div>
      </div>

      <div className="specFilterPills">
        {([["all",ui.all],["weapon",ui.weapons],["armor",ui.armor],["offhand","◈ Off-hands"],["gathering",ui.gathering],["bag",ui.bags],["cape",ui.capes],["potion",ui.potions],["food",ui.food],["refining",ui.refining]] as [Filter,string][]).map(([id,label])=><button key={id} className={filter===id?"active":""} onClick={()=>setFilter(id)}>{label}</button>)}
      </div>

      {!groups.length&&<div className="specCatalogLoading">{ui.loadingCatalog}</div>}
      <div className="specTreeList">
        {shown.map(g=>{
          const mastery=profile.masteries[g.id]??0,isOpen=open.includes(g.id)||!!search;
          const filled=g.items.filter(i=>(profile.specs[`${g.id}:${i.baseId}`]??0)>0).length;
          return <article className={`specFamily ${isOpen?"open":""}`} key={g.id}>
            <button className="specFamilyHead" onClick={()=>toggle(g.id)}>
              <span className="specFamilyIcon">{g.icon}</span>
              <span className="specFamilyName"><b>{g.name}</b><small>{filled}/{g.items.length} {ui.specsConfigured}</small></span>
              {g.type==="refining"?<span className="specMasterySummary"><small>REFINING SPECS</small><b>{filled}/{g.items.length}</b></span>:<span className="specMasterySummary"><small>GENERAL SPEC</small><b>{mastery}/100</b></span>}
              <span className="specChevron">{isOpen?"−":"+"}</span>
            </button>
            {isOpen&&<div className="specFamilyBody">
              {g.type!=="refining"&&<div className="specGeneralRow">
                <div><span className="specNodeBadge general">GENERAL</span><b>{g.name}</b>
                  <small>+{masteryFcePerLevel(g)} {ui.focusPerLevel}{masteryQualityPerLevel(g)>0?` • +${masteryQualityPerLevel(g)} Quality Points / ${lang==="en"?"level":"nível"}`:""}</small>
                </div>
                <Level value={mastery} onChange={v=>setMastery(g.id,v)}/>
              </div>}

              <div className="specNodesGrid">
                {g.items.filter(i=>!search||itemMatchesSearch(i.id,i.name,search)||g.name.toLowerCase().includes(search.toLowerCase())).map(item=>{
                  const level=profile.specs[`${g.id}:${item.baseId}`]??0;
                  const fce=calculatedFceForFamily(item.id,g,profile),qp=calculatedQualityPointsForFamily(item.id,g,profile);
                  const qMut=mutualQualityPerLevel(item.id,g),qUnique=uniqueQualityPerLevel(g,item.id);
                  return <article className="specNodeCard" key={item.baseId}>
                    <img src={img(item.id)} alt={item.name}/>
                    <div className="specNodeInfo"><span className="specNodeBadge">SPEC</span><b>{item.name}</b>
                      <small>+{uniqueFcePerLevel(item.id,g)} {lang==="en"?"own Focus Efficiency":"Eficiência de Focus própria"} • +{mutualFcePerLevel(item.id,g)} {g.type==="refining"?ui.refineChain:ui.tree} / {lang==="en"?"level":"nível"}</small>
                      {(["weapon","armor","offhand","gathering","bag","cape"].includes(g.type))&&<small className="qualityHint">{lang==="en"?"Quality":"Qualidade"}: +{qUnique} {ui.qualityOwn} • +{qMut} {ui.qualityTree} / {lang==="en"?"level":"nível"}</small>}
                    </div>
                    <div className="specCalculated">
                      <span>{ui.focusTotal}</span><b>{fce.toLocaleString("pt-PT")}</b>
                      {(["weapon","armor","offhand","gathering","bag","cape"].includes(g.type))&&<><span>Quality Points</span><b className="qualityValue">{qp.toLocaleString("pt-PT")}</b></>}
                    </div>
                    <Level value={level} onChange={v=>setNode(g.id,item.baseId,v)}/>
                  </article>
                })}
              </div>
            </div>}
          </article>
        })}
      </div>
    </section>

    <section className="specExplainGrid">
      <article><span>1</span><div><b>General Tree</b><p>{ui.generalText}</p></div></article>
      <article><span>2</span><div><b>{lang==="en"?"Individual Spec":"Spec individual"}</b><p>{ui.specText}</p></div></article>
      <article><span>3</span><div><b>{ui.qualityTitle}</b><p>{ui.qualityText}</p></div></article>
    </section>

    <section className="qualityNotice">
      <span>✦</span><div><b>{ui.qualityNotice}</b><p>{ui.qualityNoticeText}</p></div>
    </section>

    <section className="discordReadyBar"><div className="discordMark">◈</div><div><b>{ui.discordTitle}</b><span>{ui.discordText}</span></div><span className="discordFuture">{ui.soon}</span></section>
    {notice&&<div className="specNotice fixedNotice">{notice}</div>}
  </main>
}

function Level({value,onChange}:{value:number;onChange:(v:number)=>void}){
  return <div className="specLevelControl">
    <button onClick={()=>onChange(Math.max(0,value-1))}>−</button>
    <input type="number" min="0" max="100" value={value} onChange={e=>onChange(Math.max(0,Math.min(100,Number(e.target.value)||0)))}/>
    <button onClick={()=>onChange(Math.min(100,value+1))}>+</button>
    <div className="specLevelBar"><i style={{width:`${value}%`}}/></div>
  </div>
}