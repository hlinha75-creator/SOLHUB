"use client";
import {itemImageUrl} from "../lib/itemImage";
import LanguageSelector from "./components/LanguageSelector";
import AppSidebar from "./components/AppSidebar";
import WatchlistButton from "./components/WatchlistButton";


import {currentSiteLanguage} from "../lib/languageClient";

import Link from "next/link";
import {useEffect,useState} from "react";
import {useSolHubSettings} from "../lib/settingsClient";
import {ageText,dataHealthLabel,dataHealthLevel} from "../lib/dataHealth";
import {marketRecommendation} from "../lib/solRecommendations";
import {conditionLabel,intelligenceBand,type IntelligenceCondition} from "../lib/solIntelligence";
import {WATCHLIST_EVENT,loadWatchlist} from "../lib/watchlistClient";
import {PORTFOLIO_EVENT,loadPortfolio} from "../lib/portfolioClient";
import {loadAlerts,loadAlertNotifications,evaluateAlerts} from "../lib/alertsClient";

type Bonus={category:string;bonus:number;city?:string};
type Event={title:string;detail?:string;time?:string};
type BonusItem={id:string;name:string;kind?:string};
type TodayData={
  bonuses:Bonus[];available:boolean;dateLabel?:string;resetLabel?:string;
  lastSeen?:string[];events?:Event[];updatedAt?:string;
};

type DashboardFlip={
 itemId:string;itemName:string;quality:number;qualityName:string;
 buyCity:string;sellCity:string;buyPrice:number;sellPrice:number;fees:number;
 profit:number;roi:number;buyAgeMin:number;sellAgeMin:number;score:number;
 recommendedQty:number;recommendedInvestment:number;recommendedProfit:number;
 avgDailyVolume:number;liquidity:"Alta"|"Média"|"Baixa"|"Sem dados";
 risk:"Baixo"|"Médio"|"Alto";volatilityPct:number;priceDeviationPct:number;
 intelligenceScore:number;entryAdvantagePct:number;trendPct:number;marketCondition:IntelligenceCondition;
};
type DashboardFlipResult={flips:DashboardFlip[];error?:string};

const silver=new Intl.NumberFormat("pt-PT");
const money=(n:number)=>silver.format(Math.round(n||0));

function dashboardOpportunityScore(f:DashboardFlip){
 const age=Math.max(f.buyAgeMin,f.sellAgeMin);
 const investment=f.recommendedInvestment>0?f.recommendedInvestment:f.buyPrice;
 const capitalScore=Math.max(0,100-Math.min(100,investment/300000*100));
 const freshnessScore=Math.max(0,100-Math.min(100,age/120*100));
 const liquidityScore=f.liquidity==="Alta"?100:f.liquidity==="Média"?72:f.liquidity==="Baixa"?32:0;
 const roiScore=Math.min(100,Math.max(0,f.roi)*4);
 const profitScore=Math.min(100,Math.max(0,f.recommendedProfit||f.profit)/30000*100);
 const conservativeScore=capitalScore*.34+freshnessScore*.24+liquidityScore*.20+roiScore*.14+profitScore*.08;
 return conservativeScore*.65+(f.intelligenceScore??0)*.35;
}

const specialties=[
 {city:"Bridgewatch",items:"Crossbows • Daggers • Cursed • Plate Armor • Cloth Shoes"},
 {city:"Martlock",items:"Axes • Quarterstaffs • Frost • Plate Shoes • Off-hands"},
 {city:"Lymhurst",items:"Swords • Bows • Arcane • Leather Helmets • Leather Shoes"},
 {city:"Thetford",items:"Maces • Fire • Nature • Leather Armor • Cloth Helmets"},
 {city:"Fort Sterling",items:"Hammers • Spears • Holy • Cloth Armor • Plate Helmets"},
 {city:"Caerleon",items:"War Gloves • Shapeshifter • Gathering Gear"},
 {city:"Brecilien",items:"Bags • Capes"}
];


const itemRender=(id:string,size=64)=>itemImageUrl(id,{size});
const dailyBonusTypeLabel=(category:string,lang:"pt-BR"|"en")=>{
  const c=category.toLowerCase().trim();
  const refining=["ore","wood","hide","fiber","stone","metal bar","plank","leather","cloth","stone block"];
  if(lang==="en")return refining.includes(c)?"DAILY REFINING BONUS":"DAILY CRAFTING BONUS";
  return refining.includes(c)?"BÔNUS DIÁRIO DE REFINO":"BÔNUS DIÁRIO DE CRAFT";
};

const bonusFallbackImageId=(category:string)=>{
  const c=category.toLowerCase().trim();
  const map:Record<string,string>={
    "ore":"T8_ORE","metal bar":"T8_METALBAR","wood":"T8_WOOD","plank":"T8_PLANKS",
    "hide":"T8_HIDE","leather":"T8_LEATHER","fiber":"T8_FIBER","cloth":"T8_CLOTH",
    "stone":"T8_ROCK","stone block":"T8_STONEBLOCK",
    "potion":"T8_POTION_HEAL","food":"T8_MEAL_STEW",
    "sword":"T8_MAIN_SWORD","bow":"T8_2H_BOW","arcane staff":"T8_MAIN_ARCANESTAFF",
    "axe":"T8_MAIN_AXE","quarterstaff":"T8_2H_QUARTERSTAFF","frost staff":"T8_MAIN_FROSTSTAFF",
    "mace":"T8_MAIN_MACE","fire staff":"T8_MAIN_FIRESTAFF","nature staff":"T8_MAIN_NATURESTAFF",
    "hammer":"T8_MAIN_HAMMER","spear":"T8_MAIN_SPEAR","holy staff":"T8_MAIN_HOLYSTAFF",
    "crossbow":"T8_2H_CROSSBOW","dagger":"T8_MAIN_DAGGER","cursed staff":"T8_MAIN_CURSEDSTAFF",
    "war gloves":"T8_2H_KNUCKLES_SET1","shapeshifter staff":"T8_2H_SHAPESHIFTER_SET1",
    "off-hand":"T8_OFF_TORCH","bag":"T8_BAG","cape":"T8_CAPE",
    "plate helmet":"T8_HEAD_PLATE_SET1","plate armor":"T8_ARMOR_PLATE_SET1","plate boots":"T8_SHOES_PLATE_SET1",
    "leather helmet":"T8_HEAD_LEATHER_SET1","leather armor":"T8_ARMOR_LEATHER_SET1","leather shoes":"T8_SHOES_LEATHER_SET1",
    "cloth cowl":"T8_HEAD_CLOTH_SET1","cloth robe":"T8_ARMOR_CLOTH_SET1","cloth sandals":"T8_SHOES_CLOTH_SET1"
  };
  return map[c] ?? "T8_BAG";
};

const eventImageId=(title:string)=>{
  const t=title.toLowerCase();
  if(t.includes("bandit"))return "T8_CAPEITEM_FW_CAERLEON";
  if(t.includes("ore")||t.includes("mining"))return "T8_ORE";
  if(t.includes("wood")||t.includes("logging"))return "T8_WOOD";
  if(t.includes("hide")||t.includes("skinning"))return "T8_HIDE";
  if(t.includes("fiber")||t.includes("harvest"))return "T8_FIBER";
  if(t.includes("stone")||t.includes("quarry"))return "T8_ROCK";
  if(t.includes("gathering"))return "T8_TOOL_PICK";
  return "T8_JOURNAL_GENERAL";
};

export default function Home(){
 const {settings}=useSolHubSettings();
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 const [data,setData]=useState<TodayData|null>(null);
 const [bonusItems,setBonusItems]=useState<Record<string,BonusItem[]>>({});
 const [dailyPick,setDailyPick]=useState<DashboardFlip|null>(null);
 const [pickLoading,setPickLoading]=useState(true);
 const [pickError,setPickError]=useState("");
 const [trackedVersion,setTrackedVersion]=useState(0);
 const [radar,setRadar]=useState({improving:0,strong:0,near:0,deteriorating:0,unread:0});
 useEffect(()=>{
   setLang(currentSiteLanguage());
   fetch("/api/daily-bonus").then(r=>r.json()).then(setData).catch(()=>setData({bonuses:[],available:false}));
   const refreshTracked=()=>setTrackedVersion(v=>v+1);
   window.addEventListener(WATCHLIST_EVENT,refreshTracked);
   window.addEventListener(PORTFOLIO_EVENT,refreshTracked);
   window.addEventListener("storage",refreshTracked);
   return()=>{window.removeEventListener(WATCHLIST_EVENT,refreshTracked);window.removeEventListener(PORTFOLIO_EVENT,refreshTracked);window.removeEventListener("storage",refreshTracked)};
 },[]);

 useEffect(()=>{
  let alive=true;
  const q=new URLSearchParams({
   buyCity:"all",sellCity:"all",category:"all",tiers:"4,5,6",enchants:"0,1",
   maxAgeHours:"2",minRoi:"8",minProfit:"1000",capital:"500000",
   premium:String(settings.premium),maxAllocationPct:"30",maxDailyVolumePct:"15",
   saleMode:settings.saleMode,lang
  });
  setPickLoading(true);setPickError("");
  fetch(`/api/flips?${q}`)
   .then(async r=>{const j:DashboardFlipResult=await r.json();if(!r.ok)throw Error(j.error??"Falha ao procurar oportunidade.");return j})
   .then(j=>{
    if(!alive)return;
    const watched=loadWatchlist();
    const portfolio=loadPortfolio();
    const isAlreadyTracked=(f:DashboardFlip)=>{
      const route=`${f.buyCity} → ${f.sellCity}`;
      return watched.some(x=>x.type==="FLIP"&&x.itemId===f.itemId&&x.route===route)
        || portfolio.some(x=>x.type==="FLIP"&&x.itemId===f.itemId&&(x.route??"")===route);
    };
    const available=(j.flips??[]).filter(f=>!isAlreadyTracked(f));
    const conservative=available
      .filter(f=>f.risk==="Baixo"&&Math.max(f.buyAgeMin,f.sellAgeMin)<=120&&f.avgDailyVolume>=5)
      .filter(f=>(f.recommendedInvestment||f.buyPrice)<=300000)
      .sort((a,b)=>dashboardOpportunityScore(b)-dashboardOpportunityScore(a));
    const fallback=available
      .filter(f=>f.risk==="Baixo"&&Math.max(f.buyAgeMin,f.sellAgeMin)<=120)
      .sort((a,b)=>dashboardOpportunityScore(b)-dashboardOpportunityScore(a));
    setDailyPick(conservative[0]??fallback[0]??null);
   })
   .catch(e=>{if(alive){setDailyPick(null);const msg=e instanceof Error?e.message:"Erro inesperado.";setPickError(lang==="en"&&msg.includes("demasiados pedidos")?"Albion Data is temporarily receiving too many requests. Wait a few seconds and try again.":msg)}})
   .finally(()=>{if(alive)setPickLoading(false)});
  return()=>{alive=false};
 },[settings.premium,settings.saleMode,lang,trackedVersion]);

 useEffect(()=>{
  let alive=true;const watched=loadWatchlist().filter(x=>x.type==="FLIP");if(!watched.length){setRadar({improving:0,strong:0,near:0,deteriorating:0,unread:loadAlertNotifications().filter(x=>!x.read).length});return}
  fetch("/api/watchlist/quotes",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({entries:watched,premium:settings.premium,saleMode:settings.saleMode})}).then(r=>r.json()).then(j=>{if(!alive)return;const q=j.quotes??{};evaluateAlerts(loadAlerts(),Object.fromEntries(watched.map(x=>[x.id,x])),q);let improving=0,strong=0,near=0,deteriorating=0;for(const x of watched){const now=q[x.id]?.currentIntelligenceScore,saved=x.intelligenceScore;if(now!=null&&saved!=null){if(now-saved>=8)improving++;if(now-saved<=-8)deteriorating++;if(now>=85)strong++;else if(now>=78)near++;}}setRadar({improving,strong,near,deteriorating,unread:loadAlertNotifications().filter(x=>!x.read).length})}).catch(()=>{});return()=>{alive=false}
 },[trackedVersion,settings.premium,settings.saleMode]);

 useEffect(()=>{
   if(!data?.available||!data.bonuses?.length)return;
   let alive=true;
   Promise.all(data.bonuses.map(async b=>{
     try{
       const r=await fetch(`/api/daily-bonus-items?category=${encodeURIComponent(b.category)}&lang=${encodeURIComponent(lang)}`);
       const j=await r.json();
       return [b.category,Array.isArray(j?.items)?j.items:[]] as const;
     }catch{return [b.category,[]] as const}
   })).then(entries=>{if(alive)setBonusItems(Object.fromEntries(entries))});
   return()=>{alive=false};
 },[data,lang]);

 const ui=lang==="en"?{
  online:"Market intelligence online",title:"A conservative opportunity to start right now",tag:"Low capital • Low risk • Europe",
  searching:"Sol is looking for a safe flip…",validating:"Checking capital, liquidity, return and data freshness.",
  lowRisk:"LOW RISK FLIP",risk:"Low risk",buy:"Buy in",sell:"Sell in",investment:"Investment",profit:"Estimated profit",
  return:"Return",liquidity:"Liquidity",marketData:"Market Data",view:"View opportunity",
  empty:"No Low Risk Flip meets the criteria right now.",emptyText:"SOL would rather show nothing than recommend a weak opportunity just to fill the space.",
  open:"Open Market Scanner",quick:"QUICK ACTIONS",quickHint:"Your tools are still always within reach.",
  scanMarket:"Scan market routes",calcCraft:"Calculate a craft",calcRefine:"Calculate a refine",allocate:"Allocate capital",
  follow:"Follow opportunities",track:"Track performance",units:"units",perUnit:"/ unit",
  reason:(liq:string)=>`Selected by SOL: low starting capital, ${liq.toLowerCase()} liquidity, healthy margin and recent prices.`
 }:{
  online:"Inteligência de mercado online",title:"Uma oportunidade conservadora para começar agora",tag:"Pouco capital • Baixo risco • Europe",
  searching:"O Sol está procurando um flip seguro…",validating:"Validando capital, liquidez, rentabilidade e atualização dos dados.",
  lowRisk:"FLIP DE BAIXO RISCO",risk:"Baixo risco",buy:"Comprar em",sell:"Vender em",investment:"Investimento",profit:"Lucro estimado",
  return:"Rentabilidade",liquidity:"Liquidez",marketData:"Dados de mercado",view:"Ver oportunidade",
  empty:"Nenhum Flip de Baixo Risco atende aos critérios neste momento.",emptyText:"O SOL prefere não recomendar uma oportunidade fraca apenas para preencher espaço.",
  open:"Abrir Market Scanner",quick:"AÇÕES RÁPIDAS",quickHint:"As ferramentas continuam sempre à mão.",
  scanMarket:"Analisar rotas de mercado",calcCraft:"Calcular um craft",calcRefine:"Calcular um refino",allocate:"Distribuir capital",
  follow:"Acompanhar oportunidades",track:"Acompanhar desempenho",units:"un.",perUnit:"/ un.",
  reason:(liq:string)=>`Selecionado pelo SOL: baixo capital inicial, liquidez ${liq.toLowerCase()}, margem saudável e preços recentes.`
 };
 const localLiquidity=(v:string)=>lang==="en"?({Alta:"High",Média:"Medium",Baixa:"Low","Sem dados":"No data"}[v]??v):v;
 const opportunityHref=(f:DashboardFlip)=>{
  const q=new URLSearchParams({auto:"1",pickItem:f.itemId,pickBuy:f.buyCity,pickSell:f.sellCity,pickQuality:String(f.quality),
   buyCity:"all",sellCity:"all",category:"all",tiers:"4,5,6",enchants:"0,1",maxAgeHours:"2",minRoi:"8",minProfit:"1000",
   capital:"500000",premium:String(settings.premium),maxAllocationPct:"30",maxDailyVolumePct:"15",saleMode:settings.saleMode,lang});
  return `/flipper?${q.toString()}`;
 };
 return <main className="shell dashboardShell"><AppSidebar/>
  <header className="hero dashboardHero">
   <div>
    <div className="eyebrow">SOL HUB • ALBION ECONOMY</div>
    <h1>SOL <span>HUB</span></h1>
    <p><strong>Craft smarter. Trade better. Grow together.</strong><br/>Market intelligence, crafting optimization and daily insights — built for NoTag, powered by SOL HUB. ☀️</p>
   </div>
   
  <div className="headerTools"><LanguageSelector/></div></header>

  <section className="hubStatusBar">
    <div className="hubStatusPrimary"><span className="hubLiveDot"/><strong>Albion Europe</strong><span>{ui.online}</span></div>
    <div className="hubStatusPills">
      <span><b>Premium</b>{settings.premium?"ON":"OFF"}</span>
      <span><b>Focus</b>{settings.focus.toLocaleString("pt-PT")}</span>
      <span><b>Market</b>{settings.marketCity==="all"?"All Cities":settings.marketCity}</span>
    </div>
  </section>

  <section className="solOpportunitySection">
    <div className="hubSectionHead solOpportunityHead">
      <div><div className="eyebrow">☀️ SOL DAILY OPPORTUNITY</div><h2>{ui.title}</h2></div>
      <span>{ui.tag}</span>
    </div>

    {pickLoading?<div className="solOpportunityCard solOpportunityLoading">
      <div className="solPickSkeleton"><span/><span/><span/></div>
      <div><strong>{ui.searching}</strong><p>{ui.validating}</p></div>
    </div>:dailyPick?(()=>{
      const age=Math.max(dailyPick.buyAgeMin,dailyPick.sellAgeMin);
      const qty=Math.max(1,dailyPick.recommendedQty||1);
      const investment=dailyPick.recommendedInvestment||dailyPick.buyPrice*qty;
      const profit=dailyPick.recommendedProfit||dailyPick.profit*qty;
      const rec=marketRecommendation({roi:dailyPick.roi,profit:dailyPick.profit,risk:dailyPick.risk,liquidity:dailyPick.liquidity,volatilityPct:dailyPick.volatilityPct,priceDeviationPct:dailyPick.priceDeviationPct,dataAgeMin:age,recommendedQty:qty},lang);
      return <article className="solOpportunityCard">
       <div className="solOpportunityVisual">
        <span className="solPickBadge">☀️ SOL PICK</span>
        <img src={itemImageUrl(dailyPick.itemId,{quality:dailyPick.quality,size:128})} alt={dailyPick.itemName}/>
        <span className="solQuality">{dailyPick.qualityName}</span>
       </div>
       <div className="solOpportunityMain">
        <div className="solOpportunityTitle"><div><span>{ui.lowRisk}</span><h3>{dailyPick.itemName}</h3><small>{dailyPick.itemId}</small></div><span className="risk baixo">{ui.risk}</span></div>
        <div className="solRoute"><div><span>{ui.buy}</span><strong>{dailyPick.buyCity}</strong><b>{money(dailyPick.buyPrice)}</b></div><i>→</i><div><span>{ui.sell}</span><strong>{dailyPick.sellCity}</strong><b>{money(dailyPick.sellPrice)}</b></div></div>
        <p className="solReason">{ui.reason(localLiquidity(dailyPick.liquidity))}</p>
        <div className={`solDashboardRec ${rec.tone}`}><span>{lang==="en"?"SOL recommends":"SOL recomenda"}</span><strong>{rec.label}</strong><small>{rec.action}</small></div><div className="dashboardIntelStrip"><div><span>☀️ SOL SCORE 2.0</span><strong>{dailyPick.intelligenceScore}/100</strong><small>{intelligenceBand(dailyPick.intelligenceScore,lang)}</small></div><div><span>{lang==="en"?"Entry quality":"Qualidade da entrada"}</span><strong className={dailyPick.entryAdvantagePct>=0?"profit":"warn"}>{dailyPick.entryAdvantagePct>=0?"+":""}{dailyPick.entryAdvantagePct.toFixed(1)}%</strong><small>{conditionLabel(dailyPick.marketCondition,lang)}</small></div><div><span>{lang==="en"?"7d trend":"Tendência 7d"}</span><strong>{dailyPick.trendPct>=0?"+":""}{dailyPick.trendPct.toFixed(1)}%</strong><small>{lang==="en"?"Historical context":"Contexto histórico"}</small></div></div>
       </div>
       <div className="solOpportunityMetrics">
        <div><span>{ui.investment}</span><strong>{money(investment)}</strong><small>{qty} {ui.units}</small></div>
        <div><span>{ui.profit}</span><strong className="profit">+{money(profit)}</strong><small>+{money(dailyPick.profit)} {ui.perUnit}</small></div>
        <div><span>{ui.return}</span><strong>{dailyPick.roi.toFixed(1)}%</strong><small>Score {dailyPick.score}/100</small></div>
        <div><span>{ui.liquidity}</span><strong>{dailyPick.avgDailyVolume.toFixed(1)}/dia</strong><small>{localLiquidity(dailyPick.liquidity)}</small></div>
        <div><span>{ui.marketData}</span><strong><span className={`dataFreshness ${dataHealthLevel(age)}`} title={dataHealthLabel(age,lang)}><i/>{ageText(age)}</span></strong><small>{dataHealthLabel(age,lang)}</small></div>
       </div>
       <div className="solOpportunityActions">
        <Link href={opportunityHref(dailyPick)} className="solPrimaryAction">{ui.view} <b>→</b></Link>
        <WatchlistButton source="DASHBOARD" type="FLIP" itemId={dailyPick.itemId} name={dailyPick.itemName} route={`${dailyPick.buyCity} → ${dailyPick.sellCity}`} buyCity={dailyPick.buyCity} sellCity={dailyPick.sellCity} quality={dailyPick.quality} investment={investment} profit={profit} roi={dailyPick.roi} dataAgeMin={age} buyPrice={dailyPick.buyPrice} sellPrice={dailyPick.sellPrice} intelligenceScore={dailyPick.intelligenceScore} entryAdvantagePct={dailyPick.entryAdvantagePct} trendPct={dailyPick.trendPct} marketCondition={dailyPick.marketCondition} volatilityPct={dailyPick.volatilityPct} liquidity={dailyPick.liquidity} risk={dailyPick.risk} avgDailyVolume={dailyPick.avgDailyVolume}/>
       </div>
      </article>
    })():<div className="solOpportunityCard solOpportunityEmpty">
      <div className="solEmptyIcon">☀️</div>
      <div><strong>{ui.empty}</strong><p>{pickError||ui.emptyText}</p></div>
      <Link href="/flipper" className="solPrimaryAction">{ui.open} →</Link>
    </div>}

    <div className="hubQuickActions">
      <div className="hubQuickActionsTitle"><span>{ui.quick}</span><small>{ui.quickHint}</small></div>
      <div className="hubSecondaryGrid">
       <Link href="/flipper"><span>↔</span><b>Market Scanner</b><small>{ui.scanMarket}</small></Link>
       <Link href="/crafting"><span>⚒</span><b>Craft Calculator</b><small>{ui.calcCraft}</small></Link>
       <Link href="/refining"><span>♻</span><b>Refine Calculator</b><small>{ui.calcRefine}</small></Link>
       <Link href="/optimizer"><span>☀</span><b>SOL Optimizer</b><small>{ui.allocate}</small></Link>
       <Link href="/watchlist"><span>⭐</span><b>Watchlist</b><small>{ui.follow}</small></Link>
       <Link href="/portfolio"><span>📈</span><b>Portfolio</b><small>{ui.track}</small></Link>
      </div>
    </div>
  </section>


  <section className="solRadar"><div className="hubSectionHead"><div><div className="eyebrow">☀️ SOL RADAR</div><h2>{lang==="en"?"What deserves your attention":"O que merece a sua atenção"}</h2></div><Link href="/alerts">{lang==="en"?"Open Alerts":"Abrir Alertas"} →</Link></div><div className="solRadarGrid"><div className="positive"><span>↗</span><strong>{radar.improving}</strong><small>{lang==="en"?"opportunities improving":"oportunidades melhorando"}</small></div><div className="hot"><span>🔥</span><strong>{radar.strong}</strong><small>{lang==="en"?"Strong Buy signals":"sinais Strong Buy"}</small></div><div className="warn"><span>◎</span><strong>{radar.near}</strong><small>{lang==="en"?"near strong target":"perto do alvo forte"}</small></div><div className="negative"><span>↘</span><strong>{radar.deteriorating}</strong><small>{lang==="en"?"opportunities deteriorating":"oportunidades piorando"}</small></div><div className="alerts"><span>🔔</span><strong>{radar.unread}</strong><small>{lang==="en"?"unread alerts":"alertas não lidos"}</small></div></div></section>

  <section className="dailyHeaderBar">
   <div className="dailyHeaderLeft">
    <span className="dailyKicker">BÓNUS DE HOJE</span>
    <b className="regionBadge">EUROPE</b>
    <strong>{data?.dateLabel??"A carregar…"}</strong>
    {data?.resetLabel&&<span>Reset {data.resetLabel}</span>}
   </div>
  </section>

  <section className="dailyShowcase">
   {!data?<div className="dailyFeatureCard loadingCard">A carregar bónus do dia…</div>:
    data.available?data.bonuses.map((b,i)=>{
      const items=bonusItems[b.category]??[];
      return <article className="dailyEventCard dailyEventWithImage dailyBonusMatchedCard" key={`${b.category}-${i}`}>
        <div className="dailyBonusTypeMatched">{dailyBonusTypeLabel(b.category,lang)}</div>
        <div className="dailyEventImage">
         <img
          src={itemRender(items[0]?.id ?? bonusFallbackImageId(b.category),88)}
          alt={items[0]?.name ?? b.category}
         />
        </div>
        <div className="dailyEventContent">
         <h3>{b.category}</h3>
         <p><span className="dailyCityLabel">Melhor cidade</span> <strong>{b.city??"—"}</strong></p>
        </div>
        <span className="dailyBonusPercent">+{b.bonus}%</span>
       </article>
    }):<div className="dailyFeatureCard unavailable">
      <h3>Sem dados de produção para hoje</h3>
      <p>O tracker ainda não publicou os bónus. Até lá, o Sol calcula com 0% de Daily Bonus.</p>
    </div>}
  </section>

  <section className="eventsBlock">
   <div className="sectionMiniTitle">DAILY EVENTS</div>
   <div className="eventGrid">
    {data?.events?.length?data.events.map((e,i)=><article className="dailyEventCard dailyEventWithImage" key={i}>
       {e.time&&<span className="eventTimer">{e.time}</span>}
       <div className="dailyEventImage"><img src={itemRender(eventImageId(e.title),88)} alt=""/></div>
       <div className="dailyEventContent">
        <h3>{e.title}</h3>
        {e.detail&&<p>{e.detail}</p>}
       </div>
     </article>):
    <>
     <article className="dailyEventCard"><h3>Sem eventos carregados</h3><p>Os bónus de produção continuam disponíveis acima.</p></article>
     <article className="dailyEventCard mutedEvent"><h3>À espera do próximo evento</h3><p>A informação aparece aqui assim que estiver disponível.</p></article>
    </>}
   </div>
  </section>

  <p className="sourceNote">by Fate and Ryukk • NoTag Exclusive • 2026 • {lang==="en"?"Not affiliated with Sandbox Interactive.":"Não afiliado à Sandbox Interactive."}</p>
 </main>
}