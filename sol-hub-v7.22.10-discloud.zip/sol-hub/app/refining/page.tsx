"use client";
import {itemImageUrl} from "../../lib/itemImage";
import LanguageSelector from "../components/LanguageSelector";
import AppSidebar from "../components/AppSidebar";
import SpecsAwareness from "../components/SpecsAwareness";


import Link from "next/link";
import {FormEvent,useEffect,useMemo,useState} from "react";
import {currentSiteLanguage} from "../../lib/languageClient";
import {ageText,dataHealthLabel,dataHealthLevel,dataHealthSummary} from "../../lib/dataHealth";
import {loadCraftingProfile,refiningFocusEfficiencyFor} from "../../lib/focusClient";
import {settingsFormKey,useSolHubSettings} from "../../lib/settingsClient";

const refineCities=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon"];
const buyCities=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const sellCities=[...buyCities,"Black Market"];
const familyDefaults:Record<string,string>={
  metal:"Thetford",wood:"Fort Sterling",leather:"Martlock",cloth:"Lymhurst",stone:"Bridgewatch"
};
const familyImages:Record<string,string>={
  metal:"T8_METALBAR",wood:"T8_PLANKS",leather:"T8_LEATHER",cloth:"T8_CLOTH",stone:"T8_STONEBLOCK"
};
const money=(n:number)=>Math.round(Number(n)||0).toLocaleString("en-US");

type Result=any;

const refineHealth=(r:any)=>dataHealthSummary([r.sellAgeMin,...(r.breakdown??[]).map((m:any)=>m.ageMin)]);
export default function Refining(){
  const {settings,ready:settingsReady}=useSolHubSettings();
  const [family,setFamily]=useState("metal");
  const [tier,setTier]=useState(6);
  const [enchant,setEnchant]=useState(0);
  const [refineCity,setRefineCity]=useState("Thetford");
  const [res,setRes]=useState<Result|null>(null);
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState("");
  const [lang,setLang]=useState<"pt-BR"|"en">("en");
  useEffect(()=>setLang(currentSiteLanguage()),[]);

  useEffect(()=>{
    if(settingsReady)setRefineCity(settings.refineCity);
  },[settingsReady,settings.refineCity]);

  const currentItemId=useMemo(()=>{
    const suffix=familyImages[family].replace(/^T8_/,"");
    return enchant>0?`T${tier}_${suffix}_LEVEL${enchant}@${enchant}`:`T${tier}_${suffix}`;
  },[family,tier,enchant]);
  const focusEfficiency=refiningFocusEfficiencyFor(currentItemId);

  function changeFamily(v:string){
    setFamily(v);
    if(v==="stone")setEnchant(0);
    setRefineCity(familyDefaults[v]??"Thetford");
    setRes(null);
  }

  async function calculate(e:FormEvent<HTMLFormElement>){
    e.preventDefault();
    setLoading(true);setErr("");setRes(null);
    try{
      const fd=new FormData(e.currentTarget);
      const q=new URLSearchParams();
      q.set("family",family);
      q.set("tier",String(tier));
      q.set("enchant",tier>=4?String(enchant):"0");
      q.set("qty",String(fd.get("qty")??100));
      q.set("refineCity",refineCity);
      q.set("matsCity",String(fd.get("matsCity")??"cheapest"));
      q.set("sellCity",String(fd.get("sellCity")??refineCity));
      q.set("saleMode",String(fd.get("saleMode")??"sell_order"));
      q.set("stationFee",String(fd.get("stationFee")??0));
      q.set("focus",String(fd.get("focus")??0));
      q.set("focusEfficiency",String(focusEfficiency));
      q.set("specProfile",JSON.stringify(loadCraftingProfile()));
      q.set("lang",currentSiteLanguage());
      q.set("premium",fd.get("premium")?"true":"false");
      const r=await fetch(`/api/refine?${q.toString()}`);
      const j=await r.json();
      if(!r.ok)throw Error(j?.error??(lang==="en"?"Refining calculation failed.":"Erro de refino."));
      setRes(j);
    }catch(x){setErr(x instanceof Error?x.message:(lang==="en"?"Refining calculation failed.":"Erro de refino."))}
    finally{setLoading(false)}
  }

  const previewId=currentItemId;
  const ui=lang==="en"?{hero:"Calculate Return Rate, Focus, costs, fees and refining profit using real Albion Europe prices.",enchant:"Enchantment",qty:"Quantity",refineIn:"Refine in",buyMaterials:"Buy materials",cheapest:"✨ Cheapest per material",sellIn:"Sell in",saleMode:"Sale mode",stationFee:"Station Fee (Silver)",perNutrition:"per 100 nutrition",example:"e.g. 350",focusAvailable:"Available Focus",spec:"Calculated specialization",specHint:"Calculated automatically from your Specializations profile. Every 10,000 Efficiency halves the Focus cost.",calculating:"Calculating…",calculate:"Calculate Refining",health:(s:string,a:string)=>`Sell ${s} • oldest point ${a}`,specialty:"Specialty",sellData:"Sell data",totalProfit:"Total profit",return:"return",refinedQty:"Refined quantity",dailyApplied:"Daily applied",focusRefine:"Focus / refine",focusSpecs:"Calculated specialization",focusRefines:"Refines with Focus",focusUsed:"Focus used",gross:"Gross material cost",resourceReturn:"Resource return",effectiveMaterials:"Effective materials",station:"Station fee",totalCost:"Total cost",saleUnit:"Sale / unit",marketFees:"Market fees",profitUnit:"Profit / unit",materials:"📦 Required materials",materialsDesc:"Cheapest mode finds the best price for each ingredient individually.",returnNote:"Return is applied only to materials marked as returnable by the Albion recipe.",origin:"Source",priceUnit:"Price/unit",grossQty:"Gross qty.",returned:"Return",effectiveQty:"Effective qty.",effectiveCost:"Effective cost",data:"Data",bestCity:"Return Rate comparison",bestCityDesc:"SOL automatically compares cities for this material family.",specialtyTag:"SPECIALTY",recommend:"☀️ SOL recommendation",recommendText:(city:string,family:string)=>`${city} offers the highest Return Rate for ${family} under these conditions. The specialty city receives +40% refining Production Bonus.`,specialtyTitle:"♻️ Specialty city",specialtyText:(city:string,family:string)=>`${city} receives the specific refining bonus for ${family}.`,focusTitle:"⚡ Focus",focusText:"Available Focus is distributed across as many refines as possible. Focus Efficiency is calculated automatically from the T4–T8 Specs in your refining chain.",marketTitle:"⚠️ Market",marketText:"Prices come from AODP and may be outdated. Confirm prices, stock and fees in-game before refining.",start:"START CALCULATING",startTitle:"Choose the material and refining conditions",startText:"SOL uses the real recipe, Europe prices, Return Rate, Daily Bonus, Focus and fees to calculate the result.",footer:"Not affiliated with Sandbox Interactive."}:{hero:"Calcula Return Rate, Focus, custos, taxas e lucro de refino com preços reais do Albion Europe.",enchant:"Encantamento",qty:"Quantidade",refineIn:"Refinar em",buyMaterials:"Comprar materiais",cheapest:"✨ Mais barato por material",sellIn:"Vender em",saleMode:"Modo de venda",stationFee:"Taxa da Estação (Silver)",perNutrition:"por 100 de nutrição",example:"Ex.: 350",focusAvailable:"Focus disponível",spec:"Especialização calculada",specHint:"Calculada automaticamente pelo teu perfil de Especializações. Cada 10.000 de eficiência reduz o custo de Focus pela metade.",calculating:"A calcular…",calculate:"Calcular refino",health:(s:string,a:string)=>`Venda ${s} • ponto mais antigo ${a}`,specialty:"Especialidade",sellData:"Dados de venda",totalProfit:"Lucro total",return:"rentabilidade",refinedQty:"Quantidade refinada",dailyApplied:"Daily aplicado",focusRefine:"Focus / refino",focusSpecs:"Especialização calculada",focusRefines:"Refinos com Focus",focusUsed:"Focus usado",gross:"Custo bruto materiais",resourceReturn:"Retorno de recursos",effectiveMaterials:"Materiais efetivos",station:"Taxa da estação",totalCost:"Custo total",saleUnit:"Venda / unidade",marketFees:"Taxas de mercado",profitUnit:"Lucro / unidade",materials:"📦 Materiais necessários",materialsDesc:"O modo “Mais barato” procura o melhor preço de cada ingrediente individualmente.",returnNote:"O retorno é aplicado apenas aos materiais marcados como retornáveis pela receita do Albion.",origin:"Origem",priceUnit:"Preço/un.",grossQty:"Qtd. bruta",returned:"Retorno",effectiveQty:"Qtd. efetiva",effectiveCost:"Custo efetivo",data:"Dados",bestCity:"Comparação de Return Rate",bestCityDesc:"O Sol compara automaticamente as cidades para esta família de material.",specialtyTag:"ESPECIALIDADE",recommend:"☀️ Recomendação Sol",recommendText:(city:string,family:string)=>`${city} oferece o maior Return Rate para ${family} com estas condições. A cidade especializada recebe +40% de Production Bonus de refino.`,specialtyTitle:"♻️ Cidade especializada",specialtyText:(city:string,family:string)=>`${city} recebe o bônus específico de refino para ${family}.`,focusTitle:"⚡ Focus",focusText:"O Focus disponível é distribuído pelo máximo de refinos possível. A Eficiência de Focus é calculada automaticamente a partir das Specs T4–T8 da tua cadeia de refino.",marketTitle:"⚠️ Mercado",marketText:"Os preços vêm do AODP e podem estar desatualizados. Confirme preços, stock e taxas no jogo antes de refinar.",start:"COMECE A CALCULAR",startTitle:"Escolha o material e as condições do refino",startText:"O Sol usa a receita real, preços do Europe, Return Rate, Daily Bonus, Focus e taxas para calcular o resultado.",footer:"Não afiliado à Sandbox Interactive."};

  return <main className="shell"><AppSidebar/>
    <header className="hero">
      <div>
        <div className="eyebrow">NOTAG • REFINING INTELLIGENCE</div>
        <h1>Refine <span>Calculator</span></h1>
        <p>{ui.hero}</p>
      </div>
      
    <div className="headerTools"><LanguageSelector/></div></header>
 <SpecsAwareness/>

    <section className="panel refiningPanel">
      <form key={settingsFormKey(settings,settingsReady)} onSubmit={calculate} className="filters refiningFilters">
        <label>Material
          <select value={family} onChange={e=>changeFamily(e.target.value)}>
            <option value="metal">Metal Bars</option>
            <option value="wood">Planks</option>
            <option value="leather">Leather</option>
            <option value="cloth">Cloth</option>
            <option value="stone">Stone Blocks</option>
          </select>
        </label>
        <label>Tier
          <select value={tier} onChange={e=>{const t=Number(e.target.value);setTier(t);if(t<4)setEnchant(0);setRes(null)}}>
            {[3,4,5,6,7,8].map(t=><option key={t} value={t}>T{t}</option>)}
          </select>
        </label>
        <label>{ui.enchant}
          <select name="enchant" value={enchant} onChange={e=>{setEnchant(Number(e.target.value));setRes(null)}} disabled={tier<4||family==="stone"}>
            <option value="0">.0</option><option value="1">.1</option><option value="2">.2</option><option value="3">.3</option>
          </select>
        </label>
        <label>{ui.qty}
          <input name="qty" type="number" min="1" step="1" defaultValue="100"/>
        </label>

        <label>{ui.refineIn}
          <select value={refineCity} onChange={e=>setRefineCity(e.target.value)}>
            {refineCities.map(c=><option key={c}>{c}</option>)}
          </select>
        </label>
        <label>{ui.buyMaterials}
          <select name="matsCity" defaultValue="cheapest">
            <option value="cheapest">{ui.cheapest}</option>
            {buyCities.map(c=><option key={c}>{c}</option>)}
          </select>
        </label>
        <label>{ui.sellIn}
          <select name="sellCity" defaultValue={settings.refineSellCity} key={`sell-${refineCity}-${settings.refineSellCity}`}>
            {sellCities.map(c=><option key={c}>{c}</option>)}
          </select>
        </label>
        <label>{ui.saleMode}
          <select name="saleMode" defaultValue={settings.saleMode}>
            <option value="sell_order">Sell Order</option>
            <option value="instant_sell">Instant Sell</option>
          </select>
        </label>

        <label>{ui.stationFee}<small className="fieldHint">{ui.perNutrition}</small>
          <input name="stationFee" type="number" min="0" step="1" defaultValue={settings.stationFee} placeholder={ui.example}/>
        </label>
        <label>{ui.focusAvailable}
          <input name="focus" type="number" min="0" max="30000" step="1" defaultValue={settings.focus} placeholder="0–30000"/>
        </label>
        <label>{ui.spec}
          <input type="number" value={focusEfficiency} readOnly/>
          <small className="fieldHint">{ui.specHint}</small>
        </label>
        <label className="check"><input name="premium" type="checkbox" value="true" defaultChecked={settings.premium}/> Premium</label>
        <button className="scan">{loading?ui.calculating:ui.calculate}</button>
      </form>
    </section>

    {err&&<div className="error">{err}</div>}

    {res&&<>{(()=>{const h=refineHealth(res);return <section className="dataHealthBar"><div><span className="dataHealthTitle">📡 Refine Market Data</span><strong>{h.healthyPct}% Fresh/Recent</strong><small>{ui.health(ageText(res.sellAgeMin),ageText(h.maxAgeMin))}</small></div><div className="dataHealthLegend"><span className="freshNow">Fresh {h.counts.freshNow}</span><span className="freshOk">Recent {h.counts.freshOk}</span><span className="freshAging">Aging {h.counts.freshAging}</span><span className="freshStale">Stale {h.counts.freshStale}</span></div></section>})()}
      <section className="craftHero results">
        <div className="craftItem">
          <img src={itemImageUrl(res.itemId,{size:128})} alt=""/>
          <div>
            <div className="eyebrow">REFINING RESULT</div>
            <h2>{res.recipe.name}</h2>
            <p>{ui.specialty}: <b>{res.specialtyCity}</b> • Return Rate: <b>{(res.rrr*100).toFixed(1)}%</b> • {ui.sellData}: <b>{ageText(res.sellAgeMin)}</b></p>
          </div>
        </div>
        <div className={res.profit>=0?"bigProfit positive":"bigProfit negative"}>
          <span>{ui.totalProfit}</span>
          <strong>{res.profit>=0?"+":""}{money(res.profit)}</strong>
          <small>{res.roi.toFixed(1)}% {ui.return} • {res.profit>=0?"PROFITABLE":"LOSS"}</small>
        </div>
      </section>

      <section className="craftSummary">
        <div><span>{ui.refinedQty}</span><b>{res.producedQty}</b></div>
        <div><span>Production Bonus</span><b>+{(res.focusedRefines?res.productionBonus.withFocus.total:res.productionBonus.noFocus.total)}%</b></div>
        <div><span>{ui.dailyApplied}</span><b>{res.daily?`+${res.daily}%`:"0%"}</b></div>
        <div><span>Return Rate</span><b>{(res.rrr*100).toFixed(1)}%</b></div>
        <div><span>{ui.focusRefine}</span><b>{res.focusPerRefine||"—"}</b></div><div><span>{ui.focusSpecs}</span><b>{res.focusEfficiency.toLocaleString(lang==="en"?"en-GB":"pt-PT")}</b></div>
        <div><span>{ui.focusRefines}</span><b>{res.focusedRefines}/{res.qty}</b></div>
        <div><span>{ui.focusUsed}</span><b>{res.focusUsed}</b></div>
        <div><span>{ui.gross}</span><b>{money(res.grossMaterials)}</b></div>
        <div><span>{ui.resourceReturn}</span><b className="profit">−{money(res.returnValue)}</b></div>
        <div><span>{ui.effectiveMaterials}</span><b>{money(res.effectiveMaterials)}</b></div>
        <div><span>{ui.station}</span><b>{money(res.stationFee)}</b></div>
        <div><span>{ui.totalCost}</span><b>{money(res.totalCost)}</b></div>
        <div><span>{ui.saleUnit}</span><b>{money(res.sellUnit)}</b></div>
        <div><span>{ui.marketFees}</span><b>{money(res.marketFees)}</b></div>
        <div><span>{ui.profitUnit}</span><b className={res.profitPerUnit>=0?"profit":"loss"}>{res.profitPerUnit>=0?"+":""}{money(res.profitPerUnit)}</b></div>
      </section>

      <section className="results">
        <div className="resultsHead">
          <div><h2>{ui.materials}</h2><p>{ui.materialsDesc}</p></div>
          <small>{ui.returnNote}</small>
        </div>
        <div className="tableWrap"><table>
          <thead><tr><th>Material</th><th>{ui.origin}</th><th>{ui.priceUnit}</th><th>{ui.grossQty}</th><th>{ui.returned}</th><th>{ui.effectiveQty}</th><th>{ui.effectiveCost}</th><th>{ui.data}</th></tr></thead>
          <tbody>{res.breakdown.map((m:any)=><tr key={m.id}>
            <td><div className="item"><img src={itemImageUrl(m.id,{size:64})} alt=""/><div><strong>{m.name}</strong><span>{m.id}</span></div></div></td>
            <td>{m.sourceCity}</td><td>{money(m.unitPrice)}</td><td>{m.rawQty.toFixed(1)}</td>
            <td className="profit">{m.ret?`−${m.returnedQty.toFixed(1)}`:"—"}</td>
            <td>{m.effectiveQty.toFixed(1)}</td><td>{money(m.cost)}</td><td><span className={`dataFreshness ${dataHealthLevel(m.ageMin)}`} title={dataHealthLabel(m.ageMin,lang)}><i/>{ageText(m.ageMin)}</span></td>
          </tr>)}</tbody>
        </table></div>
      </section>

      <section className="rrrGuide">
        <div className="resultsHead">
          <div><div className="eyebrow">BEST REFINING CITY</div><h2>{ui.bestCity}</h2><p>{ui.bestCityDesc}</p></div>
        </div>
        <div className="refiningCityGrid">
          {res.cityComparison.map((c:any)=><div className={c.specialty?"metricCard refiningBest":"metricCard"} key={c.city}>
            <span>{c.city}{c.specialty?` • ${ui.specialtyTag}`:""}</span>
            <strong>{(c.rrr*100).toFixed(1)}%</strong>
            <small>+{c.productionBonus}% Production Bonus</small>
          </div>)}
        </div>
        <p className="rrrNote">{ui.recommend}: <b>{res.cityComparison[0]?.city}</b> {ui.recommendText(res.cityComparison[0]?.city??"—",res.familyLabel).replace(`${res.cityComparison[0]?.city??"—"} `,"")}</p>
      </section>

      <section className="craftNotes">
        <div><strong>{ui.specialtyTitle}</strong><p>{ui.specialtyText(res.specialtyCity,res.familyLabel)}</p></div>
        <div><strong>{ui.focusTitle}</strong><p>{ui.focusText}</p></div>
        <div><strong>{ui.marketTitle}</strong><p>{ui.marketText}</p></div>
      </section>
    </>}

    {!res&&!err&&<section className="refiningIntro">
      <div className="refiningPreview"><img src={itemImageUrl(previewId,{size:128})} alt=""/><div><span>{ui.start}</span><h2>{ui.startTitle}</h2><p>{ui.startText}</p></div></div>
    </section>}

    <footer>by Fate and Ryukk • NoTag Exclusive • 2026 • {ui.footer}</footer>
  </main>
}
