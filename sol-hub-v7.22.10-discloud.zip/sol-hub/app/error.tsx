"use client";
import {useEffect,useState} from "react";
import {currentSiteLanguage} from "../lib/languageClient";

export default function ErrorPage({reset}:{reset:()=>void}){
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 useEffect(()=>setLang(currentSiteLanguage()),[]);
 const en=lang==="en";
 return <main className="shell"><section className="panel" style={{marginTop:80,textAlign:"center"}}>
  <div className="eyebrow">SOL HUB</div>
  <h1>{en?"Something went wrong ☀️":"Algo deu errado ☀️"}</h1>
  <p>{en?"The data service may be temporarily unavailable. Please try again in a few moments.":"O serviço de dados pode estar temporariamente indisponível. Tente novamente em alguns instantes."}</p>
  <button className="scan" onClick={()=>reset()}>{en?"Try again":"Tentar novamente"}</button>
 </section></main>
}