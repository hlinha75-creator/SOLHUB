"use client";

import {FormEvent,useEffect,useState} from "react";
import AppSidebar from "../components/AppSidebar";
import LanguageSelector from "../components/LanguageSelector";
import {APP_VERSION} from "../../lib/appMeta";
import {currentSiteLanguage,type SiteLanguage} from "../../lib/languageClient";

const pages=[
  ["dashboard","Dashboard"],
  ["flipper","Flipper"],
  ["crafting","Crafting"],
  ["refining","Refining"],
  ["best-crafts","Best Crafts"],
  ["best-refines","Best Refines"],
  ["optimizer","Optimizer"],
  ["portfolio","Portfolio"],
  ["specializations","Specs"],
  ["other","Outra / Geral"]
] as const;

const typeOptions=(lang:SiteLanguage)=>lang==="en"?[
  {value:"bug",icon:"🐛",label:"Report a bug",hint:"Something is not working as expected."},
  {value:"suggestion",icon:"💡",label:"Suggest a feature",hint:"An idea to improve SOL HUB."},
  {value:"calculation",icon:"📊",label:"Incorrect data / calculation",hint:"Suspicious price, return, fee or result."},
  {value:"ui",icon:"🎨",label:"Interface suggestion",hint:"Layout, navigation or user experience."},
  {value:"other",icon:"💬",label:"Other",hint:"Anything that does not fit the options above."}
] as const:[
  {value:"bug",icon:"🐛",label:"Reportar um erro",hint:"Algo não funciona como deveria."},
  {value:"suggestion",icon:"💡",label:"Sugerir funcionalidade",hint:"Uma ideia para melhorar o Consultor."},
  {value:"calculation",icon:"📊",label:"Dados / cálculo incorreto",hint:"Preço, retorno, taxa ou resultado suspeito."},
  {value:"ui",icon:"🎨",label:"Sugestão de interface",hint:"Layout, navegação ou experiência de utilização."},
  {value:"other",icon:"💬",label:"Outro",hint:"Tudo o que não encaixa nas opções acima."}
] as const;

export default function FeedbackPage(){
  const [lang,setLang]=useState<SiteLanguage>("en");
  const [type,setType]=useState("bug");
  const [affectedPage,setAffectedPage]=useState("other");
  const [sourcePage,setSourcePage]=useState("/");
  const [loading,setLoading]=useState(false);
  const [selectedFiles,setSelectedFiles]=useState<File[]>([]);
  const [status,setStatus]=useState<{kind:"ok"|"error";text:string}|null>(null);

  useEffect(()=>{
    setLang(currentSiteLanguage());
    try{
      const ref=document.referrer?new URL(document.referrer):null;
      if(ref&&ref.origin===location.origin){
        setSourcePage(ref.pathname);
        const route=ref.pathname.split("/").filter(Boolean)[0]??"dashboard";
        if(pages.some(([value])=>value===route))setAffectedPage(route);
        else if(ref.pathname==="/")setAffectedPage("dashboard");
      }
    }catch{}
  },[]);

  async function submit(e:FormEvent<HTMLFormElement>){
    e.preventDefault();
    setLoading(true);
    setStatus(null);

    const form=e.currentTarget;
    const fd=new FormData(form);
    fd.set("type",type);
    fd.set("affectedPage",affectedPage);
    fd.set("sourcePage",sourcePage);
    fd.set("includeTechnical",fd.get("includeTechnical")==="on"?"true":"false");
    fd.set("language",navigator.language);
    fd.set("userAgent",navigator.userAgent);

    try{
      const r=await fetch("/api/feedback",{
        method:"POST",
        body:fd
      });
      const j=await r.json();
      if(!r.ok)throw new Error(lang==="en"?"Could not send feedback.":(j?.error||"Não foi possível enviar o feedback."));
      setStatus({
        kind:"ok",
        text:lang==="en"
          ?(j?.attachments?`Sent with ${j.attachments} attachment${j.attachments===1?"":"s"}! Thank you for helping improve SOL HUB. ☀️`:"Sent! Thank you for helping improve SOL HUB. ☀️")
          :(j?.attachments?`Enviado com ${j.attachments} anexo${j.attachments===1?"":"s"}! Obrigado por ajudares a melhorar o Consultor. ☀️`:"Enviado! Obrigado por ajudares a melhorar o Consultor. ☀️")
      });
      form.reset();
      setSelectedFiles([]);
      setType("bug");
    }catch(err){
      setStatus({kind:"error",text:err instanceof Error?err.message:(lang==="en"?"Could not send feedback.":"Não foi possível enviar o feedback.")});
    }finally{
      setLoading(false);
    }
  }

  const showIncident=type==="bug"||type==="calculation";
  const showMarket=type==="calculation";
  const ui=lang==="en"?{
    titleA:"Suggestions &",titleB:"Reports",hero:"Found a problem or have an idea to improve SOL HUB? Send it directly to the NoTag team. ☀️",help:"Help us improve",helpHint:"Reports are sent to a private team channel through a Discord Webhook.",typeTitle:"What type of feedback do you want to send?",typeHint:"Choose the option that best describes the topic.",detailsTitle:"Tell us what is happening",detailsHint:"The more context you provide, the faster we can understand the case.",affected:"Affected page",contact:"Discord contact",optional:"optional",title:"Title",description:"Description",itemRef:"Item / reference",city:"City",expected:"What did you expect to happen",actual:"What happened",attachments:"Attachments",attachmentsHint:"Add screenshots or files that help us understand the problem.",fileHint:"PNG, JPG, WEBP, GIF, PDF, TXT or LOG • maximum 3 files • 8 MB per file",tech:"Technical information",techHint:"Helps us reproduce errors without making you look up these details.",includeTech:"Include technical data",includeTechHint:"SOL HUB version, source page, language and browser identification. We do not send the webhook address to the browser.",submitHint:"The report will be sent directly to the private channel configured by NoTag.",suggestionPh:"e.g. Save favorite filters",issuePh:"e.g. Best Refines does not show results",descriptionPh:"Explain what you found or your suggestion…",expectedPh:"e.g. I expected to see the refine materials and profit.",actualPh:"e.g. An error message appears and no results are shown."
  }:{
    titleA:"Sugestões &",titleB:"Reports",hero:"Encontraste um problema ou tens uma ideia para melhorar o Consultor? Envia diretamente para a equipa NoTag. ☀️",help:"Ajuda-nos a melhorar",helpHint:"Os reports são enviados para um canal privado da equipa através de Discord Webhook.",typeTitle:"Que tipo de feedback queres enviar?",typeHint:"Escolhe a opção que melhor descreve o assunto.",detailsTitle:"Conta-nos o que se passa",detailsHint:"Quanto mais contexto, mais depressa conseguimos perceber o caso.",affected:"Página afetada",contact:"Contacto Discord",optional:"opcional",title:"Título",description:"Descrição",itemRef:"Item / referência",city:"Cidade",expected:"O que esperavas que acontecesse",actual:"O que aconteceu",attachments:"Anexos",attachmentsHint:"Adiciona screenshots ou ficheiros que ajudem a perceber o problema.",fileHint:"PNG, JPG, WEBP, GIF, PDF, TXT ou LOG • máximo 3 ficheiros • 8 MB por ficheiro",tech:"Informação técnica",techHint:"Ajuda-nos a reproduzir erros sem te obrigar a procurar estes dados.",includeTech:"Incluir dados técnicos",includeTechHint:"Versão do Consultor, página de origem, idioma e identificação do browser. Não enviamos o endereço do webhook para o browser.",submitHint:"O report será enviado diretamente para o canal privado configurado pela NoTag.",suggestionPh:"Ex.: Guardar filtros favoritos",issuePh:"Ex.: Best Refines não apresenta resultados",descriptionPh:"Explica o que encontraste ou a tua sugestão…",expectedPh:"Ex.: Esperava ver os materiais e o lucro do refine.",actualPh:"Ex.: Surge uma mensagem de erro e não aparecem resultados."
  };

  return <main className="shell feedbackShell">
    <AppSidebar/>

    <header className="hero">
      <div>
        <div className="eyebrow">NOTAG • FEEDBACK CENTER</div>
        <h1>{ui.titleA} <span>{ui.titleB}</span></h1>
        <p>{ui.hero}</p>
      </div>
      <div className="headerTools"><LanguageSelector/></div>
    </header>

    <section className="feedbackIntro">
      <div><strong>{ui.help}</strong><span>{ui.helpHint}</span></div>
      <div className="feedbackVersion">V{APP_VERSION}</div>
    </section>

    <form className="feedbackForm" onSubmit={submit}>
      <section className="feedbackSection">
        <div className="feedbackSectionHead">
          <span>1</span>
          <div><strong>{ui.typeTitle}</strong><small>{ui.typeHint}</small></div>
        </div>
        <div className="feedbackTypeGrid">
          {typeOptions(lang).map(x=><button
            type="button"
            key={x.value}
            className={type===x.value?"feedbackType active":"feedbackType"}
            onClick={()=>setType(x.value)}
          >
            <span className="feedbackTypeIcon">{x.icon}</span>
            <strong>{x.label}</strong>
            <small>{x.hint}</small>
          </button>)}
        </div>
      </section>

      <section className="feedbackSection">
        <div className="feedbackSectionHead">
          <span>2</span>
          <div><strong>{ui.detailsTitle}</strong><small>{ui.detailsHint}</small></div>
        </div>

        <div className="feedbackFields">
          <label>{ui.affected}
            <select name="affectedPage" value={affectedPage} onChange={e=>setAffectedPage(e.target.value)}>
              {pages.map(([value,label])=><option value={value} key={value}>{value==="other"?(lang==="en"?"Other / General":"Outra / Geral"):label}</option>)}
            </select>
          </label>

          <label>{ui.contact} <small>({ui.optional})</small>
            <input name="contact" maxLength={120} placeholder="Ex.: ryukk"/>
          </label>

          <label className="feedbackWide">{ui.title}
            <input name="title" required minLength={4} maxLength={180} placeholder={type==="suggestion"?ui.suggestionPh:ui.issuePh}/>
          </label>

          <label className="feedbackWide">{ui.description}
            <textarea name="description" required minLength={10} maxLength={3000} rows={6} placeholder={ui.descriptionPh}/>
          </label>

          {showMarket&&<>
            <label>{ui.itemRef}
              <input name="item" maxLength={160} placeholder="Ex.: T7_METALBAR@1"/>
            </label>
            <label>{ui.city}
              <input name="city" maxLength={80} placeholder="Ex.: Thetford"/>
            </label>
          </>}

          {showIncident&&<>
            <label className="feedbackWide">{ui.expected} <small>({ui.optional})</small>
              <textarea name="expected" maxLength={1200} rows={3} placeholder={ui.expectedPh}/>
            </label>
            <label className="feedbackWide">{ui.actual} <small>({ui.optional})</small>
              <textarea name="actual" maxLength={1200} rows={3} placeholder={ui.actualPh}/>
            </label>
          </>}
        </div>
      </section>

      <section className="feedbackSection">
        <div className="feedbackSectionHead">
          <span>3</span>
          <div>
            <strong>{ui.attachments}</strong>
            <small>{ui.attachmentsHint}</small>
          </div>
        </div>

        <label className="feedbackUpload">
          <input
            type="file"
            name="attachments"
            multiple
            accept=".png,.jpg,.jpeg,.webp,.gif,.pdf,.txt,.log,image/png,image/jpeg,image/webp,image/gif,application/pdf,text/plain"
            onChange={e=>{
              const files=Array.from(e.target.files??[]);
              if(files.length>3){
                setStatus({kind:"error",text:lang==="en"?"You can send a maximum of 3 attachments per report.":"Podes enviar no máximo 3 anexos por report."});
                e.target.value="";
                setSelectedFiles([]);
                return;
              }
              const tooLarge=files.find(file=>file.size>8*1024*1024);
              if(tooLarge){
                setStatus({kind:"error",text:lang==="en"?`"${tooLarge.name}" exceeds the 8 MB per-file limit.`:`"${tooLarge.name}" ultrapassa o limite de 8 MB por ficheiro.`});
                e.target.value="";
                setSelectedFiles([]);
                return;
              }
              setStatus(null);
              setSelectedFiles(files);
            }}
          />
          <span className="feedbackUploadIcon">📎</span>
          <span className="feedbackUploadCopy">
            <strong>{selectedFiles.length?(lang==="en"?"Add more attachments":"Adicionar outros anexos"):(lang==="en"?"Select attachments":"Selecionar anexos")}</strong>
            <small>{ui.fileHint}</small>
          </span>
          <span className="feedbackUploadButton">{lang==="en"?"Browse files":"Procurar ficheiros"}</span>
        </label>

        {selectedFiles.length>0&&<div className="feedbackFileList">
          {selectedFiles.map((file,index)=><div className="feedbackFile" key={`${file.name}-${file.size}-${index}`}>
            <span>{file.type.startsWith("image/")?"🖼️":"📄"}</span>
            <div>
              <strong>{file.name}</strong>
              <small>{(file.size/1024/1024).toFixed(file.size<1024*1024?2:1)} MB</small>
            </div>
          </div>)}
        </div>}
      </section>

      <section className="feedbackSection feedbackTechnical">
        <div className="feedbackSectionHead">
          <span>4</span>
          <div><strong>{ui.tech}</strong><small>{ui.techHint}</small></div>
        </div>
        <label className="feedbackTechCheck">
          <input type="checkbox" name="includeTechnical" defaultChecked/>
          <span><strong>{ui.includeTech}</strong><small>{ui.includeTechHint}</small></span>
        </label>
      </section>

      {/* Anti-spam honeypot — hidden from normal users. */}
      <label className="feedbackHoneypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off"/></label>

      {status&&<div className={status.kind==="ok"?"feedbackStatus success":"feedbackStatus error"}>{status.text}</div>}

      <div className="feedbackSubmitRow">
        <span>{ui.submitHint}</span>
        <button className="feedbackSubmit" disabled={loading}>{loading?(lang==="en"?"Sending…":"A enviar…"):(lang==="en"?"☀️ Send feedback":"☀️ Enviar feedback")}</button>
      </div>
    </form>
  </main>;
}
