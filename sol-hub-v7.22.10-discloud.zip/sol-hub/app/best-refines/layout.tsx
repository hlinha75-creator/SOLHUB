import type {Metadata} from "next";
export const metadata:Metadata={title:"Refine Scanner | SOL HUB"};
export default function Layout({children}:{children:React.ReactNode}){return children}
