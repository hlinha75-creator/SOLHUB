"use client";
import {itemImageUrl} from "../../lib/itemImage";
import {itemMatchesSearch} from "../../lib/itemSearch";
import {ageText,dataHealthLabel,dataHealthLevel,dataHealthSummary} from "../../lib/dataHealth";

import LanguageSelector from "../components/LanguageSelector";
import AppSidebar from "../components/AppSidebar";
import SpecsAwareness from "../components/SpecsAwareness";


import Link from "next/link";
import {FormEvent,useEffect,useState} from "react";
import AddToPortfolioButton from "../components/AddToPortfolioButton";
import WatchlistButton from "../components/WatchlistButton";
import {currentSiteLanguage} from "../../lib/languageClient";
import {refineRecommendation} from "../../lib/solRecommendations";
import {loadCraftingProfile} from "../../lib/focusClient";
import {settingsFormKey,useSolHubSettings} from "../../lib/settingsClient";
import SortTh from "../components/SortTh";
import {sortRows,nextSort,type SortDir} from "../../lib/sort";

const fmt=new Intl.NumberFormat("pt-PT"),money=(n:number)=>fmt.format(Math.round(n||0));
type Row={itemId:string;name:string;family:string;tier:number;enchant:number;specialtyCity:string;sellCity:string;shopping:Record<string,{id:string;name:string;qty:number;unitPrice:number;ageMin:number}[]>;daily:number;focusEfficiency:number;focusPerRefine:number;useFocus:boolean;rrr:number;investment:number;profit:number;roi:number;risk:"Baixo"|"Médio"|"Alto";score:number;sellPrice:number;dataAgeMin:number;output:number;roiNoFocus:number;roiFocus:number};
type Result={rows:Row[];meta:{scanned:number;approved:number};error?:string};

export default function BestRefines(){const [itemSearch,setItemSearch]=useState("");
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 useEffect(()=>setLang(currentSiteLanguage()),[]);
 const {settings,ready:settingsReady}=useSolHubSettings();
 const [r,setR]=useState<Result|null>(null),[loading,setLoading]=useState(false),[err,setErr]=useState(""),[selected,setSelected]=useState<Row|null>(null);
 const [sort,setSort]=useState<{key:string;dir:SortDir}>({key:"score",dir:"desc"});
 const sortBy=(key:string)=>setSort(v=>nextSort(v.key,v.dir,key));
 const health=dataHealthSummary(r?.rows.map(x=>x.dataAgeMin)??[]);
 async function scan(e:FormEvent<HTMLFormElement>){
  e.preventDefault();setLoading(true);setErr("");
  const f=new FormData(e.currentTarget),q=new URLSearchParams();
  for(const[k,v]of f.entries())q.set(k,String(v));
  q.set("specProfile",JSON.stringify(loadCraftingProfile()));
  q.set("lang",currentSiteLanguage());
  if(!f.has("premium"))q.set("premium","false");
  try{const x=await fetch(`/api/refine-scan?${q}`),j=await x.json();if(!x.ok)throw Error(j.error??"Falha no scanner de refino.");setR(j)}
  catch(x){setErr(x instanceof Error?x.message:"Erro inesperado.")}
  finally{setLoading(false)}
 }
 return <main className="shell"><AppSidebar/>
  <header className="hero"><div><div className="eyebrow">NOTAG • REFINING SCANNER</div><h1>Refine <span>Scanner</span></h1><p>{lang==="en"?"Automatically discover the most profitable refines using Europe prices, bonus city, Focus and your Specializations.":"Descobre automaticamente os refinos mais rentáveis com preços Europe, cidade de bónus, Focus e as tuas Especializações."}</p></div><div className="headerTools"><LanguageSelector/></div></header>
 <SpecsAwareness/>

  <section className="panel"><form key={settingsFormKey(settings,settingsReady)} onSubmit={scan} className="filters">
   <label>Material<select name="family" defaultValue="all"><option value="all">{lang==="en"?"All":"Todos"}</option><option value="metal">{lang==="en"?"Metal Bars":"Barras de Metal"}</option><option value="wood">{lang==="en"?"Planks":"Tábuas"}</option><option value="leather">{lang==="en"?"Leather":"Couro"}</option><option value="cloth">{lang==="en"?"Cloth":"Tecido"}</option><option value="stone">{lang==="en"?"Stone Blocks":"Blocos de Pedra"}</option></select></label>
   <label>{lang==="en"?"Minimum tier":"Tier mínimo"}<select name="tierMin" defaultValue="4">{[4,5,6,7,8].map(x=><option key={x}>{x}</option>)}</select></label>
   <label>{lang==="en"?"Maximum tier":"Tier máximo"}<select name="tierMax" defaultValue="8">{[4,5,6,7,8].map(x=><option key={x}>{x}</option>)}</select></label>
   <label>{lang==="en"?"Sell in":"Vender em"}<select name="sellCity" defaultValue={settings.refineSellCity}>{["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien","Black Market"].map(x=><option key={x}>{x}</option>)}</select></label>
   <label>{lang==="en"?"Available Focus":"Focus disponível"}<input name="focus" type="number" min="0" max="30000" defaultValue={settings.focus}/></label>
   <label>{lang==="en"?"Station Fee (Silver)":"Taxa da Estação (Silver)"}<input name="stationFee" type="number" min="0" defaultValue={settings.stationFee}/></label>
   <label>{lang==="en"?"Minimum return (%)":"Rentabilidade mínima (%)"}<input name="minRoi" type="number" defaultValue="5"/></label>
   <label>{lang==="en"?"Max data age (hours)":"Dados máx. (horas)"}<input name="maxAgeHours" type="number" min="1" max="48" defaultValue={settings.maxAgeHours}/></label>
   <label>{lang==="en"?"Maximum risk":"Risco máximo"}<select name="risk" defaultValue="Alto"><option value="Baixo">{lang==="en"?"Low":"Baixo"}</option><option value="Médio">{lang==="en"?"Medium":"Médio"}</option><option value="Alto">{lang==="en"?"High":"Alto"}</option></select></label>
   <label className="check"><input name="premium" type="checkbox" value="true" defaultChecked={settings.premium}/> Premium</label>
   <button className="scan" disabled={loading}>{loading?(lang==="en"?"Analyzing market…":"A analisar o mercado…"):(lang==="en"?"♻️ FIND BEST REFINES":"♻️ PROCURAR MELHORES REFINOS")}</button>
  </form></section>
  {err&&<div className="error">{err}</div>}

  {r&&<section className="results">
   <div className="resultsHead"><div><div className="eyebrow">♻️ REFINING OPPORTUNITIES</div><h2>{lang==="en"?"Best refines right now":"Melhores refinos agora"}</h2><p>{r.meta.approved} {lang==="en"?"approved opportunities from":"oportunidades aprovadas de"} {r.meta.scanned} {lang==="en"?"combinations analyzed.":"combinações analisadas."}</p></div><small>{lang==="en"?"Materials bought in the cheapest Royal City/Brecilien.":"Materiais comprados na cidade Royal/Brecilien mais barata."}</small></div>
   {r&&r.rows.length>0&&<div className="dataHealthBar"><div><span className="dataHealthTitle">📡 Market Data Health</span><strong>{health.healthyPct}% Fresh/Recent</strong><small>{health.total} {lang==="en"?"refines • oldest":"refinos • mais antigo"} {ageText(health.maxAgeMin)}</small></div><div className="dataHealthLegend"><span className="freshNow">Fresh {health.counts.freshNow}</span><span className="freshOk">Recent {health.counts.freshOk}</span><span className="freshAging">Aging {health.counts.freshAging}</span><span className="freshStale">Stale {health.counts.freshStale}</span></div></div>}<div className="resultItemSearch"><input value={itemSearch} onChange={e=>setItemSearch(e.target.value)} placeholder={lang==="en"?"Filter results: Metal Bar T6.1, Cloth 7.2…":"Filtrar resultados: Metal Bar T6.1, Cloth 7.2…"}/></div><div className="tableWrap financeTableWrap"><table className="financeTable"><thead><tr>
    <SortTh label="Item" field="name" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Refine in":"Refinar em"} field="specialtyCity" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Investment":"Investimento"} field="investment" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Profit":"Lucro"} field="profit" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Return":"Rentabilidade"} field="roi" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label="RRR" field="rrr" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label="Focus" field="focusPerRefine" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Age":"Idade"} field="dataAgeMin" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label={lang==="en"?"Risk":"Risco"} field="risk" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/>
    <SortTh label="Score" field="score" sortKey={sort.key} sortDir={sort.dir} onSort={sortBy}/><th>SOL</th><th>Watch</th><th>Portfolio</th>
   </tr></thead><tbody>
   {sortRows<Row>(r.rows.filter(x=>itemMatchesSearch(x.itemId,x.name,itemSearch)),sort.key,sort.dir).map(x=><tr className="clickable" onClick={()=>setSelected(x)} key={x.itemId}>
    <td><div className="item"><img src={itemImageUrl(x.itemId,{size:64})} alt=""/><div><strong>{x.name}</strong><span>T{x.tier}{x.enchant?`.${x.enchant}`:""} • {lang==="en"?"sell":"vender"}: {x.sellCity}</span></div></div></td>
    <td><b>{x.specialtyCity}</b><small className="qtyHint">{x.daily?<>Daily +{x.daily}%</>:null}</small></td>
    <td>{money(x.investment)}</td><td className="profit">+{money(x.profit)}</td><td><b>{x.roi.toFixed(1)}%</b><small className="qtyHint">{lang==="en"?"without Focus":"sem Focus"} {x.roiNoFocus.toFixed(1)}% • {lang==="en"?"with Focus":"com Focus"} {x.roiFocus.toFixed(1)}%</small></td>
    <td>{(x.rrr*100).toFixed(1)}%</td><td>{x.useFocus?<><b>{money(x.focusPerRefine)}</b><small className="qtyHint">{money(x.focusEfficiency)} {lang==="en"?"efficiency":"eficiência"}</small></>:<span>—</span>}</td>
    <td><span className={`dataFreshness ${dataHealthLevel(x.dataAgeMin)}`} title={dataHealthLabel(x.dataAgeMin,lang)}><i/>{ageText(x.dataAgeMin)}</span></td><td><span className={`risk ${x.risk.toLowerCase().replace("é","e")}`}>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[x.risk]??x.risk):x.risk}</span></td><td><span className={x.score>=80?"score hot":x.score>=60?"score good":"score"}>{x.score}</span></td><td>{(()=>{const rec=refineRecommendation({roi:x.roi,profit:x.profit,score:x.score,risk:x.risk,dataAgeMin:x.dataAgeMin,useFocus:x.useFocus,roiNoFocus:x.roiNoFocus,roiFocus:x.roiFocus},lang);return <span className={`solRecBadge ${rec.tone}`}>{rec.label}</span>})()}</td><td onClick={e=>e.stopPropagation()}><WatchlistButton source="REFINE_SCANNER" compact type="REFINE" itemId={x.itemId} name={x.name} route={lang==="en"?`Refine: ${x.specialtyCity} | Sell: ${x.sellCity}`:`Refinar: ${x.specialtyCity} | Vender: ${x.sellCity}`} refineCity={x.specialtyCity} sellCity={x.sellCity} investment={x.investment} profit={x.profit} roi={x.roi} dataAgeMin={x.dataAgeMin} sellPrice={x.sellPrice}/></td><td onClick={e=>e.stopPropagation()}><AddToPortfolioButton type="REFINE" itemId={x.itemId} name={x.name} route={lang==="en"?`Refine: ${x.specialtyCity} | Sell: ${x.sellCity}`:`Refinar: ${x.specialtyCity} | Vender: ${x.sellCity}`} investment={x.investment} expectedProfit={x.profit} focusUsed={x.useFocus?x.focusPerRefine:0} solScore={x.score} source="REFINE_SCANNER"/></td>
   </tr>)}
   {!r.rows.length&&<tr><td colSpan={13} className="empty">{lang==="en"?"No refine passed these filters. Try lowering the minimum return or increasing the maximum data age.":"Nenhum refino passou estes filtros. Experimenta baixar a rentabilidade mínima ou aumentar a idade máxima dos dados."}</td></tr>}
   </tbody></table></div>
   <div className="disclaimer">⚠️ {lang==="en"?"Albion Data Project prices depend on markets recently opened by players in-game. Confirm prices before executing a large refine.":"Os preços do Albion Data Project dependem dos mercados que os jogadores abriram recentemente no jogo. Confirma os preços antes de executar um refino grande."}</div>
  </section>}
  {selected&&<div className="overlay" onClick={()=>setSelected(null)}><aside className="drawer opportunityDrawer" onClick={e=>e.stopPropagation()}>
   <button className="close" onClick={()=>setSelected(null)}>×</button>
   <div className="detailHead"><img src={itemImageUrl(selected.itemId,{size:128})} alt=""/><div><div className="eyebrow">☀️ REFINE OPPORTUNITY DETAIL</div><h2>{selected.name}</h2><p>{lang==="en"?"Refine in":"Refinar em"} {selected.specialtyCity} → {lang==="en"?"sell in":"vender em"} {selected.sellCity}</p></div></div>
   <div className="detailGrid"><div><span>{lang==="en"?"Investment":"Investimento"}</span><strong>{money(selected.investment)}</strong></div><div><span>{lang==="en"?"Sell price":"Preço de venda"}</span><strong>{money(selected.sellPrice)}</strong></div><div><span>{lang==="en"?"Profit":"Lucro"}</span><strong className="profit">+{money(selected.profit)}</strong></div><div><span>{lang==="en"?"Return":"Rentabilidade"}</span><strong>{selected.roi.toFixed(1)}%</strong></div><div><span>{lang==="en"?"Risk":"Risco"}</span><strong>{selected.risk}</strong></div><div><span>Score</span><strong>{selected.score}/100</strong></div></div>
   {(()=>{const rec=refineRecommendation({roi:selected.roi,profit:selected.profit,score:selected.score,risk:selected.risk,dataAgeMin:selected.dataAgeMin,useFocus:selected.useFocus,roiNoFocus:selected.roiNoFocus,roiFocus:selected.roiFocus},lang);return <section className={`solRecommendation ${rec.tone}`}><div className="solRecommendationTop"><span>{lang==="en"?"☀️ SOL RECOMMENDS":"☀️ SOL RECOMENDA"}</span><strong>{rec.label}</strong></div><h3>{rec.headline}</h3><p>{rec.reason}</p><b>{rec.action}</b></section>})()}
   <section className="opportunityExplain"><h3>{lang==="en"?"Why does SOL like this opportunity?":"Por que o SOL gosta desta oportunidade?"}</h3><p>{lang==="en"?"It compares material costs in the cheapest cities with the final sale, applying Return Rate, Focus, specialization and Daily Bonus.":"Compara o custo dos materiais nas cidades mais baratas com a venda final, aplicando Return Rate, Focus, especialização e Daily Bonus."}</p></section>
   <div className="opportunityBreakdown"><div><span>Return Rate</span><b>{(selected.rrr*100).toFixed(1)}%</b></div><div><span>Daily Bonus</span><b>{selected.daily?`+${selected.daily}%`:"—"}</b></div><div><span>{lang==="en"?"Focus / refine":"Focus / refino"}</span><b>{selected.useFocus?money(selected.focusPerRefine):(lang==="en"?"No Focus":"Sem Focus")}</b></div><div><span>{lang==="en"?"Focus Efficiency":"Eficiência Focus"}</span><b>{money(selected.focusEfficiency)}</b></div><div><span>{lang==="en"?"Without Focus":"Sem Focus"}</span><b>{selected.roiNoFocus.toFixed(1)}%</b></div><div><span>{lang==="en"?"With Focus":"Com Focus"}</span><b>{selected.roiFocus.toFixed(1)}%</b></div></div>
   <div className="opportunityMaterials"><h3>{lang==="en"?"Shopping list":"Lista de compras"}</h3>{Object.entries(selected.shopping).map(([city,mats])=><div className="materialCity" key={city}><strong>{city}</strong>{mats.map(m=><div className="materialLine" key={`${city}-${m.id}`}><span>{m.qty}× {m.name}</span><b>{money(m.unitPrice)} {lang==="en"?"/ unit":"/ un."}</b><small><span className={`dataFreshness ${dataHealthLevel(m.ageMin)}`}><i/>{ageText(m.ageMin)}</span></small></div>)}</div>)}</div>
   <div className="opportunityFooter"><span className={`dataFreshness ${dataHealthLevel(selected.dataAgeMin)}`}><i/>{ageText(selected.dataAgeMin)}</span><WatchlistButton source="REFINE_SCANNER" type="REFINE" itemId={selected.itemId} name={selected.name} route={lang==="en"?`Refine: ${selected.specialtyCity} | Sell: ${selected.sellCity}`:`Refinar: ${selected.specialtyCity} | Vender: ${selected.sellCity}`} refineCity={selected.specialtyCity} sellCity={selected.sellCity} investment={selected.investment} profit={selected.profit} roi={selected.roi} dataAgeMin={selected.dataAgeMin} sellPrice={selected.sellPrice}/><AddToPortfolioButton type="REFINE" itemId={selected.itemId} name={selected.name} route={lang==="en"?`Refine: ${selected.specialtyCity} | Sell: ${selected.sellCity}`:`Refinar: ${selected.specialtyCity} | Vender: ${selected.sellCity}`} investment={selected.investment} expectedProfit={selected.profit} focusUsed={selected.useFocus?selected.focusPerRefine:0} solScore={selected.score} source="REFINE_SCANNER"/></div>
  </aside></div>}
  <footer>by Fate and Ryukk • NoTag Exclusive • 2026 • {lang==="en"?"Not affiliated with Sandbox Interactive.":"Não afiliado à Sandbox Interactive."}</footer>
 </main>
}
