"use client";
import {useEffect,useState} from "react";
type Bonus={category:string;bonus:number;city?:string};
export default function DailyBonusToday(){
 const [data,setData]=useState<{bonuses:Bonus[];available:boolean}|null>(null);
 useEffect(()=>{fetch("/api/daily-bonus").then(r=>r.json()).then(setData).catch(()=>setData({bonuses:[],available:false}))},[]);
 return <div className="dailyAuto">
   <div><b>☀️ Daily Production Bonus — Europe</b><small>Atualizado automaticamente após o reset diário</small></div>
   {!data?<span className="dailyStatus">A carregar…</span>:
    data.available?<div className="dailyChips">{data.bonuses.map((b,i)=><span key={i}><b>{b.category}</b> +{b.bonus}%{b.city?` • ${b.city}`:""}</span>)}</div>:
    <span className="dailyStatus">Ainda sem dados de hoje — cálculos usam 0% de Daily Bonus.</span>}
 </div>
}
