"use client";
import {useState} from "react";
import {addPortfolio,type PortfolioType} from "../../lib/portfolioClient";
export default function AddToPortfolioButton({type,itemId,name,route="",qty=1,investment,expectedProfit,focusUsed=0,solScore,source}:{type:PortfolioType;itemId:string;name:string;route?:string;qty?:number;investment:number;expectedProfit:number;focusUsed?:number;solScore?:number;source?:string}){
 const [added,setAdded]=useState(false);
 function add(){addPortfolio({type,itemId,name,route,qty:Math.max(1,qty),investment,expectedProfit,expectedRoi:investment?expectedProfit/investment*100:0,focusUsed,solScore,source});setAdded(true);setTimeout(()=>setAdded(false),1800)}
 return <button type="button" className="portfolioAdd" onClick={add}>{added?"✓ Adicionado":"＋ Portfolio"}</button>
}
