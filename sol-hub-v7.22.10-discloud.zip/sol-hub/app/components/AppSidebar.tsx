"use client";

import Link from "next/link";
import {useEffect,useState} from "react";
import {usePathname} from "next/navigation";
import UtcClock from "./UtcClock";
import {ALERTS_EVENT,loadAlertNotifications} from "../../lib/alertsClient";

const groups=[
  {label:"",items:[{href:"/",icon:"☀️",label:"Dashboard"}]},
  {label:"MARKET",items:[{href:"/flipper",icon:"↔",label:"Market Scanner"}]},
  {label:"PRODUCTION",items:[
    {href:"/crafting",icon:"⚒",label:"Craft Calculator"},
    {href:"/refining",icon:"♻️",label:"Refine Calculator"},
    {href:"/best-crafts",icon:"🔥",label:"Craft Scanner"},
    {href:"/best-refines",icon:"♻️",label:"Refine Scanner"},
  ]},
  {label:"INTELLIGENCE",items:[
    {href:"/optimizer",icon:"☀️",label:"SOL Optimizer"},
    {href:"/watchlist",icon:"⭐",label:"Watchlist"},
    {href:"/alerts",icon:"🔔",label:"Alerts"},
    {href:"/portfolio",icon:"📈",label:"Portfolio"},
  ]},
  {label:"PROFILE",items:[
    {href:"/specializations",icon:"⚙️",label:"Specializations"},
    {href:"/settings",icon:"🔧",label:"Settings"},
  ]},
  {label:"SUPPORT",items:[{href:"/feedback",icon:"💬",label:"Feedback"}]},
] as const;

export default function AppSidebar(){
  const pathname=usePathname();
  const [collapsed,setCollapsed]=useState(false);
  const [mobileOpen,setMobileOpen]=useState(false);
  const [unreadAlerts,setUnreadAlerts]=useState(0);

  useEffect(()=>{
    const saved=localStorage.getItem("notag-sidebar-collapsed")==="1";
    setCollapsed(saved);
    document.body.classList.toggle("sidebarCollapsed",saved);
    return()=>document.body.classList.remove("sidebarCollapsed");
  },[]);

  function toggleCollapse(){
    const next=!collapsed;
    setCollapsed(next);
    localStorage.setItem("notag-sidebar-collapsed",next?"1":"0");
    document.body.classList.toggle("sidebarCollapsed",next);
  }

  useEffect(()=>{setMobileOpen(false)},[pathname]);
  useEffect(()=>{const sync=()=>setUnreadAlerts(loadAlertNotifications().filter(x=>!x.read).length);sync();window.addEventListener(ALERTS_EVENT,sync);window.addEventListener("storage",sync);return()=>{window.removeEventListener(ALERTS_EVENT,sync);window.removeEventListener("storage",sync)}},[]);

  return <>
    <button className="mobileMenuButton" onClick={()=>setMobileOpen(true)} aria-label="Abrir menu">☰</button>
    {mobileOpen&&<button className="sidebarBackdrop" onClick={()=>setMobileOpen(false)} aria-label="Fechar menu"/>}
    <aside className={`appSidebar ${collapsed?"collapsed":""} ${mobileOpen?"mobileOpen":""}`}>
      <div className="sidebarBrand">
        <div className="brandMark">☀️</div>
        <div className="brandCopy"><strong>SOL HUB</strong><span>ALBION ECONOMY</span></div>
        <button className="collapseButton" onClick={toggleCollapse} aria-label={collapsed?"Expandir menu":"Recolher menu"}>{collapsed?"›":"‹"}</button>
      </div>

      <nav className="sidebarNav">
        {groups.map((g,gi)=><div className="sidebarGroup" key={`${g.label}-${gi}`}>
          {g.label&&<div className="sidebarGroupLabel">{g.label}</div>}
          {g.items.map(item=>{
            const active=item.href==="/"?pathname==="/":pathname.startsWith(item.href);
            return <Link key={item.href} href={item.href} className={active?"sidebarLink active": "sidebarLink"} title={collapsed?item.label:undefined}>
              <span className="sidebarIcon">{item.icon}</span><span className="sidebarLabel">{item.label}</span>{item.href==="/alerts"&&unreadAlerts>0&&<span className="sidebarAlertBadge">{unreadAlerts>99?"99+":unreadAlerts}</span>}
            </Link>
          })}
        </div>)}
      </nav>

      <div className="sidebarFooter">
        <div className="sidebarNetwork"><span className="sidebarNetworkDot"/><div><b>Albion Europe</b><small>Economy feed</small></div></div>
        <div className="sidebarServerRow">
          <div className="server sidebarServer"><span className="dot"/>Europe</div>
        </div>
        <UtcClock/>
        <small>by Fate and Ryukk • NoTag Exclusive</small>
      </div>
    </aside>
  </>;
}
