import type { SortDir } from "../../lib/sort";

export default function SortTh({label,field,sortKey,sortDir,onSort}:{label:string;field:string;sortKey:string;sortDir:SortDir;onSort:(field:string)=>void}){
 const active=sortKey===field;
 return <th aria-sort={active?(sortDir==="asc"?"ascending":"descending"):"none"}>
   <button type="button" className={`sortHead ${active?"active":""}`} onClick={()=>onSort(field)} title={`Ordenar por ${label}`}>
     {label}<span className="sortArrow">{active?(sortDir==="asc"?"▲":"▼"):"↕"}</span>
   </button>
 </th>
}