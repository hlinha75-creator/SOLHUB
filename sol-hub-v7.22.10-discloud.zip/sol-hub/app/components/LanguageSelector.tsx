"use client";

import {useEffect,useState} from "react";
import {updateSolHubLanguage} from "../../lib/settingsClient";

type Lang="pt-BR"|"en";
const STORAGE_KEY="sol-language";

const entries:Record<string,{pt:string;en:string}> = {
  "Specs configuradas": {pt:"Specs configuradas",en:"Specs configured"},
  "Os cálculos de Focus usam o teu perfil guardado.": {pt:"Os cálculos de Focus usam o teu perfil guardado.",en:"Focus calculations are using your saved profile."},
  "Ver Specs": {pt:"Ver Specs",en:"View Specs"},
  "Perfil de Especializações não configurado": {pt:"Perfil de Especializações não configurado",en:"Specialization profile not configured"},
  "Para resultados de Focus mais precisos, preenche as tuas Specs do Destiny Board.": {pt:"Para resultados de Focus mais precisos, preenche as tuas Specs do Destiny Board.",en:"For more accurate Focus results, fill in your Destiny Board Specs."},
  "Configurar Specs": {pt:"Configurar Specs",en:"Configure Specs"},
  "Estratégias a incluir": {pt:"Estratégias a incluir",en:"Strategies to include"},
  "Escolhe que motores económicos entram na pesquisa e competem pelo teu capital.": {pt:"Escolhe que motores económicos entram na pesquisa e competem pelo teu capital.",en:"Choose which economic engines enter the search and compete for your capital."},
  "Compra e venda entre mercados": {pt:"Compra e venda entre mercados",en:"Buy and sell between markets"},
  "Produção com Return Rate e Focus": {pt:"Produção com Return Rate e Focus",en:"Production with Return Rate and Focus"},
  "Refino com especializações e Focus": {pt:"Refino com especializações e Focus",en:"Refining with specializations and Focus"},
  "Seleciona pelo menos uma estratégia para o Optimizer.": {pt:"Seleciona pelo menos uma estratégia para o Optimizer.",en:"Select at least one strategy for the Optimizer."},
  "MARKET": {pt:"MERCADO",en:"MARKET"},
  "PRODUCTION": {pt:"PRODUÇÃO",en:"PRODUCTION"},
  "INTELLIGENCE": {pt:"INTELIGÊNCIA",en:"INTELLIGENCE"},
  "PROFILE": {pt:"PERFIL",en:"PROFILE"},
  "Crafting": {pt:"Crafting",en:"Crafting"},
  "Refining": {pt:"Refino",en:"Refining"},
  "Best Crafts": {pt:"Melhores Crafts",en:"Best Crafts"},
  "Best Refines": {pt:"Melhores Refines",en:"Best Refines"},
  "Optimizer": {pt:"Otimizador",en:"Optimizer"},
  "Portfolio": {pt:"Portfolio",en:"Portfolio"},
  "Specs": {pt:"Specs",en:"Specs"},
  "📈 Portfolio": {pt:"📈 Portfolio",en:"📈 Portfolio"},
  "Capital em aberto": {pt:"Capital em aberto",en:"Open capital"},
  "Lucro esperado em aberto": {pt:"Lucro esperado em aberto",en:"Expected open profit"},
  "Lucro real acumulado": {pt:"Lucro real acumulado",en:"Cumulative actual profit"},
  "Silver real / Focus": {pt:"Silver real / Focus",en:"Actual Silver / Focus"},
  "Operações em aberto": {pt:"Operações em aberto",en:"Open operations"},
  "operações à espera do resultado real.": {pt:"operações à espera do resultado real.",en:"operations awaiting the actual result."},
  "Data": {pt:"Data",en:"Date"},
  "Motor": {pt:"Motor",en:"Engine"},
  "Qtd.": {pt:"Qtd.",en:"Qty."},
  "Investimento": {pt:"Investimento",en:"Investment"},
  "Previsto": {pt:"Previsto",en:"Expected"},
  "Ações": {pt:"Ações",en:"Actions"},
  "✓ Fechar": {pt:"✓ Fechar",en:"✓ Close"},
  "Ainda não tens operações em aberto. Adiciona uma recomendação do Optimizer ao Portfolio.": {pt:"Ainda não tens operações em aberto. Adiciona uma recomendação do Optimizer ao Portfolio.",en:"You do not have any open operations yet. Add an Optimizer recommendation to the Portfolio."},
  "Histórico realizado": {pt:"Histórico realizado",en:"Realized history"},
  "Lucro real vs. previsão do Sol.": {pt:"Lucro real vs. previsão do Sol.",en:"Actual profit vs. Sol's forecast."},
  "Fechado": {pt:"Fechado",en:"Closed"},
  "Lucro real": {pt:"Lucro real",en:"Actual profit"},
  "Diferença": {pt:"Diferença",en:"Difference"},
  "Rentabilidade real": {pt:"Rentabilidade real",en:"Actual return"},
  "Quando fechares uma operação, o resultado real aparece aqui.": {pt:"Quando fechares uma operação, o resultado real aparece aqui.",en:"When you close an operation, the actual result will appear here."},

  "NOTAG • PERFORMANCE TRACKER": {pt:"NOTAG • ACOMPANHAMENTO DE PERFORMANCE",en:"NOTAG • PERFORMANCE TRACKER"},
  "Profit Portfolio": {pt:"Portfolio de Lucro",en:"Profit Portfolio"},
  "Regista as operações recomendadas pelo Sol e compara lucro previsto com o resultado real.": {pt:"Registre as operações recomendadas pelo Sol e compare o lucro previsto com o resultado real.",en:"Track Sol's recommended operations and compare expected profit with the real result."},
  "☀️ Dashboard": {pt:"☀️ Dashboard",en:"☀️ Dashboard"},
  "↔ Flipper": {pt:"↔ Flipper",en:"↔ Flipper"},
  "⚒ Crafting Calculator": {pt:"⚒ Calculadora de Craft",en:"⚒ Crafting Calculator"},
  "♻️ Refining Calculator": {pt:"♻️ Calculadora de Refino",en:"♻️ Refining Calculator"},
  "♻️ Refino": {pt:"♻️ Refino",en:"♻️ Refining"},
  "REFINING SPECS": {pt:"SPECS DE REFINO",en:"REFINING SPECS"},
  "Destino refining": {pt:"Destino do refino",en:"Refining destination"},
  "Em refining": {pt:"Em refino",en:"In refining"},
  "Especialização calculada": {pt:"Especialização calculada",en:"Calculated specialization"},
  "Calculada automaticamente pelo teu perfil de Especializações. Cada 10.000 de eficiência reduz o custo de Focus pela metade.": {pt:"Calculada automaticamente pelo seu perfil de Especializações. Cada 10.000 de eficiência reduz o custo de Focus pela metade.",en:"Automatically calculated from your Specializations profile. Every 10,000 Efficiency halves the Focus cost."},
  "Flipping, crafting e refining disputam o mesmo capital. O Sol escolhe apenas as oportunidades que passam os teus filtros.": {pt:"Flipping, crafting e refino disputam o mesmo capital. O Sol escolhe apenas as oportunidades que passam pelos seus filtros.",en:"Flipping, crafting, and refining compete for the same capital. Sol only selects opportunities that pass your filters."},
  "⚒ Crafting": {pt:"⚒ Crafting",en:"⚒ Crafting"},
  "♻️ Refining": {pt:"♻️ Refino",en:"♻️ Refining"},
  "♻️ Best Refines": {pt:"♻️ Melhores Refines",en:"♻️ Best Refines"},
  "☀️ Optimizer": {pt:"☀️ Otimizador",en:"☀️ Optimizer"},
  "⚙️ Specs": {pt:"⚙️ Specs",en:"⚙️ Specs"},
  "NOTAG • REFINING SCANNER": {pt:"NOTAG • SCANNER DE REFINO",en:"NOTAG • REFINING SCANNER"},
  "Descobre automaticamente os refinos mais rentáveis com preços Europe, cidade de bónus, Focus e as tuas Especializações.": {pt:"Descubra automaticamente os refinos mais rentáveis com preços Europe, cidade de bônus, Focus e suas Especializações.",en:"Automatically discover the most profitable refines using Europe prices, bonus city, Focus, and your Specializations."},
  "Melhores refinos agora": {pt:"Melhores refinos agora",en:"Best refines right now"},
  "PROCURAR MELHORES REFINOS": {pt:"PROCURAR MELHORES REFINOS",en:"FIND BEST REFINES"},
  "🔥 Best Crafts": {pt:"🔥 Melhores Crafts",en:"🔥 Best Crafts"},
  "☀️ Silver Optimizer": {pt:"☀️ Otimizador de Silver",en:"☀️ Silver Optimizer"},
  "⚙️ Especializações": {pt:"⚙️ Especializações",en:"⚙️ Specializations"},
  "DAILY EVENTS": {pt:"EVENTOS DIÁRIOS",en:"DAILY EVENTS"},
  "SOL HUB • ALBION ECONOMY": {pt:"SOL HUB • ECONOMIA DE ALBION",en:"SOL HUB • ALBION ECONOMY"},
  "Craft smarter. Trade better. Grow together.": {pt:"Craft smarter. Trade better. Grow together.",en:"Craft smarter. Trade better. Grow together."},
  "Market intelligence, crafting optimization and daily insights — built for NoTag, powered by SOL HUB. ☀️": {pt:"Market intelligence, crafting optimization and daily insights — built for NoTag, powered by SOL HUB. ☀️",en:"Market intelligence, crafting optimization and daily insights — built for NoTag, powered by SOL HUB. ☀️"},
  "NOTAG • MARKET INTELLIGENCE": {pt:"NOTAG • INTELIGÊNCIA DE MERCADO",en:"NOTAG • MARKET INTELLIGENCE"},
  "Flipper Intelligence": {pt:"Inteligência de Flipping",en:"Flipper Intelligence"},
  "Encontra rotas de compra e venda lucrativas e valida-as com volume histórico, volatilidade e risco.": {pt:"Encontre rotas de compra e venda lucrativas e valide-as com volume histórico, volatilidade e risco.",en:"Find profitable buy-and-sell routes and validate them using historical volume, volatility, and risk."},
  "NOTAG • CRAFTING INTELLIGENCE": {pt:"NOTAG • INTELIGÊNCIA DE CRAFTING",en:"NOTAG • CRAFTING INTELLIGENCE"},
  "Crafting Calculator": {pt:"Calculadora de Craft",en:"Crafting Calculator"},
  "Equipamento, poções e comida • receitas reais, Return Rate, especializações e lucro de crafting.": {pt:"Equipamentos, poções e comidas • receitas reais, Return Rate, especializações e lucro de crafting.",en:"Equipment, potions, and food • real recipes, Return Rate, specializations, and crafting profit."},
  "NOTAG • CRAFTING SCANNER": {pt:"NOTAG • SCANNER DE CRAFTING",en:"NOTAG • CRAFTING SCANNER"},
  "NOTAG • CAPITAL ALLOCATION": {pt:"NOTAG • ALOCAÇÃO DE CAPITAL",en:"NOTAG • CAPITAL ALLOCATION"},
  "Silver Optimizer": {pt:"Otimizador de Silver",en:"Silver Optimizer"},
  "NOTAG • DESTINY BOARD PROFILE": {pt:"NOTAG • PERFIL DO DESTINY BOARD",en:"NOTAG • DESTINY BOARD PROFILE"},
  "Metal Bars": {pt:"Barras de Metal",en:"Metal Bars"},
  "Planks": {pt:"Tábuas",en:"Planks"},
  "Leather": {pt:"Couro",en:"Leather"},
  "Cloth": {pt:"Tecido",en:"Cloth"},
  "Stone Blocks": {pt:"Blocos de Pedra",en:"Stone Blocks"},
  "EUROPE • MARKET INTELLIGENCE": {pt:"EUROPE • INTELIGÊNCIA DE MERCADO",en:"EUROPE • MARKET INTELLIGENCE"},
  "EUROPE • CRAFTING INTELLIGENCE": {pt:"EUROPE • INTELIGÊNCIA DE CRAFTING",en:"EUROPE • CRAFTING INTELLIGENCE"},
  "EUROPE • CRAFTING SCANNER": {pt:"EUROPE • SCANNER DE CRAFTING",en:"EUROPE • CRAFTING SCANNER"},
  "EUROPE • CAPITAL ALLOCATION": {pt:"EUROPE • ALOCAÇÃO DE CAPITAL",en:"EUROPE • CAPITAL ALLOCATION"},
  "CRAFTING PROFILE • EUROPE": {pt:"PERFIL DE CRAFTING • EUROPE",en:"CRAFTING PROFILE • EUROPE"},
  "DESTINY BOARD": {pt:"DESTINY BOARD",en:"DESTINY BOARD"},
  "CRAFT RESULT": {pt:"RESULTADO DO CRAFT",en:"CRAFT RESULT"},
  "BEST CRAFTS RIGHT NOW": {pt:"MELHORES CRAFTS AGORA",en:"BEST CRAFTS RIGHT NOW"},
  "SILVER PLAN 2.0": {pt:"PLANO DE SILVER 2.0",en:"SILVER PLAN 2.0"},
  "OPPORTUNITY DETAIL": {pt:"DETALHES DA OPORTUNIDADE",en:"OPPORTUNITY DETAIL"},
  "📡 Market Data Health": {pt:"📡 Saúde dos Dados de Mercado",en:"📡 Market Data Health"},
  "Score: rentabilidade + lucro + frescura + liquidez + estabilidade": {pt:"Pontuação: rentabilidade + lucro + atualização + liquidez + estabilidade",en:"Score: return + profit + freshness + liquidity + stability"},
  "⚠️ Volume é uma estimativa baseada no histórico diário do AODP, não quantidade live disponível. Confirma sempre o mercado antes de comprar.": {pt:"⚠️ O volume é uma estimativa baseada no histórico diário do AODP, não a quantidade disponível em tempo real. Sempre confira o mercado antes de comprar.",en:"⚠️ Volume is an estimate based on AODP daily history, not live available quantity. Always check the market before buying."},
  "by Fate and Ryukk • NoTag Exclusive • 2026 • Não afiliado à Sandbox Interactive.": {pt:"by Fate and Ryukk • NoTag Exclusive • 2026 • Não afiliado à Sandbox Interactive.",en:"by Fate and Ryukk • NoTag Exclusive • 2026 • Not affiliated with Sandbox Interactive."},
  "Watch": {pt:"Observar",en:"Watch"},


  "O teu dashboard diário para crafting, refining e oportunidades de mercado no Albion Europe.": {
    pt:"Seu dashboard diário para crafting, refino e oportunidades de mercado no Albion Europe.",
    en:"Your daily dashboard for crafting, refining, and market opportunities in Albion Europe."
  },
  "BÓNUS DE HOJE": {pt:"BÔNUS DE HOJE",en:"TODAY'S BONUS"},
  "BÓNUS DIÁRIO DE REFINO": {pt:"BÔNUS DIÁRIO DE REFINO",en:"DAILY REFINING BONUS"},
  "BÓNUS DIÁRIO DE CRAFT": {pt:"BÔNUS DIÁRIO DE CRAFT",en:"DAILY CRAFTING BONUS"},
  "Melhor cidade": {pt:"Melhor cidade",en:"Best city"},
  "A carregar bónus do dia…": {pt:"Carregando bônus do dia…",en:"Loading today's bonus…"},
  "Sem dados de produção para hoje": {pt:"Sem dados de produção para hoje",en:"No production data for today"},
  "O tracker ainda não publicou os bónus. Até lá, o Sol calcula com 0% de Daily Bonus.": {
    pt:"O tracker ainda não publicou os bônus. Até lá, o Sol calcula com 0% de bônus diário.",
    en:"The tracker has not published today's bonuses yet. Until then, Sol calculates with a 0% Daily Bonus."
  },
  "Sem eventos carregados": {pt:"Sem eventos carregados",en:"No events loaded"},
  "Os bónus de produção continuam disponíveis acima.": {pt:"Os bônus de produção continuam disponíveis acima.",en:"Production bonuses are still available above."},
  "À espera do próximo evento": {pt:"Aguardando o próximo evento",en:"Waiting for the next event"},
  "A informação aparece aqui assim que estiver disponível.": {pt:"A informação aparece aqui assim que estiver disponível.",en:"The information will appear here as soon as it is available."},

  "Encontra flips lucrativos e valida-os com volume histórico, volatilidade e risco.": {
    pt:"Encontre flips lucrativos e valide-os com volume histórico, volatilidade e risco.",
    en:"Find profitable flips and validate them using historical volume, volatility, and risk."
  },
  "Categoria": {pt:"Categoria",en:"Category"},
  "Capital disponível": {pt:"Capital disponível",en:"Available capital"},
  "Dados máx. (horas)": {pt:"Dados máx. (horas)",en:"Max data age (hours)"},
  "Comprar em": {pt:"Comprar em",en:"Buy in"},
  "Vender em": {pt:"Vender em",en:"Sell in"},
  "Modo de venda": {pt:"Modo de venda",en:"Selling mode"},
  "Lucro mínimo / un.": {pt:"Lucro mínimo / un.",en:"Minimum profit / unit"},
  "Rentabilidade mínima (%)": {pt:"Rentabilidade mínima (%)",en:"Minimum return (%)"},
  "Máx. por oportunidade (%)": {pt:"Máx. por oportunidade (%)",en:"Max per opportunity (%)"},
  "Máx. volume diário (%)": {pt:"Máx. volume diário (%)",en:"Max daily volume (%)"},
  "Todas as Cidades": {pt:"Todas as cidades",en:"All Cities"},
  "Todas as cidades + Black Market": {pt:"Todas as cidades + Black Market",en:"All cities + Black Market"},
  "Melhores oportunidades": {pt:"Melhores oportunidades",en:"Best opportunities"},
  "Compra": {pt:"Compra",en:"Buy"},
  "Venda": {pt:"Venda",en:"Sell"},
  "Lucro estimado": {pt:"Lucro estimado",en:"Estimated profit"},
  "Lucro / un.": {pt:"Lucro / un.",en:"Profit / unit"},
  "Liquidez": {pt:"Liquidez",en:"Liquidity"},
  "Risco": {pt:"Risco",en:"Risk"},
  "Média / dia": {pt:"Média / dia",en:"Average / day"},
  "Nenhuma oportunidade com estes filtros.": {pt:"Nenhuma oportunidade com estes filtros.",en:"No opportunities match these filters."},
  "Não foi possível montar um plano com estes filtros/capital.": {pt:"Não foi possível montar um plano com estes filtros/capital.",en:"Could not build a plan with these filters/capital."},
  "Onde meter o teu silver": {pt:"Onde investir seu silver",en:"Where to put your silver"},
  "Sugestão conservadora": {pt:"Sugestão conservadora",en:"Conservative suggestion"},
  "Preço médio diário — últimos 7 dias": {pt:"Preço médio diário — últimos 7 dias",en:"Average daily price — last 7 days"},
  "Preço vs média 7d": {pt:"Preço vs média 7d",en:"Price vs 7d average"},
  "Sem histórico suficiente para gráfico.": {pt:"Sem histórico suficiente para o gráfico.",en:"Not enough history for a chart."},
  "O histórico do AODP é usado como sinal de liquidez e estabilidade. Não representa stock live nem garante que consigas executar todas as unidades ao mesmo preço.": {
    pt:"O histórico do AODP é usado como sinal de liquidez e estabilidade. Não representa estoque em tempo real nem garante que você consiga executar todas as unidades ao mesmo preço.",
    en:"AODP history is used as a liquidity and stability signal. It does not represent live stock and does not guarantee you can execute every unit at the same price."
  },

  "Equipamento, poções e comida • receitas reais, Return Rate e lucro de crafting.": {
    pt:"Equipamentos, poções e comidas • receitas reais, Return Rate e lucro de crafting.",
    en:"Equipment, potions, and food • real recipes, Return Rate, and crafting profit."
  },
  "Procura: Cleric Robe, Healing Potion, Stew…": {pt:"Buscar: Cleric Robe, Healing Potion, Stew…",en:"Search: Cleric Robe, Healing Potion, Stew…"},
  "Selecionado:": {pt:"Selecionado:",en:"Selected:"},
  "Quantidade": {pt:"Quantidade",en:"Quantity"},
  "Craftar em": {pt:"Craftar em",en:"Craft in"},
  "Comprar materiais": {pt:"Comprar materiais",en:"Buy materials"},
  "Focus disponível": {pt:"Focus disponível",en:"Available Focus"},
  "Taxa da Estação (Silver)": {pt:"Taxa da estação (Silver)",en:"Station Fee (Silver)"},
  "— por 100 de nutrição": {pt:"— por 100 de nutrição",en:"— per 100 nutrition"},
  "Cidade de bónus:": {pt:"Cidade de bônus:",en:"Bonus city:"},
  "Cidade com especialidade": {pt:"Cidade com especialidade",en:"Specialty city"},
  "Qualquer Cidade Real": {pt:"Qualquer cidade real",en:"Any Royal City"},
  "Qualquer Cidade + Focus": {pt:"Qualquer cidade + Focus",en:"Any City + Focus"},
  "Especialidade + Focus": {pt:"Especialidade + Focus",en:"Specialty + Focus"},
  "Custo bruto materiais": {pt:"Custo bruto dos materiais",en:"Gross material cost"},
  "Materiais efetivos": {pt:"Materiais efetivos",en:"Effective materials"},
  "Taxa da estação": {pt:"Taxa da estação",en:"Station fee"},
  "Taxas de mercado": {pt:"Taxas de mercado",en:"Market fees"},
  "Custo total": {pt:"Custo total",en:"Total cost"},
  "Venda / unidade": {pt:"Venda / unidade",en:"Sale / unit"},
  "Lucro / unidade": {pt:"Lucro / unidade",en:"Profit / unit"},
  "Lucro total": {pt:"Lucro total",en:"Total profit"},
  "Itens produzidos": {pt:"Itens produzidos",en:"Items produced"},
  "Crafts com Focus": {pt:"Crafts com Focus",en:"Crafts with Focus"},
  "Focus / craft": {pt:"Focus / craft",en:"Focus / craft"},
  "Focus usado": {pt:"Focus usado",en:"Focus used"},
  "Daily aplicado": {pt:"Bônus diário aplicado",en:"Daily Bonus applied"},
  "Calculada pelo teu perfil de Especializações": {pt:"Calculada pelo seu perfil de Especializações",en:"Calculated from your Specializations profile"},
  "Retorno de recursos": {pt:"Retorno de recursos",en:"Resource return"},
  "Return Rate por cidade": {pt:"Return Rate por cidade",en:"Return Rate by city"},
  "O Return Rate do resultado é calculado automaticamente com bónus base, especialidade da cidade, Focus disponível e o Daily Bonus do item quando aplicável.": {
    pt:"O Return Rate do resultado é calculado automaticamente com bônus base, especialidade da cidade, Focus disponível e o bônus diário do item quando aplicável.",
    en:"The result's Return Rate is calculated automatically using the base bonus, city specialty, available Focus, and the item's Daily Bonus when applicable."
  },
  "Cidades Reais têm 18% de Production Bonus base. Se o item pertence ao bónus específico da cidade, soma +15%. Focus soma +59% e o Daily Bonus do item/grupo soma +10% ou +20%.": {
    pt:"As cidades reais têm 18% de Production Bonus base. Se o item pertence ao bônus específico da cidade, soma +15%. Focus soma +59% e o bônus diário do item/grupo soma +10% ou +20%.",
    en:"Royal Cities have an 18% base Production Bonus. If the item belongs to that city's specialty, add +15%. Focus adds +59%, and the item's/group's Daily Bonus adds +10% or +20%."
  },
  "Materiais não retornáveis (artifacts/tokens) não recebem Return Rate.": {
    pt:"Materiais não retornáveis (artifacts/tokens) não recebem Return Rate.",
    en:"Non-returnable materials (artifacts/tokens) do not receive Return Rate."
  },
  "O modo “Mais barato” escolhe a cidade mais barata individualmente para cada material.": {
    pt:"O modo “Mais barato” escolhe a cidade mais barata individualmente para cada material.",
    en:"“Cheapest” mode selects the cheapest city individually for each material."
  },
  "Os preços vêm do AODP e podem estar desatualizados. Confirma preços e quantidades no jogo antes de craftar.": {
    pt:"Os preços vêm do AODP e podem estar desatualizados. Confirme preços e quantidades no jogo antes de craftar.",
    en:"Prices come from AODP and may be outdated. Check prices and quantities in-game before crafting."
  },
  "✨ Mais barato por material": {pt:"✨ Mais barato por material",en:"✨ Cheapest per material"},
  "💡 Cidade recomendada": {pt:"💡 Cidade recomendada",en:"💡 Recommended city"},
  "📦 Materiais": {pt:"📦 Materiais",en:"📦 Materials"},
  "⚠️ Mercado": {pt:"⚠️ Mercado",en:"⚠️ Market"},

  "O scanner procura crafts rentáveis automaticamente e ordena-os por oportunidade.": {
    pt:"O scanner procura crafts rentáveis automaticamente e os ordena por oportunidade.",
    en:"The scanner automatically finds profitable crafts and ranks them by opportunity."
  },
  "Melhores oportunidades de crafting": {pt:"Melhores oportunidades de crafting",en:"Best crafting opportunities"},
  "Tipo de craft": {pt:"Tipo de craft",en:"Craft type"},
  "Tipo de item": {pt:"Tipo de item",en:"Item type"},
  "Tier mínimo": {pt:"Tier mínimo",en:"Minimum tier"},
  "Tier máximo": {pt:"Tier máximo",en:"Maximum tier"},
  "Todos": {pt:"Todos",en:"All"},
  "Equipamento": {pt:"Equipamento",en:"Equipment"},
  "⚔️ Armas": {pt:"⚔️ Armas",en:"⚔️ Weapons"},
  "🐎 Montarias": {pt:"🐎 Montarias",en:"🐎 Mounts"},
  "Todas as cidades": {pt:"Todas as cidades",en:"All cities"},
  "Black Market indisponível para montarias.": {pt:"Black Market indisponível para montarias.",en:"Black Market unavailable for mounts."},
  "Black Market indisponível para poções.": {pt:"Black Market indisponível para poções.",en:"Black Market unavailable for potions."},

  "🛡️ Armaduras": {pt:"🛡️ Armaduras",en:"🛡️ Armor"},
  "🛡 Off-hands": {pt:"🛡 Off-hands",en:"🛡 Off-hands"},
  "🧥 Capas": {pt:"🧥 Capas",en:"🧥 Capes"},
  "🎒 Bolsas": {pt:"🎒 Bolsas",en:"🎒 Bags"},
  "⛏️ Gathering": {pt:"⛏️ Gathering",en:"⛏️ Gathering"},
  "⚔️ Arma": {pt:"⚔️ Arma",en:"⚔️ Weapon"},
  "🛡️ Armadura": {pt:"🛡️ Armadura",en:"🛡️ Armor"},
  "🛡 Off-hand": {pt:"🛡 Off-hand",en:"🛡 Off-hand"},
  "🧥 Capa": {pt:"🧥 Capa",en:"🧥 Cape"},
  "🎒 Bolsa": {pt:"🎒 Bolsa",en:"🎒 Bag"},

  "🧪 Poções": {pt:"🧪 Poções",en:"🧪 Potions"},
  "🍲 Comida": {pt:"🍲 Comida",en:"🍲 Food"},
  "Faz um scan para o SOL HUB procurar oportunidades. ☀️": {
    pt:"Faça um scan para o SOL HUB procurar oportunidades. ☀️",
    en:"Run a scan so SOL HUB can find opportunities. ☀️"
  },
  "Materiais na cidade mais barata • Inclui equipamento, poções e comida • batches são calculados pela quantidade produzida": {
    pt:"Materiais na cidade mais barata • Inclui equipamentos, poções e comidas • batches são calculados pela quantidade produzida",
    en:"Materials from the cheapest city • Includes equipment, potions, and food • batches are calculated by output quantity"
  },
  "Score combina rentabilidade, lucro e eficiência de capital.": {pt:"O score combina rentabilidade, lucro e eficiência de capital.",en:"Score combines return, profit, and capital efficiency."},
  "⚠️ O scanner usa preços AODP e uma amostra de equipamento craftável. Confirma preços, taxas da estação e liquidez no jogo antes de investir.": {
    pt:"⚠️ O scanner usa preços do AODP e uma amostra de equipamentos craftáveis. Confirme preços, taxas da estação e liquidez no jogo antes de investir.",
    en:"⚠️ The scanner uses AODP prices and a sample of craftable equipment. Check prices, station fees, and liquidity in-game before investing."
  },

  "Flipping e crafting disputam o mesmo capital. O Sol escolhe apenas as oportunidades que passam os teus filtros.": {
    pt:"Flipping e crafting disputam o mesmo capital. O Sol escolhe apenas as oportunidades que passam pelos seus filtros.",
    en:"Flipping and crafting compete for the same capital. Sol only selects opportunities that pass your filters."
  },
  "Destino crafting": {pt:"Destino do crafting",en:"Crafting destination"},
  "Risco máximo": {pt:"Risco máximo",en:"Maximum risk"},
  "Baixo": {pt:"Baixo",en:"Low"},
  "Médio": {pt:"Médio",en:"Medium"},
  "Alto": {pt:"Alto",en:"High"},
  "Alocação recomendada": {pt:"Alocação recomendada",en:"Recommended allocation"},
  "☀️ PLANO DO SOL": {pt:"☀️ PLANO DO SOL",en:"☀️ SOL PLAN"},

  "Em flips": {pt:"Em flips",en:"In flips"},
  "Em crafting": {pt:"Em crafting",en:"In crafting"},
  "Reserva": {pt:"Reserva",en:"Reserve"},
  "Focus restante": {pt:"Focus restante",en:"Remaining Focus"},
  "Oportunidades consideradas": {pt:"Oportunidades consideradas",en:"Opportunities considered"},
  "Porquê": {pt:"Por quê",en:"Why"},
  "Investir": {pt:"Investir",en:"Invest"},
  "Rentabilidade do plano": {pt:"Rentabilidade do plano",en:"Plan return"},
  "O Sol não encontrou oportunidades suficientes para recomendar investimento com estes filtros.": {
    pt:"O Sol não encontrou oportunidades suficientes para recomendar investimento com estes filtros.",
    en:"Sol did not find enough opportunities to recommend an investment with these filters."
  },
  "O optimizer não é obrigado a gastar tudo. Capital sem oportunidade aceitável fica em reserva.": {
    pt:"O otimizador não é obrigado a gastar tudo. Capital sem oportunidade aceitável fica em reserva.",
    en:"The optimizer does not have to spend everything. Capital without an acceptable opportunity stays in reserve."
  },
  "O plano limita concentração por oportunidade.": {pt:"O plano limita a concentração por oportunidade.",en:"The plan limits concentration per opportunity."},

  "Especializações": {pt:"Especializações",en:"Specializations"},
  "Replica a tua árvore do Destiny Board: General Spec da família + Spec individual de cada produto.": {
    pt:"Replique sua árvore do Destiny Board: General Spec da família + Spec individual de cada produto.",
    en:"Replicate your Destiny Board tree: family General Spec + each product's individual Spec."
  },
  "A carregar perfil…": {pt:"Carregando perfil…",en:"Loading profile…"},
  "A carregar árvores e produtos do Albion…": {pt:"Carregando árvores e produtos do Albion…",en:"Loading Albion trees and products…"},
  "Perfil local": {pt:"Perfil local",en:"Local profile"},
  "Persistente neste browser e preparado para associação ao Discord.": {
    pt:"Persistente neste navegador e preparado para associação ao Discord.",
    en:"Persistent in this browser and ready for Discord association."
  },
  "PERFIL ATIVO": {pt:"PERFIL ATIVO",en:"ACTIVE PROFILE"},
  "Árvores de Crafting": {pt:"Árvores de Crafting",en:"Crafting Trees"},
  "General Trees": {pt:"Árvores gerais",en:"General Trees"},
  "configuradas": {pt:"configuradas",en:"configured"},
  "produtos configurados": {pt:"produtos configurados",en:"products configured"},
  "especializações maxed": {pt:"especializações no máximo",en:"maxed specializations"},
  "Eficiência de Focus total": {pt:"Eficiência de Focus total",en:"Total Focus Efficiency"},
  "Qualidade do equipamento": {pt:"Qualidade do equipamento",en:"Equipment quality"},
  "Qualidade já faz parte do perfil": {pt:"A qualidade já faz parte do perfil",en:"Quality is already part of the profile"},
  "A General Tree beneficia toda a família. Cada Spec individual dá o maior bónus ao próprio produto e um bónus menor aos restantes itens da mesma árvore.": {
    pt:"A General Tree beneficia toda a família. Cada Spec individual dá o maior bônus ao próprio produto e um bônus menor aos demais itens da mesma árvore.",
    en:"The General Tree benefits the entire family. Each individual Spec gives the largest bonus to its own product and a smaller bonus to the other items in the same tree."
  },
  "Login Discord será implementado brevemente": {pt:"O login com Discord será implementado em breve",en:"Discord login will be implemented soon"},
  "O perfil de crafting será associado à conta do membro e as permissões poderão seguir as roles do servidor da guilda.": {
    pt:"O perfil de crafting será associado à conta do membro e as permissões poderão seguir os cargos do servidor da guilda.",
    en:"The crafting profile will be linked to the member's account, and permissions may follow the guild server roles."
  },
  "DISCORD • BREVEMENTE": {pt:"DISCORD • EM BREVE",en:"DISCORD • COMING SOON"},
  "⇧ Importar": {pt:"⇧ Importar",en:"⇧ Import"},
  "⇩ Exportar": {pt:"⇩ Exportar",en:"⇩ Export"},
  "Procurar árvore ou item…": {pt:"Buscar árvore ou item…",en:"Search tree or item…"},

  "NOTAG • REFINING INTELLIGENCE": {pt:"NOTAG • INTELIGÊNCIA DE REFINO",en:"NOTAG • REFINING INTELLIGENCE"},
  "Refining Calculator": {pt:"Calculadora de Refino",en:"Refining Calculator"},
  "Calcula Return Rate, Focus, custos, taxas e lucro de refino com preços reais do Albion Europe.": {pt:"Calcule Return Rate, Focus, custos, taxas e lucro de refino com preços reais do Albion Europe.",en:"Calculate Return Rate, Focus, costs, fees, and refining profit using real Albion Europe prices."},
  "Material": {pt:"Material",en:"Material"},
  "Encantamento": {pt:"Encantamento",en:"Enchant"},
  "Refinar em": {pt:"Refinar em",en:"Refine in"},
  "Eficiência de Focus": {pt:"Eficiência de Focus",en:"Focus Efficiency"},
  "Cada 10.000 de eficiência reduz o custo de Focus pela metade.": {pt:"Cada 10.000 de eficiência reduz o custo de Focus pela metade.",en:"Every 10,000 Efficiency halves the Focus cost."},
  "Calcular refino": {pt:"Calcular refino",en:"Calculate refining"},
  "A calcular…": {pt:"Calculando…",en:"Calculating…"},
  "REFINING RESULT": {pt:"RESULTADO DO REFINO",en:"REFINING RESULT"},
  "Especialidade:": {pt:"Especialidade:",en:"Specialty:"},
  "Dados de venda:": {pt:"Dados de venda:",en:"Sale data:"},
  "Quantidade refinada": {pt:"Quantidade refinada",en:"Refined quantity"},
  "Focus / refino": {pt:"Focus / refino",en:"Focus / refine"},
  "Refinos com Focus": {pt:"Refinos com Focus",en:"Refines with Focus"},
  "📦 Materiais necessários": {pt:"📦 Materiais necessários",en:"📦 Required materials"},
  "O modo “Mais barato” procura o melhor preço de cada ingrediente individualmente.": {pt:"O modo “Mais barato” procura o melhor preço de cada ingrediente individualmente.",en:"“Cheapest” mode finds the best price for each ingredient individually."},
  "O retorno é aplicado apenas aos materiais marcados como retornáveis pela receita do Albion.": {pt:"O retorno é aplicado apenas aos materiais marcados como retornáveis pela receita do Albion.",en:"Return is applied only to materials marked as returnable by the Albion recipe."},
  "Origem": {pt:"Origem",en:"Source"},
  "Preço/un.": {pt:"Preço/un.",en:"Price/unit"},
  "Qtd. bruta": {pt:"Qtd. bruta",en:"Gross qty."},
  "Retorno": {pt:"Retorno",en:"Return"},
  "Qtd. efetiva": {pt:"Qtd. efetiva",en:"Effective qty."},
  "Custo efetivo": {pt:"Custo efetivo",en:"Effective cost"},
  "Dados": {pt:"Dados",en:"Data age"},
  "BEST REFINING CITY": {pt:"MELHOR CIDADE DE REFINO",en:"BEST REFINING CITY"},
  "Comparação de Return Rate": {pt:"Comparação de Return Rate",en:"Return Rate comparison"},
  "O Sol compara automaticamente as cidades para esta família de material.": {pt:"O Sol compara automaticamente as cidades para esta família de material.",en:"Sol automatically compares cities for this material family."},
  "A cidade especializada recebe +40% de Production Bonus de refino.": {pt:"A cidade especializada recebe +40% de Production Bonus de refino.",en:"The specialty city receives a +40% refining Production Bonus."},
  "♻️ Cidade especializada": {pt:"♻️ Cidade especializada",en:"♻️ Specialty city"},
  "O Focus disponível é distribuído pelo máximo de refinos possível. A Eficiência de Focus reduz o custo por refino.": {pt:"O Focus disponível é distribuído pelo máximo de refinos possível. A Eficiência de Focus reduz o custo por refino.",en:"Available Focus is allocated to as many refines as possible. Focus Efficiency reduces the Focus cost per refine."},
  "COMECE A CALCULAR": {pt:"COMECE A CALCULAR",en:"START CALCULATING"},
  "Escolha o material e as condições do refino": {pt:"Escolha o material e as condições do refino",en:"Choose the material and refining conditions"},
  "O Sol usa a receita real, preços do Europe, Return Rate, Daily Bonus, Focus e taxas para calcular o resultado.": {pt:"O Sol usa a receita real, preços do Europe, Return Rate, Daily Bonus, Focus e taxas para calcular o resultado.",en:"Sol uses the real recipe, Europe prices, Return Rate, Daily Bonus, Focus, and fees to calculate the result."},
  "Premium": {pt:"Premium",en:"Premium"},
  "Tier": {pt:"Tier",en:"Tier"},
  "Enchant": {pt:"Encantamento",en:"Enchant"},
  "Armas": {pt:"Armas",en:"Weapons"},
  "Armaduras": {pt:"Armaduras",en:"Armor"},
  "A carregar…": {pt:"Carregando…",en:"Loading…"},
  "Market Scanner": {pt:"Market Scanner",en:"Market Scanner"},
  "Craft Calculator": {pt:"Calculadora de Craft",en:"Craft Calculator"},
  "Refine Calculator": {pt:"Calculadora de Refino",en:"Refine Calculator"},
  "SOL Optimizer": {pt:"SOL Optimizer",en:"SOL Optimizer"},
  "Watchlist": {pt:"Watchlist",en:"Watchlist"},

  "Bags": {pt:"Bolsas",en:"Bags"},
  "Capes": {pt:"Capas",en:"Capes"},
  "Off-hands": {pt:"Off-hands",en:"Off-hands"},
  "Mounts": {pt:"Montarias",en:"Mounts"},
  "Taxas": {pt:"Taxas",en:"Fees"},
  "Capital": {pt:"Capital",en:"Capital"},
  "investidos": {pt:"investidos",en:"invested"},
  "lucro estimado": {pt:"lucro estimado",en:"estimated profit"},
  "lucro potencial": {pt:"lucro potencial",en:"potential profit"},
  "Score": {pt:"Score",en:"Score"},
  "Volatilidade": {pt:"Volatilidade",en:"Volatility"},
  "Volume 7d": {pt:"Volume 7d",en:"7d volume"},
  "Instant Sell": {pt:"Venda instantânea",en:"Instant Sell"},
  "Sell Order": {pt:"Ordem de venda",en:"Sell Order"},
  "Instant Sell / Buy Order": {pt:"Venda instantânea / Ordem de compra",en:"Instant Sell / Buy Order"},
  "Black Market": {pt:"Black Market",en:"Black Market"},
  "Europe": {pt:"Europe",en:"Europe"},
  // V7.22.3 — full language audit: Feedback, Settings and Specializations
  "Sugestões &": {pt:"Sugestões &",en:"Suggestions &"},
  "Encontraste um problema ou tens uma ideia para melhorar o Consultor? Envia diretamente para a equipa NoTag. ☀️": {pt:"Encontrou um problema ou tem uma ideia para melhorar o Consultor? Envie diretamente para a equipe NoTag. ☀️",en:"Found a problem or have an idea to improve SOL HUB? Send it directly to the NoTag team. ☀️"},
  "Ajuda-nos a melhorar": {pt:"Ajude-nos a melhorar",en:"Help us improve"},
  "Os reports são enviados para um canal privado da equipa através de Discord Webhook.": {pt:"Os reports são enviados para um canal privado da equipe através de Discord Webhook.",en:"Reports are sent to the team's private channel through a Discord Webhook."},
  "Que tipo de feedback queres enviar?": {pt:"Que tipo de feedback você quer enviar?",en:"What type of feedback do you want to send?"},
  "Escolhe a opção que melhor descreve o assunto.": {pt:"Escolha a opção que melhor descreve o assunto.",en:"Choose the option that best describes the issue."},
  "Reportar um erro": {pt:"Reportar um erro",en:"Report a bug"},
  "Algo não funciona como deveria.": {pt:"Algo não funciona como deveria.",en:"Something is not working as expected."},
  "Sugerir funcionalidade": {pt:"Sugerir funcionalidade",en:"Suggest a feature"},
  "Uma ideia para melhorar o Consultor.": {pt:"Uma ideia para melhorar o Consultor.",en:"An idea to improve SOL HUB."},
  "Dados / cálculo incorreto": {pt:"Dados / cálculo incorreto",en:"Incorrect data / calculation"},
  "Preço, retorno, taxa ou resultado suspeito.": {pt:"Preço, retorno, taxa ou resultado suspeito.",en:"A suspicious price, return, fee, or result."},
  "Sugestão de interface": {pt:"Sugestão de interface",en:"Interface suggestion"},
  "Layout, navegação ou experiência de utilização.": {pt:"Layout, navegação ou experiência de uso.",en:"Layout, navigation, or user experience."},
  "Outro": {pt:"Outro",en:"Other"},
  "Tudo o que não encaixa nas opções acima.": {pt:"Tudo o que não se encaixa nas opções acima.",en:"Anything that does not fit the options above."},
  "Conta-nos o que se passa": {pt:"Conte-nos o que está acontecendo",en:"Tell us what is happening"},
  "Quanto mais contexto, mais depressa conseguimos perceber o caso.": {pt:"Quanto mais contexto, mais rápido conseguimos entender o caso.",en:"The more context you provide, the faster we can understand the issue."},
  "Página afetada": {pt:"Página afetada",en:"Affected page"},
  "Contacto Discord": {pt:"Contato Discord",en:"Discord contact"},
  "(opcional)": {pt:"(opcional)",en:"(optional)"},
  "Título": {pt:"Título",en:"Title"},
  "Descrição": {pt:"Descrição",en:"Description"},
  "Item / referência": {pt:"Item / referência",en:"Item / reference"},
  "Cidade": {pt:"Cidade",en:"City"},
  "O que esperavas que acontecesse": {pt:"O que você esperava que acontecesse",en:"What did you expect to happen"},
  "O que aconteceu": {pt:"O que aconteceu",en:"What happened"},
  "Anexos": {pt:"Anexos",en:"Attachments"},
  "Adiciona screenshots ou ficheiros que ajudem a perceber o problema.": {pt:"Adicione screenshots ou arquivos que ajudem a entender o problema.",en:"Add screenshots or files that help us understand the problem."},
  "Adicionar outros anexos": {pt:"Adicionar outros anexos",en:"Add more attachments"},
  "Selecionar anexos": {pt:"Selecionar anexos",en:"Select attachments"},
  "PNG, JPG, WEBP, GIF, PDF, TXT ou LOG • máximo 3 ficheiros • 8 MB por ficheiro": {pt:"PNG, JPG, WEBP, GIF, PDF, TXT ou LOG • máximo de 3 arquivos • 8 MB por arquivo",en:"PNG, JPG, WEBP, GIF, PDF, TXT or LOG • maximum 3 files • 8 MB per file"},
  "Procurar ficheiros": {pt:"Procurar arquivos",en:"Browse files"},
  "Informação técnica": {pt:"Informação técnica",en:"Technical information"},
  "Ajuda-nos a reproduzir erros sem te obrigar a procurar estes dados.": {pt:"Ajude-nos a reproduzir erros sem você precisar procurar esses dados.",en:"Helps us reproduce errors without making you look up this information."},
  "Incluir dados técnicos": {pt:"Incluir dados técnicos",en:"Include technical data"},
  "Versão do Consultor, página de origem, idioma e identificação do browser. Não enviamos o endereço do webhook para o browser.": {pt:"Versão do Consultor, página de origem, idioma e identificação do navegador. Não enviamos o endereço do webhook para o navegador.",en:"SOL HUB version, source page, language, and browser identification. The webhook address is never sent to the browser."},
  "O report será enviado diretamente para o canal privado configurado pela NoTag.": {pt:"O report será enviado diretamente para o canal privado configurado pela NoTag.",en:"The report will be sent directly to the private channel configured by NoTag."},
  "☀️ Enviar feedback": {pt:"☀️ Enviar feedback",en:"☀️ Send feedback"},
  "A enviar…": {pt:"Enviando…",en:"Sending…"},
  "Outra / Geral": {pt:"Outra / Geral",en:"Other / General"},
  "Ex.: Guardar filtros favoritos": {pt:"Ex.: Salvar filtros favoritos",en:"E.g. Save favorite filters"},
  "Ex.: Best Refines não apresenta resultados": {pt:"Ex.: Best Refines não apresenta resultados",en:"E.g. Refine Scanner shows no results"},
  "Explica o que encontraste ou a tua sugestão…": {pt:"Explique o que encontrou ou a sua sugestão…",en:"Explain what you found or your suggestion…"},
  "Ex.: Esperava ver os materiais e o lucro do refine.": {pt:"Ex.: Esperava ver os materiais e o lucro do refino.",en:"E.g. I expected to see the materials and refining profit."},
  "Ex.: Surge uma mensagem de erro e não aparecem resultados.": {pt:"Ex.: Surge uma mensagem de erro e não aparecem resultados.",en:"E.g. An error message appears and no results are shown."},

  "Define uma vez as tuas preferências e o SOL HUB aplica-as automaticamente nas ferramentas económicas.": {pt:"Defina suas preferências uma vez e o SOL HUB as aplicará automaticamente às ferramentas econômicas.",en:"Set your preferences once and SOL HUB will automatically apply them across the economic tools."},
  "Preferências globais": {pt:"Preferências globais",en:"Global preferences"},
  "Estas definições ficam guardadas neste browser. Podes continuar a alterar qualquer campo diretamente numa calculadora sem mudar o valor global.": {pt:"Estas configurações ficam salvas neste navegador. Você pode continuar alterando qualquer campo diretamente em uma calculadora sem mudar o valor global.",en:"These settings are stored in this browser. You can still change any field directly in a calculator without changing the global value."},
  "Conta & Mercado": {pt:"Conta & Mercado",en:"Account & Market"},
  "Taxas e preferências usadas nas análises de mercado.": {pt:"Taxas e preferências usadas nas análises de mercado.",en:"Fees and preferences used in market analysis."},
  "Premium ativo": {pt:"Premium ativo",en:"Premium active"},
  "Usa as taxas de mercado correspondentes a Premium.": {pt:"Usa as taxas de mercado correspondentes ao Premium.",en:"Use the market fees that apply to Premium."},
  "Cidade de mercado preferida": {pt:"Cidade de mercado preferida",en:"Preferred market city"},
  "Usada como ponto de partida no Flipper.": {pt:"Usada como ponto de partida no Market Scanner.",en:"Used as the starting point in Market Scanner."},
  "Dados máximos (horas)": {pt:"Dados máximos (horas)",en:"Maximum data age (hours)"},
  "Idade máxima dos preços em scanners e Optimizer.": {pt:"Idade máxima dos preços nos scanners e no Optimizer.",en:"Maximum price age used by scanners and Optimizer."},
  "Modo de venda por defeito": {pt:"Modo de venda padrão",en:"Default sale mode"},
  "Produção": {pt:"Produção",en:"Production"},
  "Defaults partilhados por Crafting, Refining e Optimizer.": {pt:"Padrões compartilhados por Crafting, Refining e Optimizer.",en:"Defaults shared by Crafting, Refining, and Optimizer."},
  "Silver por 100 de nutrição.": {pt:"Silver por 100 de nutrição.",en:"Silver per 100 nutrition."},
  "Cidade de Crafting": {pt:"Cidade de Crafting",en:"Crafting city"},
  "Destino de venda — Crafting": {pt:"Destino de venda — Crafting",en:"Selling destination — Crafting"},
  "Cidade de Refining": {pt:"Cidade de Refining",en:"Refining city"},
  "Destino de venda — Refining": {pt:"Destino de venda — Refining",en:"Selling destination — Refining"},
  "Interface": {pt:"Interface",en:"Interface"},
  "Preferências gerais do SOL HUB.": {pt:"Preferências gerais do SOL HUB.",en:"General SOL HUB preferences."},
  "Idioma": {pt:"Idioma",en:"Language"},
  "Ao guardar, esta opção sincroniza com o seletor de idioma no cabeçalho.": {pt:"Ao salvar, esta opção sincroniza com o seletor de idioma no cabeçalho.",en:"When saved, this option syncs with the language selector in the header."},
  "✅ Preferências guardadas. As ferramentas vão usar estes valores como defaults.": {pt:"✅ Preferências salvas. As ferramentas usarão estes valores como padrão.",en:"✅ Preferences saved. Tools will use these values as defaults."},
  "Repor defaults": {pt:"Restaurar padrões",en:"Reset defaults"},
  "Guardar definições": {pt:"Salvar configurações",en:"Save settings"},

  "Especializações Sol": {pt:"Especializações Sol",en:"SOL Specializations"},
  "Perfil ativo": {pt:"Perfil ativo",en:"Active profile"},
  "Procurar item, ex. Bag T6.1…": {pt:"Procurar item, ex. Bag T6.1…",en:"Search item, e.g. Bag T6.1…"},
  "⚔ Armas": {pt:"⚔ Armas",en:"⚔ Weapons"},
  "🛡 Armaduras": {pt:"🛡 Armaduras",en:"🛡 Armor"},
  "⛏ Gear Coleta": {pt:"⛏ Equipamento de Coleta",en:"⛏ Gathering Gear"},
  "🎒 Bags": {pt:"🎒 Bags",en:"🎒 Bags"},
  "🦸 Capes": {pt:"🦸 Capes",en:"🦸 Capes"},
  "GENERAL SPEC": {pt:"SPEC GERAL",en:"GENERAL SPEC"},
  "GENERAL": {pt:"GERAL",en:"GENERAL"},
  "Eficiência de Focus / nível": {pt:"Eficiência de Focus / nível",en:"Focus Efficiency / level"},
  "Quality Points / nível": {pt:"Quality Points / nível",en:"Quality Points / level"},
  "Eficiência de Focus própria": {pt:"Eficiência de Focus própria",en:"own Focus Efficiency"},
  "cadeia de refino": {pt:"cadeia de refino",en:"refining chain"},
  "árvore": {pt:"árvore",en:"tree"},
  "Qualidade:": {pt:"Qualidade:",en:"Quality:"},
  "próprio": {pt:"próprio",en:"own"},
  "árvore / nível": {pt:"árvore / nível",en:"tree / level"},
  "Spec individual": {pt:"Spec individual",en:"Individual Spec"},
  "General Tree": {pt:"General Tree",en:"General Tree"},
  "O Consultor calcula os": {pt:"O Consultor calcula os",en:"SOL HUB calculates the"},
  "Bow Crafter, Dagger Crafter, Chef, Alchemist, Torch/Tome/Shield, gathering gear, bags, capes e cadeias de refino T4–T8. Cada árvore usa os coeficientes próprios do Destiny Board.": {pt:"Bow Crafter, Dagger Crafter, Chef, Alchemist, Torch/Tome/Shield, gathering gear, bags, capes e cadeias de refino T4–T8. Cada árvore usa os coeficientes próprios do Destiny Board.",en:"Bow Crafter, Dagger Crafter, Chef, Alchemist, Torch/Tome/Shield, gathering gear, bags, capes, and T4–T8 refining chains. Each tree uses its own Destiny Board coefficients."},
  "Cada arma, peça de armadura, off-hand, peça de gear de coleta, bag, comida ou poção tem a sua Spec. No refino, cada material tem Specs separadas de T4 a T8; cada nível dá +250 de Eficiência de Focus ao próprio Tier e +30 aos restantes Tiers da mesma cadeia. Cape usa o seu nó próprio de Cape Crafting. Em Chef e Alchemist, cada Spec individual também dá bónus mútuo aos restantes produtos. Em Alchemist, as poções base dão +22,5 de Eficiência de Focus/nível à árvore e as poções especializadas/artefacto dão +11,25.": {pt:"Cada arma, peça de armadura, off-hand, peça de equipamento de coleta, bag, comida ou poção tem sua Spec. No refino, cada material tem Specs separadas de T4 a T8; cada nível dá +250 de Eficiência de Focus ao próprio Tier e +30 aos demais Tiers da mesma cadeia. Cape usa seu próprio nó de Cape Crafting. Em Chef e Alchemist, cada Spec individual também dá bônus mútuo aos demais produtos. Em Alchemist, as poções base dão +22,5 de Eficiência de Focus/nível à árvore e as poções especializadas/artefato dão +11,25.",en:"Each weapon, armor piece, off-hand, gathering gear piece, bag, food, or potion has its own Spec. In refining, each material has separate T4–T8 Specs; each level gives +250 Focus Efficiency to its own Tier and +30 to the other Tiers in the same chain. Cape uses its own Cape Crafting node. In Chef and Alchemist, each individual Spec also gives a mutual bonus to the other products. In Alchemist, base potions give +22.5 Focus Efficiency/level to the tree, while specialized/artifact potions give +11.25."},
  "Nas armas, armaduras, off-hands, gathering gear, bags e capes, Mastery e Specs também aumentam os Quality Points, que melhoram as probabilidades de obter Good, Outstanding, Excellent e Masterpiece.": {pt:"Nas armas, armaduras, off-hands, gathering gear, bags e capes, Mastery e Specs também aumentam os Quality Points, que melhoram as probabilidades de obter Good, Outstanding, Excellent e Masterpiece.",en:"For weapons, armor, off-hands, gathering gear, bags, and capes, Mastery and Specs also increase Quality Points, improving the chances of Good, Outstanding, Excellent, and Masterpiece quality."},
  "O Consultor calcula os Quality Points resultantes das tuas Specs para armas, armaduras, off-hands, gathering gear, bags e capes. Ainda não convertemos estes pontos numa percentagem exata de cada qualidade nem os usamos no lucro esperado, para não inventar probabilidades.": {pt:"O Consultor calcula os Quality Points resultantes das suas Specs para armas, armaduras, off-hands, gathering gear, bags e capes. Ainda não convertemos estes pontos em uma porcentagem exata de cada qualidade nem os usamos no lucro esperado, para não inventar probabilidades.",en:"SOL HUB calculates the Quality Points produced by your Specs for weapons, armor, off-hands, gathering gear, bags, and capes. We do not yet convert these points into an exact probability for each quality or use them in expected profit, so we do not invent probabilities."},
  "Perfil importado.": {pt:"Perfil importado.",en:"Profile imported."},
  "Perfil incompatível.": {pt:"Perfil incompatível.",en:"Incompatible profile."},
  "Sem dados": {pt:"Sem dados",en:"No data"},
  "Falha ao procurar oportunidade.": {pt:"Falha ao procurar oportunidade.",en:"Failed to find an opportunity."},
  "Falha ao procurar oportunidades.": {pt:"Falha ao procurar oportunidades.",en:"Failed to find opportunities."},
  "Falha no scanner de refino.": {pt:"Falha no scanner de refino.",en:"Refine Scanner failed."},
  "A analisar o mercado…": {pt:"Analisando o mercado…",en:"Analyzing the market…"},
  "Lucro": {pt:"Lucro",en:"Profit"},
  "Rentabilidade": {pt:"Rentabilidade",en:"Return"},
  "Preço atual": {pt:"Preço atual",en:"Current price"},
  "Ver oportunidade": {pt:"Ver oportunidade",en:"View opportunity"},
  "Todas as origens": {pt:"Todas as origens",en:"All sources"},
  "Maior rentabilidade": {pt:"Maior rentabilidade",en:"Highest return"},
  "Maior lucro": {pt:"Maior lucro",en:"Highest profit"},
  "Nome A–Z": {pt:"Nome A–Z",en:"Name A–Z"},
  "Mercado": {pt:"Mercado",en:"Market"},
  "Refino": {pt:"Refino",en:"Refining"},
  "Por que o SOL gosta desta oportunidade?": {pt:"Por que o SOL gosta desta oportunidade?",en:"Why does SOL like this opportunity?"},
  "Dados de compra": {pt:"Dados de compra",en:"Buy data"},
  "Dados de venda": {pt:"Dados de venda",en:"Sell data"},
  "Preço vs. média 7d": {pt:"Preço vs. média de 7d",en:"Price vs. 7d average"},
  "INTELIGÊNCIA DE MERCADO": {pt:"INTELIGÊNCIA DE MERCADO",en:"MARKET INTELLIGENCE"},
  "Pulso do Mercado": {pt:"Pulso do Mercado",en:"Market Pulse"},
  "DETALHES DA OPORTUNIDADE": {pt:"DETALHES DA OPORTUNIDADE",en:"OPPORTUNITY DETAILS"},
  "Lucro esperado": {pt:"Lucro esperado",en:"Expected profit"},
  "Economia por unidade": {pt:"Economia por unidade",en:"Unit economics"},
  "Recomendação do SOL": {pt:"Recomendação do SOL",en:"SOL recommendation"},
  "Score de decisão": {pt:"Score de decisão",en:"Decision Score"},
  "Investimento no plano": {pt:"Investimento no plano",en:"Plan investment"},
  "Não selecionada": {pt:"Não selecionada",en:"Not selected"},
  "A procurar crafts…": {pt:"Procurando crafts…",en:"Finding crafts…"},
  "Vender": {pt:"Vender",en:"Sell"},
  "Lucro/un.": {pt:"Lucro/un.",en:"Profit/unit"},
  "Focus/craft": {pt:"Focus/craft",en:"Focus/craft"},
  "Erro de refino.": {pt:"Erro de refino.",en:"Refining error."},
  "Seleciona primeiro um item da lista.": {pt:"Selecione primeiro um item da lista.",en:"Select an item from the list first."},
  "Resultados da pesquisa de items": {pt:"Resultados da pesquisa de itens",en:"Item search results"},
  "Calcular crafting": {pt:"Calcular crafting",en:"Calculate crafting"},
  "não identificada": {pt:"não identificada",en:"not identified"},
  "Não retornável": {pt:"Não retornável",en:"Non-returnable"},
  "SOL HUB • by Fate and Ryukk • NoTag Exclusive • 2026 • Não afiliado à Sandbox Interactive.": {pt:"SOL HUB • by Fate and Ryukk • NoTag Exclusive • 2026 • Não afiliado à Sandbox Interactive.",en:"SOL HUB • by Fate and Ryukk • NoTag Exclusive • 2026 • Not affiliated with Sandbox Interactive."},
  "Ainda sem dados de hoje — cálculos usam 0% de Daily Bonus.": {pt:"Ainda sem dados de hoje — cálculos usam 0% de Daily Bonus.",en:"No data for today yet — calculations use 0% Daily Bonus."},
  "Os preços vêm do AODP e podem estar desatualizados. Confirme preços, stock e taxas no jogo antes de refinar.": {pt:"Os preços vêm do AODP e podem estar desatualizados. Confirme preços, stock e taxas no jogo antes de refinar.",en:"Prices come from AODP and may be outdated. Confirm prices, stock and fees in-game before refining."},
  "• Dados de venda:": {pt:"• Dados de venda:",en:"• Sell data:"},

};

const reversePt=new Map<string,string>();
const reverseEn=new Map<string,string>();
for(const [source,v] of Object.entries(entries)){
  reversePt.set(v.pt,source);
  reverseEn.set(v.en,source);
}

function translateValue(value:string,lang:Lang){
  const lead=value.match(/^\s*/)?.[0]??"";
  const trail=value.match(/\s*$/)?.[0]??"";
  const core=value.trim();
  if(!core)return value;

  let source=core;
  if(entries[core]) source=core;
  else if(reversePt.has(core)) source=reversePt.get(core)!;
  else if(reverseEn.has(core)) source=reverseEn.get(core)!;

  const hit=entries[source];
  if(!hit)return value;
  return lead+(lang==="en"?hit.en:hit.pt)+trail;
}

function translateElement(root:ParentNode,lang:Lang){
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
  const texts:Text[]=[];
  while(walker.nextNode())texts.push(walker.currentNode as Text);
  for(const node of texts){
    const parent=node.parentElement;
    if(!parent||parent.closest("script,style,code,pre"))continue;
    const next=translateValue(node.nodeValue??"",lang);
    if(next!==node.nodeValue)node.nodeValue=next;
  }

  const els=(root instanceof Element?[root,...Array.from(root.querySelectorAll("*"))]:Array.from(root.querySelectorAll("*"))) as Element[];
  for(const el of els){
    for(const attr of ["placeholder","title","aria-label"]){
      const cur=el.getAttribute(attr);
      if(!cur)continue;
      const next=translateValue(cur,lang);
      if(next!==cur)el.setAttribute(attr,next);
    }
  }
}

export default function LanguageSelector(){
  const [lang,setLang]=useState<Lang>("en");
  const [ready,setReady]=useState(false);

  useEffect(()=>{
    const saved=localStorage.getItem(STORAGE_KEY);
    const initial:Lang=saved==="pt-BR"?"pt-BR":"en";
    setLang(initial);
    setReady(true);
  },[]);

  useEffect(()=>{
    if(!ready)return;

    localStorage.setItem(STORAGE_KEY,lang);
    document.documentElement.lang=lang;
    translateElement(document.body,lang);

    const observer=new MutationObserver(mutations=>{
      for(const m of mutations){
        if(m.type==="characterData"&&m.target.parentNode){
          translateElement(m.target.parentNode as ParentNode,lang);
        }
        for(const node of Array.from(m.addedNodes)){
          if(node.nodeType===Node.TEXT_NODE&&node.parentNode)translateElement(node.parentNode as ParentNode,lang);
          else if(node.nodeType===Node.ELEMENT_NODE)translateElement(node as Element,lang);
        }
      }
    });
    observer.observe(document.body,{childList:true,subtree:true,characterData:true});
    return()=>observer.disconnect();
  },[lang,ready]);

  return <label className="languagePicker" title={lang==="en"?"Language":"Idioma"}>
    <span className="languageFlag" aria-hidden="true">{lang==="en"?"🇬🇧":"🇧🇷"}</span>
    <select aria-label={lang==="en"?"Language":"Idioma"} value={lang} onChange={e=>{
      const next=e.target.value as Lang;
      localStorage.setItem(STORAGE_KEY,next);
      document.documentElement.lang=next;
      setLang(next);
      window.location.reload();
    }}>
      <option value="pt-BR">🇧🇷 PT-BR</option>
      <option value="en">🇬🇧 EN</option>
    </select>
  </label>;
}