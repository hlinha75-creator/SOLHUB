"use client";
import {useEffect,useState} from "react";
import {WATCHLIST_EVENT,isWatchlisted,toggleWatchlist,type WatchlistEntry} from "../../lib/watchlistClient";
import {currentSiteLanguage} from "../../lib/languageClient";

type Props=Omit<WatchlistEntry,"id"|"createdAt"> & {compact?:boolean};

export default function WatchlistButton(props:Props){
 const {compact,...entry}=props;
 const [active,setActive]=useState(false);
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 useEffect(()=>{
  setLang(currentSiteLanguage());
  const sync=()=>setActive(isWatchlisted(entry));
  sync();window.addEventListener(WATCHLIST_EVENT,sync);window.addEventListener("storage",sync);
  return()=>{window.removeEventListener(WATCHLIST_EVENT,sync);window.removeEventListener("storage",sync)};
 },[entry.type,entry.itemId,entry.route,entry.source]);

 return <button
  type="button"
  className={`watchlistButton ${active?"active":""} ${compact?"compact":""}`}
  aria-pressed={active}
  aria-label={active?(lang==="en"?"Remove from Watchlist":"Remover da Watchlist"):(lang==="en"?"Add to Watchlist":"Adicionar à Watchlist")}
  title={active?(lang==="en"?"Remove from Watchlist":"Remover da Watchlist"):(lang==="en"?"Add to Watchlist":"Adicionar à Watchlist")}
  onClick={e=>{e.stopPropagation();toggleWatchlist(entry);setActive(!active)}}
 >★{!compact&&<span>{active?(lang==="en"?"Saved":"Guardado"):"Watchlist"}</span>}</button>;
}
