"use client";

import Link from "next/link";
import {useEffect,useState} from "react";
import {loadCraftingProfile} from "../../lib/focusClient";
import {currentSiteLanguage} from "../../lib/languageClient";

function hasConfiguredSpecs(){
  const p=loadCraftingProfile();
  const levels=[...Object.values(p.masteries??{}),...Object.values(p.specs??{})];
  const legacy=Object.values(p.legacyFceOverrides??{});
  return [...levels,...legacy].some(v=>Number(v)>0);
}

export default function SpecsAwareness(){
  const [ready,setReady]=useState(false);
  const [configured,setConfigured]=useState(false);
  const [lang,setLang]=useState<"pt-BR"|"en">("en");

  useEffect(()=>{
    setConfigured(hasConfiguredSpecs());
    setLang(currentSiteLanguage());
    setReady(true);
  },[]);

  if(!ready)return null;

  if(configured){
    return <div className="specsStatus specsStatusOk">
      <span className="specsStatusIcon">⚙️</span>
      <div><strong>{lang==="en"?"Specs configured":"Specs configuradas"}</strong><span>{lang==="en"?"Focus calculations use your saved profile.":"Os cálculos de Focus usam o teu perfil guardado."}</span></div>
      <Link href="/specializations">{lang==="en"?"View Specs":"Ver Specs"}</Link>
    </div>;
  }

  return <div className="specsStatus specsStatusWarn">
    <span className="specsStatusIcon">⚠️</span>
    <div><strong>{lang==="en"?"Specializations profile not configured":"Perfil de Especializações não configurado"}</strong><span>{lang==="en"?"For more accurate Focus results, fill in your Destiny Board Specs.":"Para resultados de Focus mais precisos, preenche as tuas Specs do Destiny Board."}</span></div>
    <Link href="/specializations">{lang==="en"?"Configure Specs":"Configurar Specs"}</Link>
  </div>;
}
