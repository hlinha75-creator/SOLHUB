"use client";
import {useEffect,useState} from "react";

function utcTime(d:Date){
 return d.toLocaleTimeString("pt-PT",{
  timeZone:"UTC",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false
 });
}

export default function UtcClock(){
 const [now,setNow]=useState<Date|null>(null);
 useEffect(()=>{
  setNow(new Date());
  const timer=setInterval(()=>setNow(new Date()),1000);
  return()=>clearInterval(timer);
 },[]);
 return <div className="utcClock" aria-label="Hora UTC atual">
  <span className="utcClockDot"/>
  <div><small>UTC</small><strong>{now?utcTime(now):"--:--:--"}</strong></div>
 </div>;
}
