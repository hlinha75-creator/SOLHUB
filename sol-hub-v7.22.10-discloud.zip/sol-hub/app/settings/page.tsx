"use client";

import {FormEvent,useEffect,useState} from "react";
import AppSidebar from "../components/AppSidebar";
import LanguageSelector from "../components/LanguageSelector";
import {
  DEFAULT_SETTINGS,
  loadSolHubSettings,
  resetSolHubSettings,
  saveSolHubSettings,
  type SolHubSettings
} from "../../lib/settingsClient";
import {currentSiteLanguage} from "../../lib/languageClient";

const royalCities=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const sellCities=[...royalCities,"Black Market"];

export default function SettingsPage(){
  const [settings,setSettings]=useState<SolHubSettings>(DEFAULT_SETTINGS);
  const [ready,setReady]=useState(false);
  const [saved,setSaved]=useState(false);
  const [lang,setLang]=useState<"pt-BR"|"en">("en");

  useEffect(()=>{
    setSettings(loadSolHubSettings());
    setLang(currentSiteLanguage());
    setReady(true);
  },[]);

  function set<K extends keyof SolHubSettings>(key:K,value:SolHubSettings[K]){
    setSaved(false);
    setSettings(prev=>({...prev,[key]:value}));
  }

  function submit(e:FormEvent){
    e.preventDefault();
    saveSolHubSettings(settings);
    setSaved(true);
  }

  function reset(){
    resetSolHubSettings();
    setSettings(DEFAULT_SETTINGS);
    setSaved(true);
  }

  const ui=lang==="en"?{hero:"Set your preferences once and SOL HUB applies them automatically across economic tools.",global:"Global preferences",globalDesc:"These settings are saved in this browser. You can still change any field directly in a calculator without changing the global value.",loading:"Loading…",account:"Account & Market",accountDesc:"Fees and preferences used in market analysis.",premium:"Premium active",premiumDesc:"Uses the corresponding Premium market fees.",marketCity:"Preferred market city",allCities:"All cities",marketHint:"Used as the starting point in Market Scanner.",maxData:"Maximum data age (hours)",maxDataHint:"Maximum price age in scanners and Optimizer.",saleMode:"Default sale mode",production:"Production",productionDesc:"Shared defaults for Crafting, Refining and Optimizer.",focus:"Available Focus",station:"Station fee",stationHint:"Silver per 100 nutrition.",craftCity:"Crafting city",craftSell:"Crafting sell destination",refineCity:"Refining city",refineSell:"Refining sell destination",interface:"Interface",interfaceDesc:"General SOL HUB preferences.",language:"Language",languageHint:"When saved, this option syncs with the language selector in the header.",saved:"✅ Preferences saved. Tools will use these values as defaults.",reset:"Reset defaults",save:"Save settings"}:{hero:"Define uma vez as tuas preferências e o SOL HUB aplica-as automaticamente nas ferramentas económicas.",global:"Preferências globais",globalDesc:"Estas definições ficam guardadas neste browser. Podes continuar a alterar qualquer campo diretamente numa calculadora sem mudar o valor global.",loading:"A carregar…",account:"Conta & Mercado",accountDesc:"Taxas e preferências usadas nas análises de mercado.",premium:"Premium ativo",premiumDesc:"Usa as taxas de mercado correspondentes a Premium.",marketCity:"Cidade de mercado preferida",allCities:"Todas as cidades",marketHint:"Usada como ponto de partida no Market Scanner.",maxData:"Dados máximos (horas)",maxDataHint:"Idade máxima dos preços em scanners e Optimizer.",saleMode:"Modo de venda por defeito",production:"Produção",productionDesc:"Defaults partilhados por Crafting, Refining e Optimizer.",focus:"Focus disponível",station:"Taxa da estação",stationHint:"Silver por 100 de nutrição.",craftCity:"Cidade de Crafting",craftSell:"Destino de venda — Crafting",refineCity:"Cidade de Refining",refineSell:"Destino de venda — Refining",interface:"Interface",interfaceDesc:"Preferências gerais do SOL HUB.",language:"Idioma",languageHint:"Ao guardar, esta opção sincroniza com o seletor de idioma no cabeçalho.",saved:"✅ Preferências guardadas. As ferramentas vão usar estes valores como defaults.",reset:"Repor defaults",save:"Guardar definições"};

  return <main className="shell settingsShell">
    <AppSidebar/>
    <header className="hero">
      <div>
        <div className="eyebrow">SOL HUB • GLOBAL CONFIGURATION</div>
        <h1>Global <span>Settings</span></h1>
        <p>{ui.hero}</p>
      </div>
      <div className="headerTools"><LanguageSelector/></div>
    </header>

    <section className="settingsInfo">
      <div className="settingsInfoIcon">⚙️</div>
      <div>
        <strong>{ui.global}</strong>
        <span>{ui.globalDesc}</span>
      </div>
      <span className={ready?"settingsStored":"settingsStored loading"}>{ready?"LOCAL":ui.loading}</span>
    </section>

    <form className="settingsForm" onSubmit={submit}>
      <section className="settingsCard">
        <div className="settingsCardHead">
          <span>💰</span><div><strong>{ui.account}</strong><small>{ui.accountDesc}</small></div>
        </div>
        <div className="settingsGrid">
          <label className="settingsToggle">
            <input type="checkbox" checked={settings.premium} onChange={e=>set("premium",e.target.checked)}/>
            <span><strong>{ui.premium}</strong><small>{ui.premiumDesc}</small></span>
          </label>
          <label>{ui.marketCity}
            <select value={settings.marketCity} onChange={e=>set("marketCity",e.target.value)}>
              <option value="all">{ui.allCities}</option>
              {royalCities.map(city=><option key={city}>{city}</option>)}
            </select>
            <small>{ui.marketHint}</small>
          </label>
          <label>{ui.maxData}
            <input type="number" min="1" max="48" value={settings.maxAgeHours} onChange={e=>set("maxAgeHours",Number(e.target.value))}/>
            <small>{ui.maxDataHint}</small>
          </label>
          <label>{ui.saleMode}
            <select value={settings.saleMode} onChange={e=>set("saleMode",e.target.value as SolHubSettings["saleMode"])}>
              <option value="sell_order">Sell Order</option>
              <option value="instant_sell">Instant Sell</option>
            </select>
          </label>
        </div>
      </section>

      <section className="settingsCard">
        <div className="settingsCardHead">
          <span>⚒️</span><div><strong>{ui.production}</strong><small>{ui.productionDesc}</small></div>
        </div>
        <div className="settingsGrid">
          <label>{ui.focus}
            <input type="number" min="0" max="30000" step="1" value={settings.focus} onChange={e=>set("focus",Number(e.target.value))}/>
            <small>0–30.000 Focus.</small>
          </label>
          <label>{ui.station}
            <input type="number" min="0" step="1" value={settings.stationFee} onChange={e=>set("stationFee",Number(e.target.value))}/>
            <small>{ui.stationHint}</small>
          </label>
          <label>{ui.craftCity}
            <select value={settings.craftCity} onChange={e=>set("craftCity",e.target.value)}>
              {royalCities.map(city=><option key={city}>{city}</option>)}
            </select>
          </label>
          <label>{ui.craftSell}
            <select value={settings.craftSellCity} onChange={e=>set("craftSellCity",e.target.value)}>
              {sellCities.map(city=><option key={city}>{city}</option>)}
            </select>
          </label>
          <label>{ui.refineCity}
            <select value={settings.refineCity} onChange={e=>set("refineCity",e.target.value)}>
              {royalCities.filter(c=>c!=="Brecilien").map(city=><option key={city}>{city}</option>)}
            </select>
          </label>
          <label>{ui.refineSell}
            <select value={settings.refineSellCity} onChange={e=>set("refineSellCity",e.target.value)}>
              {sellCities.map(city=><option key={city}>{city}</option>)}
            </select>
          </label>
        </div>
      </section>

      <section className="settingsCard">
        <div className="settingsCardHead">
          <span>🌐</span><div><strong>{ui.interface}</strong><small>{ui.interfaceDesc}</small></div>
        </div>
        <div className="settingsGrid">
          <label>{ui.language}
            <select value={settings.language} onChange={e=>set("language",e.target.value as SolHubSettings["language"])}>
              <option value="pt-BR">🇧🇷 Português</option>
              <option value="en">🇬🇧 English</option>
            </select>
            <small>{ui.languageHint}</small>
          </label>
        </div>
      </section>

      {saved&&<div className="settingsSaved">{ui.saved}</div>}

      <div className="settingsActions">
        <button type="button" className="settingsReset" onClick={reset}>{ui.reset}</button>
        <button type="submit" className="settingsReset settingsSave">{ui.save}</button>
      </div>
    </form>
  </main>;
}
