import {NextRequest,NextResponse} from "next/server";
import {ageMinutes,loadMarketPrices} from "../../../../lib/albion";
import {marketIntelligence} from "../../../../lib/solIntelligence";

export const runtime="nodejs";
type Entry={id:string;type:"FLIP"|"CRAFT"|"REFINE";itemId:string;buyCity?:string;sellCity?:string;quality?:number;
 intelligenceScore?:number;avgDailyVolume?:number;volatilityPct?:number;buyHistoryAvgPrice?:number;investment?:number;profit?:number};

export async function POST(req:NextRequest){
 try{
  const body=await req.json();
  const entries:(Entry[])=(Array.isArray(body?.entries)?body.entries:[]).slice(0,100);
  const premium=body?.premium!==false;
  const saleMode=body?.saleMode==="instant_sell"?"instant_sell":"sell_order";
  const locations=[...new Set(entries.flatMap(x=>[x.buyCity,x.sellCity].filter(Boolean) as string[]))];
  const ids=[...new Set(entries.map(x=>x.itemId))];
  if(!entries.length)return NextResponse.json({quotes:{}});
  const rows=locations.length?await loadMarketPrices(ids,locations):[];
  const quotes:Record<string,any>={};

  for(const e of entries){
   const q=Number(e.quality??1);
   const pick=(city?:string)=>rows.filter((x:any)=>x.item_id===e.itemId&&x.city===city&&(Number(x.quality??1)===q||e.type!=="FLIP"));
   if(e.type==="FLIP"){
    const buy=pick(e.buyCity).filter((x:any)=>x.sell_price_min>0).sort((a:any,b:any)=>a.sell_price_min-b.sell_price_min)[0];
    const sellRows=pick(e.sellCity);
    const black=e.sellCity==="Black Market";
    const sell=sellRows.filter((x:any)=>(black?x.buy_price_max:x.sell_price_min)>0)
      .sort((a:any,b:any)=>(black?b.buy_price_max-a.buy_price_max:a.sell_price_min-b.sell_price_min))[0];
    const buyPrice=buy?.sell_price_min??null;
    const sellPrice=sell?(black?sell.buy_price_max:sell.sell_price_min):null;
    const buyAgeMin=buy?Math.round(ageMinutes(buy.sell_price_min_date)):null;
    const sellAgeMin=sell?Math.round(ageMinutes(black?sell.buy_price_max_date:sell.sell_price_min_date)):null;
    let currentProfit:null|number=null,currentRoi:null|number=null,currentIntelligenceScore:null|number=null;
    if(buyPrice&&sellPrice){
      const taxRate=premium?0.04:0.08;
      const setupRate=black||saleMode==="instant_sell"?0:0.025;
      const fees=Math.ceil(sellPrice*taxRate)+Math.ceil(sellPrice*setupRate);
      currentProfit=sellPrice-buyPrice-fees;
      currentRoi=buyPrice>0?currentProfit/buyPrice*100:0;
      if(e.intelligenceScore!=null){
        currentIntelligenceScore=marketIntelligence({
          roi:currentRoi,profit:currentProfit,avgDailyVolume:e.avgDailyVolume??0,volatilityPct:e.volatilityPct??0,
          dataAgeMin:Math.max(buyAgeMin??999,sellAgeMin??999),buyPrice,buyHistoryAvgPrice:e.buyHistoryAvgPrice??0,
          recommendedInvestment:buyPrice,recommendedProfit:currentProfit
        }).score;
      }
    }
    quotes[e.id]={buyPrice,sellPrice,buyAgeMin,sellAgeMin,currentProfit,currentRoi,currentIntelligenceScore};
   }else{
    const out=pick(e.sellCity);
    const black=e.sellCity==="Black Market";
    const best=out.filter((x:any)=>(black?x.buy_price_max:x.sell_price_min)>0)
      .sort((a:any,b:any)=>(black?b.buy_price_max-a.buy_price_max:a.sell_price_min-b.sell_price_min))[0];
    quotes[e.id]={
     sellPrice:best?(black?best.buy_price_max:best.sell_price_min):null,
     sellAgeMin:best?Math.round(ageMinutes(black?best.buy_price_max_date:best.sell_price_min_date)):null
    };
   }
  }
  return NextResponse.json({quotes});
 }catch(e){
  return NextResponse.json({error:e instanceof Error?e.message:"Falha ao atualizar Watchlist."},{status:400});
 }
}
