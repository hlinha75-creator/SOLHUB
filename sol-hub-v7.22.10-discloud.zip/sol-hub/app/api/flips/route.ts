import { NextRequest, NextResponse } from "next/server";
import {
  CITIES,
  ageMinutes,
  loadItems,
  loadMarketHistory,
  loadMarketPrices,
  qualityName,
  canSellOnBlackMarket,
  type MarketHistoryPoint,
  type SaleMode
} from "../../../lib/albion";
import {itemLanguage} from "../../../lib/localizedNames";
import {historyTrendPct,marketIntelligence,type IntelligenceComponents,type IntelligenceCondition} from "../../../lib/solIntelligence";

export const runtime = "nodejs";

type Liquidity = "Alta" | "Média" | "Baixa" | "Sem dados";
type Risk = "Baixo" | "Médio" | "Alto";

type Flip = {
  itemId: string; itemName: string; quality: number; qualityName: string;
  buyCity: string; sellCity: string; buyPrice: number; sellPrice: number; fees: number;
  profit: number; roi: number; buyAgeMin: number; sellAgeMin: number; affordableQty: number;
  potentialProfit: number; score: number; recommendedQty: number; recommendedInvestment: number;
  recommendedProfit: number; allocationPct: number; avgDailyVolume: number; volume7d: number;
  historyAvgPrice: number; priceDeviationPct: number; volatilityPct: number; liquidity: Liquidity;
  buyHistoryAvgPrice:number; entryAdvantagePct:number; trendPct:number; intelligenceScore:number;
  intelligenceComponents:IntelligenceComponents; marketCondition:IntelligenceCondition;
  risk: Risk; history: MarketHistoryPoint[]; planQty?: number; planInvestment?: number; planProfit?: number;
};

function nums(value: string | null, fallback: number[]) {
  if (!value) return fallback;
  return value.split(",").map(Number).filter(Number.isFinite);
}

function historyStats(points: MarketHistoryPoint[], currentSellPrice: number) {
  const valid = points.filter(p => p.avg_price > 0 && p.item_count >= 0).slice(-7);
  const volume7d = valid.reduce((s, p) => s + p.item_count, 0);
  const avgDailyVolume = valid.length ? volume7d / valid.length : 0;
  const totalWeight = valid.reduce((s, p) => s + Math.max(1, p.item_count), 0);
  const historyAvgPrice = totalWeight
    ? valid.reduce((s, p) => s + p.avg_price * Math.max(1, p.item_count), 0) / totalWeight
    : 0;
  const prices = valid.map(p => p.avg_price);
  const mean = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
  const variance = prices.length ? prices.reduce((s, p) => s + Math.pow(p - mean, 2), 0) / prices.length : 0;
  const volatilityPct = mean > 0 ? Math.sqrt(variance) / mean * 100 : 0;
  const priceDeviationPct = historyAvgPrice > 0 ? (currentSellPrice - historyAvgPrice) / historyAvgPrice * 100 : 0;
  return { avgDailyVolume, volume7d, historyAvgPrice, volatilityPct, priceDeviationPct, history: valid };
}

function liquidityFor(avgDailyVolume: number): Liquidity {
  if (avgDailyVolume >= 20) return "Alta";
  if (avgDailyVolume >= 5) return "Média";
  if (avgDailyVolume > 0) return "Baixa";
  return "Sem dados";
}

function riskFor(avgDailyVolume: number, volatilityPct: number, deviationPct: number, age: number): Risk {
  let points = 0;
  if (avgDailyVolume < 5) points += 2; else if (avgDailyVolume < 15) points += 1;
  if (volatilityPct > 25) points += 2; else if (volatilityPct > 12) points += 1;
  if (Math.abs(deviationPct) > 30) points += 2; else if (Math.abs(deviationPct) > 15) points += 1;
  if (age > 180) points += 2; else if (age > 60) points += 1;
  return points >= 5 ? "Alto" : points >= 2 ? "Médio" : "Baixo";
}

export async function GET(req: NextRequest) {
  try {
    const s = req.nextUrl.searchParams;
    const buyCityParam = s.get("buyCity") ?? "Martlock";
    const buyCities = buyCityParam === "all" ? CITIES.filter(c => c !== "Black Market") : [buyCityParam];
    const sellCityParam = s.get("sellCity") ?? "all";
    const sellCities = sellCityParam === "all" ? [...CITIES] : [sellCityParam];
    const category = s.get("category") ?? "all";
    const tiers = nums(s.get("tiers"), [4, 5, 6, 7, 8]);
    const enchants = nums(s.get("enchants"), [0, 1, 2, 3]);
    const maxAgeHours = Number(s.get("maxAgeHours") ?? 4);
    const minRoi = Number(s.get("minRoi") ?? 10);
    const minProfit = Number(s.get("minProfit") ?? 10000);
    const capital = Number(s.get("capital") ?? 10000000);
    const premium = s.get("premium") !== "false";
    const maxAllocationPct = Math.min(100, Math.max(1, Number(s.get("maxAllocationPct") ?? 20)));
    const maxDailyVolumePct = Math.min(100, Math.max(1, Number(s.get("maxDailyVolumePct") ?? 25)));
    const saleMode = (s.get("saleMode") ?? "sell_order") as SaleMode;
    const lang=itemLanguage(s.get("lang"));

    const requestedItemId=s.get("itemId");
    const loadedItems = await loadItems(category, tiers, enchants, lang);
    const items=requestedItemId?loadedItems.filter(i=>i.id===requestedItemId):loadedItems;
    if(requestedItemId&&!items.length)return NextResponse.json({error:"O item selecionado já não pertence aos filtros desta oportunidade."},{status:404});
    const names = new Map(items.map(i => [i.id, i.name]));
    const locations = [...new Set([...buyCities, ...sellCities])];
    const prices = await loadMarketPrices(items.map(i => i.id), locations);
    const byKey = new Map<string, (typeof prices)[number]>();
    for (const p of prices) byKey.set(`${p.item_id}|${p.city}|${p.quality}`, p);

    const taxRate = premium ? 0.04 : 0.08;
    const setupRate = 0.025;
    const maxAgeMin = maxAgeHours * 60;
    const base: Flip[] = [];

    for (const item of items) for (let q = 1; q <= 5; q++) {
      for (const buyCity of buyCities) {
        const buy = byKey.get(`${item.id}|${buyCity}|${q}`);
        if (!buy || !buy.sell_price_min || ageMinutes(buy.sell_price_min_date) > maxAgeMin) continue;
        for (const sellCity of sellCities) {
          // A compra e a venda na mesma cidade não constituem um flip.
          if (sellCity === buyCity) continue;
          // O Black Market não compra montarias nem poções.
          if (sellCity === "Black Market" && !canSellOnBlackMarket(item.id)) continue;
          const sell = byKey.get(`${item.id}|${sellCity}|${q}`);
          if (!sell) continue;
          const effectiveSaleMode:SaleMode=sellCity==="Black Market"?"instant_sell":saleMode;
          const sellPrice = effectiveSaleMode === "instant_sell" ? sell.buy_price_max : sell.sell_price_min;
          const sellDate = effectiveSaleMode === "instant_sell" ? sell.buy_price_max_date : sell.sell_price_min_date;
          if (!sellPrice || ageMinutes(sellDate) > maxAgeMin) continue;
          const setupFee = effectiveSaleMode === "sell_order" ? Math.ceil(sellPrice * setupRate) : 0;
          const salesTax = Math.ceil(sellPrice * taxRate);
          const fees = setupFee + salesTax;
          const profit = sellPrice - buy.sell_price_min - fees;
          const roi = profit / buy.sell_price_min * 100;
          if (profit < minProfit || roi < minRoi) continue;
          const affordableQty = buy.sell_price_min > 0 ? Math.floor(capital / buy.sell_price_min) : 0;
          const maxAge = Math.max(ageMinutes(buy.sell_price_min_date), ageMinutes(sellDate));
          const freshness = Math.max(0, 100 - maxAge / maxAgeMin * 100);
          const roiScore = Math.min(100, roi * 2);
          const profitScore = Math.min(100, profit / Math.max(1, minProfit) * 25);
          const score = Math.round(roiScore * .5 + profitScore * .3 + freshness * .2);
          base.push({ itemId:item.id,itemName:names.get(item.id)??item.id,quality:q,qualityName:qualityName(q),buyCity,sellCity,buyPrice:buy.sell_price_min,sellPrice,fees,profit,roi,buyAgeMin:Math.round(ageMinutes(buy.sell_price_min_date)),sellAgeMin:Math.round(ageMinutes(sellDate)),affordableQty,potentialProfit:profit*affordableQty,score,recommendedQty:0,recommendedInvestment:0,recommendedProfit:0,allocationPct:0,avgDailyVolume:0,volume7d:0,historyAvgPrice:0,priceDeviationPct:0,volatilityPct:0,liquidity:"Sem dados",buyHistoryAvgPrice:0,entryAdvantagePct:0,trendPct:0,intelligenceScore:0,intelligenceComponents:{profit:0,return:0,liquidity:0,stability:0,freshness:0,capitalEfficiency:0},marketCondition:"NO_HISTORY",risk:"Médio",history:[] });
        }
      }
    }

    base.sort((a,b)=>b.score-a.score || b.profit-a.profit);
    const candidates = base.slice(0, 90);
    const historyIds = [...new Set(candidates.map(f=>f.itemId))];
    const historyLocations = [...new Set(candidates.flatMap(f=>[f.buyCity,f.sellCity]))];
    const histories = await loadMarketHistory(historyIds, historyLocations, 8);
    const historyMap = new Map(histories.map(h=>[`${h.item_id}|${h.location}|${h.quality}`, h.data]));

    for (const f of candidates) {
      // Sell-city history measures exit liquidity/stability; buy-city history measures entry quality.
      const sellHistory=historyMap.get(`${f.itemId}|${f.sellCity}|${f.quality}`) ?? [];
      const buyHistory=historyMap.get(`${f.itemId}|${f.buyCity}|${f.quality}`) ?? [];
      const stats = historyStats(sellHistory, f.sellPrice);
      const buyStats=historyStats(buyHistory,f.buyPrice);
      Object.assign(f, stats);
      f.buyHistoryAvgPrice=buyStats.historyAvgPrice;
      f.trendPct=historyTrendPct(stats.history);
      f.liquidity = liquidityFor(f.avgDailyVolume);
      f.risk = riskFor(f.avgDailyVolume, f.volatilityPct, f.priceDeviationPct, Math.max(f.buyAgeMin,f.sellAgeMin));
      const freshnessScore = Math.max(0, 100 - Math.max(f.buyAgeMin,f.sellAgeMin) / maxAgeMin * 100);
      const liquidityScore = Math.min(100, f.avgDailyVolume * 4);
      const stabilityScore = Math.max(0, 100 - Math.min(100, f.volatilityPct * 3));
      const roiScore = Math.min(100, f.roi * 2);
      const profitScore = Math.min(100, f.profit / Math.max(1,minProfit) * 25);
      f.score = Math.round(roiScore*.32 + profitScore*.18 + freshnessScore*.18 + liquidityScore*.22 + stabilityScore*.10);

      const allocationBudget = capital * (maxAllocationPct/100);
      const capitalQty = f.buyPrice > 0 ? Math.floor(allocationBudget/f.buyPrice) : 0;
      const liquidityQty = f.avgDailyVolume > 0 ? Math.max(1, Math.floor(f.avgDailyVolume*(maxDailyVolumePct/100))) : 1;
      f.recommendedQty = Math.min(capitalQty, liquidityQty);
      f.recommendedInvestment = f.recommendedQty*f.buyPrice;
      f.recommendedProfit = f.recommendedQty*f.profit;
      f.allocationPct = capital > 0 ? f.recommendedInvestment/capital*100 : 0;
      f.potentialProfit = f.profit*f.affordableQty;
      const intel=marketIntelligence({
        roi:f.roi,profit:f.profit,avgDailyVolume:f.avgDailyVolume,volatilityPct:f.volatilityPct,
        dataAgeMin:Math.max(f.buyAgeMin,f.sellAgeMin),buyPrice:f.buyPrice,buyHistoryAvgPrice:f.buyHistoryAvgPrice,
        trendPct:f.trendPct,recommendedInvestment:f.recommendedInvestment,recommendedProfit:f.recommendedProfit
      });
      f.entryAdvantagePct=intel.entryAdvantagePct;
      f.intelligenceScore=intel.score;
      f.intelligenceComponents=intel.components;
      f.marketCondition=intel.condition;
    }

    candidates.sort((a,b)=>b.intelligenceScore-a.intelligenceScore || b.score-a.score || b.recommendedProfit-a.recommendedProfit);
    let remaining=capital;
    const plan: Flip[]=[];
    for (const f of candidates) {
      if (remaining < f.buyPrice || plan.length>=12 || f.recommendedQty<1) continue;
      const qty=Math.min(f.recommendedQty,Math.floor(remaining/f.buyPrice));
      if(qty<1) continue;
      const investment=qty*f.buyPrice;
      plan.push({...f,planQty:qty,planInvestment:investment,planProfit:qty*f.profit});
      remaining-=investment;
    }
    const invested=capital-remaining;
    const expectedProfit=plan.reduce((sum,x)=>sum+(x.planProfit??0),0);
    return NextResponse.json({count:base.length,scannedItems:items.length,flips:candidates.slice(0,90),plan,summary:{capital,invested,remaining,expectedProfit,expectedRoi:invested>0?expectedProfit/invested*100:0,maxAllocationPct,maxDailyVolumePct}});
  } catch(error) {
    console.error(error);
    return NextResponse.json({error:error instanceof Error?error.message:"Erro inesperado."},{status:500});
  }
}
