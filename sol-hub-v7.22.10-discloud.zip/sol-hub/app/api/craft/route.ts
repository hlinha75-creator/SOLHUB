import {parseFocusProfile,parseCraftingSpecProfile,profileFce,focusCostPerCraft} from "../../../lib/focus";import {craftKind,craftCityFor,isSupportedCraftId} from "../../../lib/craftCatalog";import {craftBonusBreakdown} from "../../../lib/albionBonuses";import {getEuropeDailyBonuses,dailyBonusForItem} from "../../../lib/dailyBonus";export const runtime = "nodejs";
export const maxDuration = 30;
import { NextRequest, NextResponse } from "next/server";
import {itemSearchScore} from "../../../lib/itemSearch";
import { loadMarketPrices, ageMinutes } from "../../../lib/albion";import {itemLanguage,buildLocalizedNameMap,type ItemLanguage} from "../../../lib/localizedNames";
const CITIES=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"], SELL=[...CITIES,"Black Market"];
const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json", NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
type Mat={id:string;count:number;ret:boolean;name?:string}; const SUB:Record<string,string>={sword:"Lymhurst",bow:"Lymhurst",arcanestaff:"Lymhurst",axe:"Martlock",quarterstaff:"Martlock",froststaff:"Martlock",mace:"Thetford",firestaff:"Thetford",naturestaff:"Thetford",hammer:"Fort Sterling",spear:"Fort Sterling",holystaff:"Fort Sterling",crossbow:"Bridgewatch",dagger:"Bridgewatch",cursestaff:"Bridgewatch",knuckles:"Caerleon",shapeshifterstaff:"Caerleon",cloth_armor:"Fort Sterling",plate_helmet:"Fort Sterling",leather_helmet:"Lymhurst",leather_shoes:"Lymhurst",plate_armor:"Bridgewatch",cloth_shoes:"Bridgewatch",leather_armor:"Thetford",cloth_helmet:"Thetford",plate_shoes:"Martlock"}; const CAT:Record<string,string>={offhands:"Martlock",bags:"Brecilien",capes:"Brecilien",gathering:"Caerleon"};
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x]; const base=(id:string)=>id.replace(/@\d+$/,''); const ench=(id:string)=>Number(id.match(/@(\d+)$/)?.[1]??0);
async function names(lang:ItemLanguage){const r=await fetch(NAMES,{next:{revalidate:86400}});if(!r.ok)throw Error("Falha ao carregar nomes.");const a=await r.json();return buildLocalizedNameMap(a,lang)}
function hasCraftResources(req:any){return arr(req?.craftresource).some((r:any)=>r?.["@uniquename"]&&Number(r?.["@count"]??0)>0)}
async function craftableIds(){
 const d=await fetch(FULL,{next:{revalidate:86400}}).then(r=>{if(!r.ok)throw Error("Falha ao carregar catálogo de crafting.");return r.json()});
 const allEntries=Object.values(d?.items??{}).flatMap((v:any)=>arr(v));
 const ids=new Set<string>();
 for(const it of allEntries){
   const id=String(it?.["@uniquename"]??"");
   if(!id)continue;
   const req=Array.isArray(it?.craftingrequirements)?it.craftingrequirements[0]:it?.craftingrequirements;
   const baseCraftable=isSupportedCraftId(id,3,8)&&hasCraftResources(req);
   if(!baseCraftable)continue;
   ids.add(id);

   // Enchanted variants inherit the craftability of the base item.
   // ao-bin does not always repeat craftresource inside each enchantment node.
   for(const lv of arr(it?.enchantments?.enchantment)){
     const level=Number(lv?.["@enchantmentlevel"]??0);
     if(level>0&&level<=4)ids.add(`${id}@${level}`);
   }
 }
 return ids;
}
function matId(r:any){const id=r?.["@uniquename"]??"",e=r?.["@enchantmentlevel"];return e&&e!=="0"&&!id.includes("@")?`${id}@${e}`:id}
async function recipe(id:string,lang:ItemLanguage){
 const [d,n]=await Promise.all([
  fetch(FULL,{next:{revalidate:86400}}).then(r=>{if(!r.ok)throw Error("Falha ao carregar receitas.");return r.json()}),
  names(lang)
 ]);
 const allEntries=Object.values(d?.items??{}).flatMap((v:any)=>arr(v));
 let it:any=allEntries.find((x:any)=>x?.["@uniquename"]===id);
 let exact=true;
 if(!it){it=allEntries.find((x:any)=>x?.["@uniquename"]===base(id));exact=false}
 if(!it)throw Error("Receita não encontrada.");
 let req=Array.isArray(it.craftingrequirements)?it.craftingrequirements[0]:it.craftingrequirements;
 let itemValue=Number(it?.["@itemvalue"]??0);
 if(!exact&&ench(id)){
   const level=ench(id);
   const lv=arr(it?.enchantments?.enchantment).find((x:any)=>Number(x?.["@enchantmentlevel"])===level);
   if(!lv)throw Error("Enchant deste item não encontrado.");
   const lvReq=Array.isArray(lv?.craftingrequirements)?lv.craftingrequirements[0]:lv?.craftingrequirements;
   if(lvReq)req=lvReq;
   itemValue=Number(lv?.["@itemvalue"]??(itemValue*Math.pow(2,level)));
 }
 const materials:Mat[]=arr(req?.craftresource).map((r:any)=>({
   id:matId(r),count:Number(r?.["@count"]??0),ret:r?.["@maxreturnamount"]!=="0"
 })).filter((x:Mat)=>x.id&&x.count);
 for(const m of materials)m.name=n.get(m.id)??n.get(base(m.id))??m.id;
 if(!materials.length)throw Error("Receita não suportada.");
 const shopcategory=it?.["@shopcategory"]??"",subcategory=it?.["@shopsubcategory1"]??"";
 return {
  id,name:n.get(id)??n.get(base(id))??id,
  kind:craftKind(id)??"equipment",
  city:craftCityFor(id,shopcategory,subcategory),
  materials,focusBase:Number(req?.["@craftingfocus"]??0)||null,itemValue,
  outputPerCraft:Math.max(1,Number(req?.["@amountcrafted"]??it?.["@amountcrafted"]??1)),
  shopcategory,subcategory
 };
}
export async function GET(req:NextRequest){try{const p=req.nextUrl.searchParams,lang=itemLanguage(p.get("lang")),q=p.get("q");if(q){
 const [n,craftable]=await Promise.all([names(lang),craftableIds()]);
 const matchScore=(id:string,name:string)=>itemSearchScore(id,name,q);
 const candidates=[...craftable].map(id=>({id,name:n.get(id)??n.get(base(id))??id}));
 const results=candidates
   .filter(x=>matchScore(x.id,x.name)<99)
   .sort((a,b)=>matchScore(a.id,a.name)-matchScore(b.id,b.name)||a.name.localeCompare(b.name)||a.id.localeCompare(b.id))
   .slice(0,100)
   .map(x=>({id:x.id,name:x.name,kind:craftKind(x.id)}));
 return NextResponse.json(results)
}const itemId=p.get("itemId")??"T6_ARMOR_CLOTH_SET1",craftCity=p.get("craftCity")??"Fort Sterling",matsCity=p.get("matsCity")??"cheapest",sellCity=p.get("sellCity")??"Black Market",crafts=Math.max(1,Math.floor(Number(p.get("crafts")??p.get("qty")??1))),focusAvailable=Math.min(30000,Math.max(0,Number(p.get("focus")??0))),focusProfile=parseFocusProfile(p.get("focusProfile")),specProfile=parseCraftingSpecProfile(p.get("specProfile")),stationFeeRate=Math.max(0,Number(p.get("stationFee")??p.get("stationPct")??0)),premium=p.get("premium")!=="false",requestedSaleMode=p.get("saleMode")??"sell_order",saleMode=sellCity==="Black Market"?"instant_sell":requestedSaleMode;if(!CITIES.includes(craftCity)||!(matsCity==="cheapest"||CITIES.includes(matsCity))||!SELL.includes(sellCity))throw Error("Cidade inválida.");const rec=await recipe(itemId,lang),dailyData=await getEuropeDailyBonuses(),daily=dailyBonusForItem(itemId,rec.shopcategory,rec.subcategory,dailyData.bonuses),focusEfficiency=profileFce(itemId,specProfile,rec.subcategory)||(focusProfile[itemId]??0),focusPerCraft=focusCostPerCraft(rec.focusBase,focusEfficiency),focusedCrafts=focusPerCraft>0?Math.min(crafts,Math.floor(focusAvailable/focusPerCraft)):0,unfocusedCrafts=crafts-focusedCrafts,matIds=rec.materials.map(m=>m.id),locations=matsCity==="cheapest"?CITIES:[matsCity];const [mp,op]=await Promise.all([loadMarketPrices(matIds,locations),loadMarketPrices([itemId],[sellCity])]);const productionNoFocus=craftBonusBreakdown({hasSpecialty:craftCity===rec.city,focus:false,dailyBonus:daily}),productionFocus=craftBonusBreakdown({hasSpecialty:craftCity===rec.city,focus:true,dailyBonus:daily}),rrr=crafts?((productionFocus.rrr*focusedCrafts)+(productionNoFocus.rrr*unfocusedCrafts))/crafts:productionNoFocus.rrr;let gross=0,retVal=0;const breakdown=rec.materials.map(m=>{const rows=mp.filter(x=>x.item_id===m.id&&x.sell_price_min>0).sort((a,b)=>a.sell_price_min-b.sell_price_min),best=rows[0],unit=best?.sell_price_min??0,raw=m.count*crafts,returned=m.ret?m.count*(focusedCrafts*productionFocus.rrr+unfocusedCrafts*productionNoFocus.rrr):0,effective=raw-returned;gross+=raw*unit;retVal+=returned*unit;return {...m,sourceCity:best?.city??"—",unitPrice:unit,rawQty:raw,returnedQty:returned,effectiveQty:effective,cost:effective*unit,ageMin:best?ageMinutes(best.sell_price_min_date):null}});const effectiveMaterials=gross-retVal,stationFee=(rec.itemValue*rec.outputPerCraft*0.1125*stationFeeRate/100)*crafts,out=op.find(x=>x.item_id===itemId),sellUnit=saleMode==="instant_sell"?(out?.buy_price_max??0):(out?.sell_price_min??0),producedQty=crafts*rec.outputPerCraft,revenue=sellUnit*producedQty,marketFees=revenue*((premium?0.04:0.08)+(saleMode==="sell_order"?0.025:0)),totalCost=effectiveMaterials+stationFee,profit=revenue-marketFees-totalCost;return NextResponse.json({recipe:rec,crafts,producedQty,craftCity,sellCity,matsCity,focus:focusedCrafts>0,focusAvailable,focusEfficiency,focusPerCraft,focusedCrafts,unfocusedCrafts,focusUsed:focusedCrafts*focusPerCraft,daily,dailyBonuses:dailyData.bonuses,dailyBonusAvailable:dailyData.available,productionBonus:{noFocus:productionNoFocus,withFocus:productionFocus},rrr,breakdown,grossMaterials:gross,returnValue:retVal,effectiveMaterials,stationFee,totalCost,sellUnit,revenue,marketFees,profit,profitPerUnit:profit/producedQty,roi:totalCost?profit/totalCost*100:0,saleMode,sellAgeMin:out?ageMinutes(saleMode==="instant_sell"?out.buy_price_max_date:out.sell_price_min_date):null,estimatedFocus:focusPerCraft?focusedCrafts*focusPerCraft:null})}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erro de crafting."},{status:400})}}
