import {NextResponse} from "next/server";
import {getEuropeDailyBonuses} from "../../../lib/dailyBonus";
export async function GET(){return NextResponse.json(await getEuropeDailyBonuses())}
