import {NextRequest,NextResponse} from "next/server";
import {dailyBonusForItem} from "../../../lib/dailyBonus";
import {craftKind,isSupportedCraftId} from "../../../lib/craftCatalog";
import {itemLanguage,localizedItemName} from "../../../lib/localizedNames";

export const runtime="nodejs";
export const maxDuration=30;

const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];

const RESOURCE_FALLBACK:[RegExp,string[]][]=[
  [/ore|mining/i,["T8_ORE"]],
  [/metal|bar/i,["T8_METALBAR"]],
  [/wood|log/i,["T8_WOOD"]],
  [/plank/i,["T8_PLANKS"]],
  [/hide/i,["T8_HIDE"]],
  [/leather/i,["T8_LEATHER"]],
  [/fiber/i,["T8_FIBER"]],
  [/cloth/i,["T8_CLOTH"]],
  [/stone block/i,["T8_STONEBLOCK"]],
  [/stone/i,["T8_ROCK"]],
];

export async function GET(req:NextRequest){
  try{
    const lang=itemLanguage(req.nextUrl.searchParams.get("lang"));
    const category=(req.nextUrl.searchParams.get("category")??"").trim();
    if(!category)return NextResponse.json({items:[]});

    const [raw,namesRaw]=await Promise.all([
      fetch(FULL,{next:{revalidate:86400}}).then(r=>{if(!r.ok)throw Error("items");return r.json()}),
      fetch(NAMES,{next:{revalidate:86400}}).then(r=>{if(!r.ok)throw Error("names");return r.json()})
    ]);

    const names=new Map<string,string>();
    for(const x of namesRaw){
      if(x?.UniqueName)names.set(x.UniqueName,localizedItemName(x,lang)||x.UniqueName);
    }

    const all=Object.values(raw?.items??{}).flatMap((v:any)=>arr(v));
    const seen=new Set<string>();
    const matched:{id:string;name:string;kind:string}[]=[];

    for(const it of all){
      const id=String(it?.["@uniquename"]??"");
      if(!id.startsWith("T8_") || id.includes("@") || seen.has(id))continue;
      if(!isSupportedCraftId(id,8,8))continue;

      const shopcategory=String(it?.["@shopcategory"]??"");
      const subcategory=String(it?.["@shopsubcategory1"]??"");
      const bonus=dailyBonusForItem(id,shopcategory,subcategory,[{category,bonus:1}]);
      if(!bonus)continue;

      // Only show actual craftable products; avoids guessed/placeholder image IDs.
      const reqs=arr(it?.craftingrequirements);
      const hasRecipe=reqs.some((r:any)=>arr(r?.craftresource).length>0);
      if(!hasRecipe)continue;

      seen.add(id);
      matched.push({
        id,
        name:names.get(id)??id,
        kind:craftKind(id)??"equipment"
      });
    }

    // Refining/resource bonuses are not part of craftCatalog, so use verified T8 base resource IDs.
    if(!matched.length){
      const fallback=RESOURCE_FALLBACK.find(([re])=>re.test(category))?.[1]??[];
      for(const id of fallback)matched.push({id,name:names.get(id)??id,kind:"resource"});
    }

    matched.sort((a,b)=>a.name.localeCompare(b.name,"en"));
    return NextResponse.json({category,tier:8,items:matched.slice(0,36)});
  }catch{
    return NextResponse.json({items:[]});
  }
}
