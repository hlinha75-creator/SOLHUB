import {NextRequest,NextResponse} from "next/server";
import {loadMarketPrices,ageMinutes} from "../../../lib/albion";
import {getEuropeDailyBonuses,dailyBonusForItem} from "../../../lib/dailyBonus";
import {focusCostPerCraft,parseCraftingSpecProfile,profileRefiningFce} from "../../../lib/focus";
import {itemLanguage,buildLocalizedNameMap,type ItemLanguage} from "../../../lib/localizedNames";
import {parseCraftResources} from "../../../lib/recipeResources";

export const runtime="nodejs";
export const maxDuration=30;

const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";

const BUY_CITIES=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const REFINE_CITIES=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon"];
const SELL_CITIES=[...BUY_CITIES,"Black Market"];

const BASE_REFINING_BONUS=18;
const SPECIALTY_REFINING_BONUS=40;
const FOCUS_BONUS=59;
const rrrFromBonus=(bonus:number)=>bonus/(100+bonus);
function refineBonusBreakdown(opts:{hasSpecialty:boolean;focus?:boolean;dailyBonus?:number}){
  const base=BASE_REFINING_BONUS;
  const specialty=opts.hasSpecialty?SPECIALTY_REFINING_BONUS:0;
  const focus=opts.focus?FOCUS_BONUS:0;
  const daily=Math.max(0,Number(opts.dailyBonus??0));
  const total=base+specialty+focus+daily;
  return {base,specialty,focus,daily,total,rrr:rrrFromBonus(total)};
}

const FAMILIES={
  metal:{label:{en:"Metal Bars",pt:"Barras de Metal"},suffix:"METALBAR",raw:"ORE",city:"Thetford"},
  wood:{label:{en:"Planks",pt:"Tábuas"},suffix:"PLANKS",raw:"WOOD",city:"Fort Sterling"},
  leather:{label:{en:"Leather",pt:"Couro"},suffix:"LEATHER",raw:"HIDE",city:"Martlock"},
  cloth:{label:{en:"Cloth",pt:"Tecido"},suffix:"CLOTH",raw:"FIBER",city:"Lymhurst"},
  stone:{label:{en:"Stone Blocks",pt:"Blocos de Pedra"},suffix:"STONEBLOCK",raw:"ROCK",city:"Bridgewatch"}
} as const;

type FamilyKey=keyof typeof FAMILIES;
type Mat={id:string;count:number;ret:boolean;name:string};
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];
const base=(id:string)=>id.replace(/@\d+$/,"");
const enchantOf=(id:string)=>Number(id.match(/@(\d+)$/)?.[1]??0);

async function loadNames(lang:ItemLanguage){
  const r=await fetch(NAMES,{next:{revalidate:86400}});
  if(!r.ok)throw Error("Falha ao carregar nomes dos materiais.");
  const a=await r.json();
  return buildLocalizedNameMap(a,lang);
}

async function getRecipe(itemId:string,lang:ItemLanguage){
  const [data,names]=await Promise.all([
    fetch(FULL,{next:{revalidate:86400}}).then(r=>{if(!r.ok)throw Error("Falha ao carregar receitas de refino.");return r.json()}),
    loadNames(lang)
  ]);
  const all=Object.values(data?.items??{}).flatMap((v:any)=>arr(v));
  let item:any=all.find((x:any)=>x?.["@uniquename"]===itemId);
  let exact=true;
  if(!item){item=all.find((x:any)=>x?.["@uniquename"]===base(itemId));exact=false}
  if(!item)throw Error("Receita de refino não encontrada.");

  let req=Array.isArray(item?.craftingrequirements)?item.craftingrequirements[0]:item?.craftingrequirements;
  let itemValue=Number(item?.["@itemvalue"]??0);
  if(!exact&&enchantOf(itemId)){
    const lv=arr(item?.enchantments?.enchantment).find((x:any)=>Number(x?.["@enchantmentlevel"])===enchantOf(itemId));
    req=Array.isArray(lv?.craftingrequirements)?lv.craftingrequirements[0]:lv?.craftingrequirements;
    itemValue=Number(lv?.["@itemvalue"]??(itemValue*Math.pow(2,enchantOf(itemId))));
  }
  const materials:Mat[]=parseCraftResources(req?.craftresource).map(r=>({
    ...r,
    name:names.get(r.id)??names.get(base(r.id))??r.id
  }));

  if(!materials.length)throw Error("Esta receita de refino não tem materiais suportados.");

  return {
    id:itemId,
    name:names.get(itemId)??names.get(base(itemId))??itemId,
    materials,
    itemValue,
    focusBase:Number(req?.["@craftingfocus"]??0)||0,
    outputPerRefine:Math.max(1,Number(req?.["@amountcrafted"]??item?.["@amountcrafted"]??1))
  };
}

function itemIdFor(family:FamilyKey,tier:number,enchant:number){
  const suffix=FAMILIES[family].suffix;
  return enchant>0
    ?`T${tier}_${suffix}_LEVEL${enchant}@${enchant}`
    :`T${tier}_${suffix}`;
}

export async function GET(req:NextRequest){
  try{
    const p=req.nextUrl.searchParams;
    const lang=itemLanguage(p.get("lang"));
    const family=(p.get("family")??"metal") as FamilyKey;
    if(!(family in FAMILIES))throw Error("Família de material inválida.");

    const tier=Math.min(8,Math.max(3,Math.floor(Number(p.get("tier")??6))));
    const enchant=family==="stone"?0:(tier>=4?Math.min(3,Math.max(0,Math.floor(Number(p.get("enchant")??0)))):0);
    const qty=Math.max(1,Math.floor(Number(p.get("qty")??100)));
    const refineCity=p.get("refineCity")??FAMILIES[family].city;
    const matsCity=p.get("matsCity")??"cheapest";
    const sellCity=p.get("sellCity")??refineCity;
    const requestedSaleMode=p.get("saleMode")??"sell_order";
    const saleMode=sellCity==="Black Market"?"instant_sell":requestedSaleMode;
    const premium=p.get("premium")!=="false";
    const stationFeeRate=Math.max(0,Number(p.get("stationFee")??0));
    const focusAvailable=Math.min(30000,Math.max(0,Math.floor(Number(p.get("focus")??0))));
    const specProfile=parseCraftingSpecProfile(p.get("specProfile"));
    const focusEfficiency=profileRefiningFce(itemIdFor(family,tier,enchant),specProfile)||Math.max(0,Number(p.get("focusEfficiency")??0));

    if(!REFINE_CITIES.includes(refineCity))throw Error("Cidade de refino inválida.");
    if(!(matsCity==="cheapest"||BUY_CITIES.includes(matsCity)))throw Error("Cidade dos materiais inválida.");
    if(!SELL_CITIES.includes(sellCity))throw Error("Cidade de venda inválida.");
    if(!["sell_order","instant_sell"].includes(saleMode))throw Error("Modo de venda inválido.");

    const itemId=itemIdFor(family,tier,enchant);
    const recipe=await getRecipe(itemId,lang);
    const dailyData=await getEuropeDailyBonuses();
    const daily=dailyBonusForItem(itemId,`resources_${family}`,FAMILIES[family].raw,dailyData.bonuses);

    const focusPerRefine=focusCostPerCraft(recipe.focusBase,focusEfficiency);
    const focusedRefines=focusPerRefine>0?Math.min(qty,Math.floor(focusAvailable/focusPerRefine)):0;
    const unfocusedRefines=qty-focusedRefines;

    const matIds=recipe.materials.map(m=>m.id);
    const sourceCities=matsCity==="cheapest"?BUY_CITIES:[matsCity];

    const [matPrices,outPrices]=await Promise.all([
      loadMarketPrices(matIds,sourceCities),
      loadMarketPrices([itemId],[sellCity])
    ]);

    const noFocus=refineBonusBreakdown({
      hasSpecialty:refineCity===FAMILIES[family].city,
      focus:false,
      dailyBonus:daily
    });
    const withFocus=refineBonusBreakdown({
      hasSpecialty:refineCity===FAMILIES[family].city,
      focus:true,
      dailyBonus:daily
    });

    const weightedRRR=qty
      ?((withFocus.rrr*focusedRefines)+(noFocus.rrr*unfocusedRefines))/qty
      :noFocus.rrr;

    let grossMaterials=0;
    let returnValue=0;
    const breakdown=recipe.materials.map(m=>{
      const rows=matPrices
        .filter(x=>x.item_id===m.id&&x.sell_price_min>0)
        .sort((a,b)=>a.sell_price_min-b.sell_price_min);
      const best=rows[0];
      const unitPrice=best?.sell_price_min??0;
      const rawQty=m.count*qty;
      const returnedQty=m.ret
        ?m.count*((focusedRefines*withFocus.rrr)+(unfocusedRefines*noFocus.rrr))
        :0;
      const effectiveQty=rawQty-returnedQty;
      grossMaterials+=rawQty*unitPrice;
      returnValue+=returnedQty*unitPrice;
      return {
        ...m,
        sourceCity:best?.city??"—",
        unitPrice,
        rawQty,
        returnedQty,
        effectiveQty,
        cost:effectiveQty*unitPrice,
        ageMin:best?ageMinutes(best.sell_price_min_date):null
      };
    });

    const effectiveMaterials=grossMaterials-returnValue;
    const stationFee=(recipe.itemValue*recipe.outputPerRefine*0.1125*stationFeeRate/100)*qty;
    const out=outPrices.find(x=>x.item_id===itemId);
    const sellUnit=saleMode==="instant_sell"?(out?.buy_price_max??0):(out?.sell_price_min??0);
    const producedQty=qty*recipe.outputPerRefine;
    const revenue=sellUnit*producedQty;
    const marketFees=revenue*((premium?0.04:0.08)+(saleMode==="sell_order"?0.025:0));
    const totalCost=effectiveMaterials+stationFee;
    const profit=revenue-marketFees-totalCost;

    const cityComparison=REFINE_CITIES.map(city=>{
      const nf=refineBonusBreakdown({hasSpecialty:city===FAMILIES[family].city,focus:false,dailyBonus:daily});
      const wf=refineBonusBreakdown({hasSpecialty:city===FAMILIES[family].city,focus:true,dailyBonus:daily});
      const rrr=qty?((wf.rrr*focusedRefines)+(nf.rrr*unfocusedRefines))/qty:nf.rrr;
      return {
        city,
        specialty:city===FAMILIES[family].city,
        productionBonus:focusedRefines?wf.total:nf.total,
        rrr
      };
    }).sort((a,b)=>b.rrr-a.rrr);

    return NextResponse.json({
      family,
      familyLabel:lang==="pt-BR"?FAMILIES[family].label.pt:FAMILIES[family].label.en,
      specialtyCity:FAMILIES[family].city,
      tier,enchant,itemId,recipe,qty,producedQty,
      refineCity,matsCity,sellCity,saleMode,premium,
      daily,dailyBonuses:dailyData.bonuses,dailyBonusAvailable:dailyData.available,
      focusAvailable,focusEfficiency,focusPerRefine,focusedRefines,unfocusedRefines,
      focusUsed:focusedRefines*focusPerRefine,
      productionBonus:{noFocus,withFocus},
      rrr:weightedRRR,
      breakdown,grossMaterials,returnValue,effectiveMaterials,
      stationFee,totalCost,sellUnit,revenue,marketFees,profit,
      profitPerUnit:producedQty?profit/producedQty:0,
      roi:totalCost?profit/totalCost*100:0,
      sellAgeMin:out?ageMinutes(saleMode==="instant_sell"?out.buy_price_max_date:out.sell_price_min_date):null,
      cityComparison
    });
  }catch(e){
    return NextResponse.json({error:e instanceof Error?e.message:"Erro de refino."},{status:400});
  }
}
