import {NextRequest,NextResponse} from "next/server";
import {craftFamilyFor,normalizedItemId,specNodeKey} from "../../../lib/specializationModel";
import {isSupportedCraftId} from "../../../lib/craftCatalog";
import {itemLanguage,localizedItemName} from "../../../lib/localizedNames";

export const runtime="nodejs";
export const maxDuration=30;

const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];

export async function GET(req:NextRequest){
  try{
    const lang=itemLanguage(req.nextUrl.searchParams.get("lang"));
    const [raw,namesRaw]=await Promise.all([
      fetch(FULL,{next:{revalidate:86400}}).then(r=>r.json()),
      fetch(NAMES,{next:{revalidate:86400}}).then(r=>r.json())
    ]);
    const names=new Map<string,string>();
    for(const x of namesRaw)if(x?.UniqueName)names.set(x.UniqueName,localizedItemName(x,lang)||x.UniqueName);

    const groups=new Map<string,{id:string;name:string;icon:string;type:string;items:any[]}>();
    const seen=new Set<string>();
    const all=Object.values(raw?.items??{}).flatMap((v:any)=>arr(v));

    for(const it of all){
      const id=String(it?.["@uniquename"]??"");
      if(!isSupportedCraftId(id,3,8))continue;
      const fam=craftFamilyFor(id,String(it?.["@shopsubcategory1"]??""));
      if(!fam)continue;
      const base=specNodeKey(id,fam);
      const seenKey=`${fam.id}:${base}`;
      if(seen.has(seenKey))continue;
      // only actual craftable products
      if(!arr(it?.craftingrequirements).some((r:any)=>arr(r?.craftresource).length))continue;

      seen.add(seenKey);
      if(!groups.has(fam.id))groups.set(fam.id,{...fam,items:[]});
      groups.get(fam.id)!.items.push({
        id,baseId:base,name:names.get(id)??names.get(id.replace(/@\d+$/,""))??(fam.type==="cape"?"Cape Crafting Specialist":base),
      });
    }
    const refiningGroups=[
      {id:"refine_metal",name:"Ore Refiner",icon:"⛏️",type:"refining",suffix:"METALBAR",label:"Metal Bar"},
      {id:"refine_wood",name:"Wood Refiner",icon:"🪵",type:"refining",suffix:"PLANKS",label:"Plank"},
      {id:"refine_leather",name:"Hide Refiner",icon:"🦌",type:"refining",suffix:"LEATHER",label:"Leather"},
      {id:"refine_cloth",name:"Fiber Refiner",icon:"🌾",type:"refining",suffix:"CLOTH",label:"Cloth"},
      {id:"refine_stone",name:"Stone Refiner",icon:"🪨",type:"refining",suffix:"STONEBLOCK",label:"Stone Block"},
    ].map(g=>({
      id:g.id,name:g.name,icon:g.icon,type:g.type,
      items:[4,5,6,7,8].map(t=>{
        const id=`T${t}_${g.suffix}`;
        return {id,baseId:`T${t}`,name:names.get(id)??`T${t} ${g.label} Refiner`};
      })
    }));
    const out=[
      ...[...groups.values()].map(g=>({...g,items:g.items.sort((a,b)=>a.name.localeCompare(b.name,"en"))})),
      ...refiningGroups
    ].sort((a,b)=>a.name.localeCompare(b.name,"en"));
    return NextResponse.json({groups:out});
  }catch{
    return NextResponse.json({groups:[]});
  }
}
