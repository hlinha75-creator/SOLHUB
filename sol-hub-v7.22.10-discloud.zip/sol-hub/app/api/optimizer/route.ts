import {parseFocusProfile,parseCraftingSpecProfile,profileFce,profileRefiningFce,focusCostPerCraft} from "../../../lib/focus";import {craftKind,craftCityFor,isSupportedCraftId} from "../../../lib/craftCatalog";import {craftBonusBreakdown} from "../../../lib/albionBonuses";import {getEuropeDailyBonuses,dailyBonusForItem} from "../../../lib/dailyBonus";export const runtime = "nodejs";
export const maxDuration = 30;
import {NextRequest,NextResponse} from "next/server";
import {CITIES,ageMinutes,loadItems,loadMarketPrices} from "../../../lib/albion";
import {itemLanguage,localizedItemName} from "../../../lib/localizedNames";
const RAW="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const ROYALS=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];
const SUB:Record<string,string>={sword:"Lymhurst",bow:"Lymhurst",arcanestaff:"Lymhurst",axe:"Martlock",quarterstaff:"Martlock",froststaff:"Martlock",mace:"Thetford",firestaff:"Thetford",naturestaff:"Thetford",hammer:"Fort Sterling",spear:"Fort Sterling",holystaff:"Fort Sterling",crossbow:"Bridgewatch",dagger:"Bridgewatch",cursestaff:"Bridgewatch",knuckles:"Caerleon",shapeshifterstaff:"Caerleon",cloth_armor:"Fort Sterling",plate_helmet:"Fort Sterling",leather_helmet:"Lymhurst",leather_shoes:"Lymhurst",plate_armor:"Bridgewatch",cloth_shoes:"Bridgewatch",leather_armor:"Thetford",cloth_helmet:"Thetford",plate_shoes:"Martlock"};
const CAT:Record<string,string>={offhands:"Martlock",bags:"Brecilien",capes:"Brecilien",gathering:"Caerleon"};
const REFINE_DEFS=[
  {key:"metal",suffix:"METALBAR",city:"Thetford",label:"Metal Bars"},
  {key:"wood",suffix:"PLANKS",city:"Fort Sterling",label:"Planks"},
  {key:"leather",suffix:"LEATHER",city:"Martlock",label:"Leather"},
  {key:"cloth",suffix:"CLOTH",city:"Lymhurst",label:"Cloth"},
  {key:"stone",suffix:"STONEBLOCK",city:"Bridgewatch",label:"Stone Blocks"},
] as const;
function refiningBonus(opts:{specialty:boolean;focus:boolean;daily:number}){
  const total=18+(opts.specialty?40:0)+(opts.focus?59:0)+Math.max(0,Number(opts.daily)||0);
  return {total,rrr:total/(100+total)};
}
function mid(r:any){const id=r?.["@uniquename"]??"",e=r?.["@enchantmentlevel"];return e&&e!=="0"&&!id.includes("@")?`${id}@${e}`:id}
function riskByAge(age:number,roi:number){if(age<=60&&roi>=18)return "Baixo";if(age<=240&&roi>=10)return "Médio";return "Alto"}
function rankRisk(r:string){return r==="Baixo"?1:r==="Médio"?2:3}
export async function GET(req:NextRequest){try{
 const p=req.nextUrl.searchParams,lang=itemLanguage(p.get("lang")),capital=Number(p.get("capital")??15000000),focusAvailable=Math.min(30000,Math.max(0,Number(p.get("focus")??0))),focusProfile=parseFocusProfile(p.get("focusProfile")),specProfile=parseCraftingSpecProfile(p.get("specProfile")),minRoi=Number(p.get("minRoi")??10),maxAgeH=Number(p.get("maxAgeHours")??4),maxAlloc=Math.min(100,Math.max(1,Number(p.get("maxAllocationPct")??20))),riskMax=p.get("risk")??"Médio",premium=p.get("premium")!=="false",craftSell=p.get("craftSellCity")??"Black Market",refineSell=p.get("refineSellCity")??"Thetford",stationFeeRate=Math.max(0,Number(p.get("stationFee")??p.get("stationPct")??0)),includeFlips=p.get("includeFlips")!=="false",includeCrafts=p.get("includeCrafts")!=="false",includeRefines=p.get("includeRefines")!=="false";
 const maxAge=maxAgeH*60,tax=premium?.04:.08,setup=.025;
 const opportunities:any[]=[];

 // FLIPS: only run this engine when selected.
 if(includeFlips){
   const items=(await loadItems("all",[4,5,6,7,8],[0,1,2,3],lang)).slice(0,220);
   const ids=items.map(x=>x.id),names=new Map(items.map(x=>[x.id,x.name]));
   const prices=await loadMarketPrices(ids,[...CITIES]);
   const by=new Map<string,any>(); for(const x of prices)if(x.quality===1)by.set(`${x.item_id}|${x.city}`,x);
   for(const it of items){
    for(const b of ROYALS){const bp=by.get(`${it.id}|${b}`);if(!bp?.sell_price_min)continue;const ba=ageMinutes(bp.sell_price_min_date);if(ba>maxAge)continue;
     for(const s of CITIES){if(s===b)continue;const sp=by.get(`${it.id}|${s}`);if(!sp)continue;const sell=s==="Black Market"?sp.buy_price_max:sp.sell_price_min,sd=s==="Black Market"?sp.buy_price_max_date:sp.sell_price_min_date;if(!sell)continue;const sa=ageMinutes(sd);if(sa>maxAge)continue;const fees=sell*tax+(s==="Black Market"?0:sell*setup),profit=sell-bp.sell_price_min-fees,roi=profit/bp.sell_price_min*100;if(profit<=0||roi<minRoi)continue;const risk=riskByAge(Math.max(ba,sa),roi);if(rankRisk(risk)>rankRisk(riskMax))continue;const score=Math.max(0,Math.min(100,Math.round(roi*2.2+(100-Math.min(100,Math.max(ba,sa)/maxAge*100))*.35)));opportunities.push({type:"FLIP",itemId:it.id,name:names.get(it.id)??it.id,route:`${b} → ${s}`,unitInvestment:bp.sell_price_min,unitProfit:profit,roi,score,risk,dataAgeMin:Math.round(Math.max(ba,sa)),reason:lang==="en"?`${roi.toFixed(1)}% return • data ≤ ${maxAgeH}h`:`${roi.toFixed(1)}% rentabilidade • dados ≤ ${maxAgeH}h`})}
    }
   }
   opportunities.sort((a,b)=>b.score-a.score||b.unitProfit-a.unitProfit);
   const flips=opportunities.splice(0,70); opportunities.push(...flips);
 }
 // Shared Albion catalog: loaded only when a production engine is selected.
 const nmap=new Map<string,string>();let allItems:any[]=[];let dailyData:any={bonuses:[],available:false};
 if(includeCrafts||includeRefines){
  const [data,formatted]=await Promise.all([fetch(RAW,{next:{revalidate:86400}}).then(r=>r.json()),fetch(NAMES,{next:{revalidate:86400}}).then(r=>r.json())]);
  for(const x of formatted)if(x.UniqueName)nmap.set(x.UniqueName,localizedItemName(x,lang)||x.UniqueName);
  allItems=Object.values(data?.items??{}).flatMap((v:any)=>arr(v));
  dailyData=await getEuropeDailyBonuses();
 }
 if(includeCrafts){
  const candidates:any[]=[];
 for(const it of allItems){
  const id=it?.["@uniquename"]??"",kind=craftKind(id);
  if(!kind||!isSupportedCraftId(id,3,8))continue;
  let req=Array.isArray(it.craftingrequirements)?it.craftingrequirements[0]:it.craftingrequirements;
  const mats=arr(req?.craftresource).map((r:any)=>({id:mid(r),count:Number(r?.["@count"]??0),ret:r?.["@maxreturnamount"]!=="0"})).filter((m:any)=>m.id&&m.count);
  if(!mats.length)continue;
  const shopcategory=it?.["@shopcategory"]??"",subcategory=it?.["@shopsubcategory1"]??"";
  candidates.push({
    id,name:nmap.get(id)??id,kind,city:craftCityFor(id,shopcategory,subcategory),
    mats,focusBase:Number(req?.["@craftingfocus"]??0)||0,itemValue:Number(it?.["@itemvalue"]??0),
    outputPerCraft:Math.max(1,Number(req?.["@amountcrafted"]??it?.["@amountcrafted"]??1)),
    shopcategory,subcategory
  });
 }
 const limited=[
  ...candidates.filter(x=>x.kind==="equipment").slice(0,80),
  ...candidates.filter(x=>x.kind==="potion").slice(0,40),
  ...candidates.filter(x=>x.kind==="food").slice(0,60)
 ];
 candidates.length=0;candidates.push(...limited);
 const matIds=[...new Set(candidates.flatMap(x=>x.mats.map((m:any)=>m.id)))];
 const [mp,cp]=await Promise.all([loadMarketPrices(matIds,ROYALS),loadMarketPrices(candidates.map(x=>x.id),[craftSell])]);
 const cheapest=new Map<string,{price:number;city:string;age:number}>();for(const x of mp){const cur=cheapest.get(x.item_id);if(x.sell_price_min>0&&(!cur||x.sell_price_min<cur.price))cheapest.set(x.item_id,{price:x.sell_price_min,city:x.city,age:ageMinutes(x.sell_price_min_date)})};
 const sale=new Map<string,{price:number;age:number}>();for(const x of cp){const v=craftSell==="Black Market"?x.buy_price_max:x.sell_price_min,d=craftSell==="Black Market"?x.buy_price_max_date:x.sell_price_min_date,cur=sale.get(x.item_id);if(v>0&&(!cur||v>cur.price))sale.set(x.item_id,{price:v,age:ageMinutes(d)})}
 for(const c of candidates){const daily=dailyBonusForItem(c.id,c.shopcategory,c.subcategory,dailyData.bonuses),focusEfficiency=profileFce(c.id,specProfile,c.subcategory)||(focusProfile[c.id]??0),focusPerCraft=focusCostPerCraft(c.focusBase,focusEfficiency),prodNo=craftBonusBreakdown({hasSpecialty:true,focus:false,dailyBonus:daily}),prodFocus=craftBonusBreakdown({hasSpecialty:true,focus:true,dailyBonus:daily});let gross=0,ret=0,miss=false,maxMatAge=0;const shopping:Record<string,{id:string;name:string;qty:number;unitPrice:number}[]>={};for(const m of c.mats){const best=cheapest.get(m.id);if(!best){miss=true;break}const u=best.price;maxMatAge=Math.max(maxMatAge,best.age);(shopping[best.city]??=[]).push({id:m.id,name:nmap.get(m.id)??m.id,qty:m.count,unitPrice:u});gross+=u*m.count;if(m.ret)ret+=u*m.count*prodNo.rrr}if(miss)continue;let retFocus=0;for(const m of c.mats){const best=cheapest.get(m.id);if(best&&m.ret)retFocus+=best.price*m.count*prodFocus.rrr}const buyLabel=Object.keys(shopping).join(" + ");const stationFee=c.itemValue*c.outputPerCraft*0.1125*stationFeeRate/100;const investNo=gross-ret+stationFee,investFocus=gross-retFocus+stationFee,sellData=sale.get(c.id),sell=sellData?.price??0;if(!sell||investNo<=0)continue;const dataAgeMin=Math.round(Math.max(maxMatAge,sellData?.age??0));const revenue=sell*c.outputPerCraft,fees=revenue*tax+(craftSell==="Black Market"?0:revenue*setup),profitNo=revenue-fees-investNo,profitFocus=revenue-fees-investFocus,canFocus=focusPerCraft>0&&focusAvailable>=focusPerCraft,invest=canFocus?investFocus:investNo,profit=canFocus?profitFocus:profitNo,roi=profit/invest*100;if(profit<=0||roi<minRoi)continue;const risk=roi>=20?"Baixo":roi>=12?"Médio":"Alto";if(rankRisk(risk)>rankRisk(riskMax))continue;const focusValue=canFocus&&focusPerCraft>0?Math.max(0,(profitFocus-profitNo)/focusPerCraft):0;const score=Math.max(0,Math.min(100,Math.round(roi*2.15+Math.min(28,profit/5000)+Math.min(18,focusValue*180))));opportunities.push({type:"CRAFT",itemId:c.id,name:c.name,kind:c.kind,route:lang==="en"?`Buy: ${buyLabel} | Craft: ${c.city} | Sell: ${craftSell}`:`Comprar: ${buyLabel} | Craftar: ${c.city} | Vender: ${craftSell}`,shopping,outputPerCraft:c.outputPerCraft,daily,rrr:canFocus?prodFocus.rrr:prodNo.rrr,productionBonus:canFocus?prodFocus.total:prodNo.total,focusEfficiency,focusPerCraft,unitInvestment:invest,unitProfit:profit,unitInvestmentNoFocus:investNo,unitProfitNoFocus:profitNo,unitInvestmentFocus:investFocus,unitProfitFocus:profitFocus,roi,score,risk,focusMode:canFocus,dataAgeMin,reason:lang==="en"?`${roi.toFixed(1)}% return${daily?` • Daily +${daily}%`:""}${canFocus?" • Return Rate with Focus":""}`:`${roi.toFixed(1)}% rentabilidade${daily?` • Daily +${daily}%`:""}${canFocus?" • Return Rate com Focus":""}`})}
 }

 // REFINING: only run this engine when selected.
 if(includeRefines){
   const refiningCandidates:any[]=[];
   for(const def of REFINE_DEFS){
     for(let tier=4;tier<=8;tier++){
       const baseId=`T${tier}_${def.suffix}`;
       const item=allItems.find((x:any)=>String(x?.["@uniquename"]??"")===baseId);
       if(!item)continue;
       const variants:[number,any][]=[[0,item]];
       if(def.key!=="stone"){
         for(const ev of arr(item?.enchantments?.enchantment)){
           const lv=Number(ev?.["@enchantmentlevel"]??0);
           if(lv>=1&&lv<=3)variants.push([lv,ev]);
         }
       }
       for(const [ench,node] of variants){
         const reqRaw=node===item?item?.craftingrequirements:node?.craftingrequirements;
         const req=Array.isArray(reqRaw)?reqRaw[0]:reqRaw;
         const mats=arr(req?.craftresource).map((r:any)=>({id:mid(r),count:Number(r?.["@count"]??0),ret:r?.["@maxreturnamount"]!=="0"})).filter((m:any)=>m.id&&m.count);
         if(!mats.length)continue;
         const itemId=ench>0?`${baseId}_LEVEL${ench}@${ench}`:baseId;
         refiningCandidates.push({
           id:itemId,name:nmap.get(itemId)??nmap.get(baseId)??`T${tier}${ench?`.${ench}`:""} ${def.label}`,family:def.key,city:def.city,mats,
           focusBase:Number(req?.["@craftingfocus"]??0)||0,
           itemValue:Number(node?.["@itemvalue"]??item?.["@itemvalue"]??0),
           outputPerCraft:Math.max(1,Number(req?.["@amountcrafted"]??node?.["@amountcrafted"]??item?.["@amountcrafted"]??1))
         });
       }
     }
   }
   const refineMatIds=[...new Set(refiningCandidates.flatMap(x=>x.mats.map((m:any)=>m.id)))];
   const [rmp,rsp]=await Promise.all([
     loadMarketPrices(refineMatIds,ROYALS),
     loadMarketPrices(refiningCandidates.map(x=>x.id),[refineSell])
   ]);
   const rcheap=new Map<string,{price:number;city:string;age:number}>();
   for(const x of rmp){const cur=rcheap.get(x.item_id),age=ageMinutes(x.sell_price_min_date);if(x.sell_price_min>0&&age<=maxAge&&(!cur||x.sell_price_min<cur.price))rcheap.set(x.item_id,{price:x.sell_price_min,city:x.city,age})}
   const rsale=new Map<string,{price:number;age:number}>();
   for(const x of rsp){const v=refineSell==="Black Market"?x.buy_price_max:x.sell_price_min,d=refineSell==="Black Market"?x.buy_price_max_date:x.sell_price_min_date,a=ageMinutes(d),cur=rsale.get(x.item_id);if(v>0&&a<=maxAge&&(!cur||v>cur.price))rsale.set(x.item_id,{price:v,age:a})}
   for(const c of refiningCandidates){
     const daily=dailyBonusForItem(c.id,`resources_${c.family}`,c.family,dailyData.bonuses);
     const focusEfficiency=profileRefiningFce(c.id,specProfile);
     const focusPerCraft=focusCostPerCraft(c.focusBase,focusEfficiency);
     const prodNo=refiningBonus({specialty:true,focus:false,daily});
     const prodFocus=refiningBonus({specialty:true,focus:true,daily});
     let gross=0,retNo=0,retFocus=0,miss=false,maxMatAge=0;
     const shopping:Record<string,{id:string;name:string;qty:number;unitPrice:number}[]>={};
     for(const m of c.mats){
       const best=rcheap.get(m.id);if(!best){miss=true;break}
       maxMatAge=Math.max(maxMatAge,best.age);
       (shopping[best.city]??=[]).push({id:m.id,name:nmap.get(m.id)??m.id,qty:m.count,unitPrice:best.price});
       gross+=best.price*m.count;
       if(m.ret){retNo+=best.price*m.count*prodNo.rrr;retFocus+=best.price*m.count*prodFocus.rrr}
     }
     if(miss)continue;
     const stationFee=c.itemValue*c.outputPerCraft*0.1125*stationFeeRate/100;
     const investNo=gross-retNo+stationFee,investFocus=gross-retFocus+stationFee;
     const sellData=rsale.get(c.id),sell=sellData?.price??0;if(!sell||investNo<=0)continue;
     const dataAgeMin=Math.round(Math.max(maxMatAge,sellData?.age??0));
     const revenue=sell*c.outputPerCraft,fees=revenue*tax+(refineSell==="Black Market"?0:revenue*setup);
     const profitNo=revenue-fees-investNo,profitFocus=revenue-fees-investFocus;
     const canFocus=focusPerCraft>0&&focusAvailable>=focusPerCraft;
     const invest=canFocus?investFocus:investNo,profit=canFocus?profitFocus:profitNo,roi=profit/invest*100;
     if(profit<=0||roi<minRoi)continue;
     const risk=roi>=20?"Baixo":roi>=12?"Médio":"Alto";if(rankRisk(risk)>rankRisk(riskMax))continue;
     const focusValue=canFocus&&focusPerCraft>0?Math.max(0,(profitFocus-profitNo)/focusPerCraft):0;const score=Math.max(0,Math.min(100,Math.round(roi*2.15+Math.min(28,profit/5000)+Math.min(18,focusValue*180))));
     const buyLabel=Object.keys(shopping).join(" + ");
     opportunities.push({
       type:"REFINE",itemId:c.id,name:c.name,kind:"refining",
       route:lang==="en"?`Buy: ${buyLabel} | Refine: ${c.city} | Sell: ${refineSell}`:`Comprar: ${buyLabel} | Refinar: ${c.city} | Vender: ${refineSell}`,
       shopping,outputPerCraft:c.outputPerCraft,daily,rrr:canFocus?prodFocus.rrr:prodNo.rrr,
       productionBonus:canFocus?prodFocus.total:prodNo.total,focusEfficiency,focusPerCraft,
       unitInvestment:invest,unitProfit:profit,unitInvestmentNoFocus:investNo,unitProfitNoFocus:profitNo,
       unitInvestmentFocus:investFocus,unitProfitFocus:profitFocus,roi,score,risk,focusMode:canFocus,dataAgeMin,
       reason:lang==="en"?`${roi.toFixed(1)}% return${daily?` • Daily +${daily}%`:""}${canFocus?` • ${focusEfficiency.toLocaleString("en-GB")} Focus Efficiency`:""}`:`${roi.toFixed(1)}% rentabilidade${daily?` • Daily +${daily}%`:""}${canFocus?` • ${focusEfficiency.toLocaleString("pt-BR")} Eficiência de Focus`:""}`
     });
   }
 }

 const enabledOpportunities=opportunities.filter(o=>(o.type==="FLIP"&&includeFlips)||(o.type==="CRAFT"&&includeCrafts)||(o.type==="REFINE"&&includeRefines));
 for(const o of enabledOpportunities){
   const freshness=Math.max(0,100-Math.min(100,(o.dataAgeMin??maxAge)/Math.max(1,maxAge)*100));
   const riskQuality=o.risk==="Baixo"?100:o.risk==="Médio"?62:25;
   const efficiency=Math.max(0,Math.min(100,(o.roi??0)/25*100));
   o.decisionScore=Math.round(Math.max(0,Math.min(100,o.score*.62+freshness*.16+riskQuality*.12+efficiency*.10)));
 }
 enabledOpportunities.sort((a,b)=>b.decisionScore-a.decisionScore||b.score-a.score||b.roi-a.roi);
 const capPer=capital*maxAlloc/100,plan:any[]=[];let remaining=capital,focusRemaining=focusAvailable;
 for(const o of enabledOpportunities){
   if(plan.length>=12)break;
   const budget=Math.min(capPer,remaining);
   if(o.type==="FLIP"){
     const qty=Math.floor(budget/o.unitInvestment);if(qty<1)continue;
     const investment=qty*o.unitInvestment,profit=qty*o.unitProfit;
     plan.push({...o,qty,investment,profit,focusUsed:0,focusedQty:0});
     remaining-=investment;continue;
   }
   let budgetLeft=budget,totalQty=0,investment=0,profit=0,focusedQty=0,focusUsed=0;
   if(o.focusPerCraft>0&&focusRemaining>=o.focusPerCraft){
     const maxByFocus=Math.floor(focusRemaining/o.focusPerCraft);
     const qf=Math.min(maxByFocus,Math.floor(budgetLeft/o.unitInvestmentFocus));
     if(qf>0){
       focusedQty=qf;totalQty+=qf;
       investment+=qf*o.unitInvestmentFocus;profit+=qf*o.unitProfitFocus;
       focusUsed=qf*o.focusPerCraft;focusRemaining-=focusUsed;budgetLeft-=qf*o.unitInvestmentFocus;
     }
   }
   const qu=Math.floor(budgetLeft/o.unitInvestmentNoFocus);
   if(qu>0){
     totalQty+=qu;investment+=qu*o.unitInvestmentNoFocus;profit+=qu*o.unitProfitNoFocus;
   }
   if(totalQty<1)continue;
   plan.push({...o,qty:totalQty,investment,profit,focusedQty,focusUsed});
   remaining-=investment;
 }
 const invested=capital-remaining,expectedProfit=plan.reduce((s,x)=>s+x.profit,0),flipInvestment=plan.filter(x=>x.type==="FLIP").reduce((s,x)=>s+x.investment,0),craftInvestment=plan.filter(x=>x.type==="CRAFT").reduce((s,x)=>s+x.investment,0),refineInvestment=plan.filter(x=>x.type==="REFINE").reduce((s,x)=>s+x.investment,0);
 const top=enabledOpportunities.slice(0,80).map(o=>({...o,qty:1,investment:o.unitInvestment,profit:o.unitProfit}));
 return NextResponse.json({opportunities:top,plan,summary:{capital,invested,reserve:remaining,expectedProfit,roi:invested?expectedProfit/invested*100:0,flipInvestment,craftInvestment,refineInvestment,focusUsed:focusAvailable-focusRemaining,focusRemaining},meta:{scannedFlips:enabledOpportunities.filter(x=>x.type==="FLIP").length,scannedCrafts:enabledOpportunities.filter(x=>x.type==="CRAFT").length,scannedRefines:enabledOpportunities.filter(x=>x.type==="REFINE").length,focusAvailable,enabledStrategies:{flips:includeFlips,crafts:includeCrafts,refines:includeRefines},dailyBonuses:dailyData.bonuses,dailyBonusAvailable:dailyData.available,focusNote:lang==="en"?"The plan shares the same Focus pool between crafting and refining and uses Focus Efficiency calculated from the Specializations profile.":"O plano compartilha o mesmo Focus entre crafting e refining e usa a Eficiência de Focus calculada a partir do perfil de Especializações."}});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erro no Silver Optimizer."},{status:500})}}
