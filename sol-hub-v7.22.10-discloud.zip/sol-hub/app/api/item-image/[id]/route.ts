import {NextRequest} from "next/server";

const safeId=(s:string)=>/^[A-Z0-9_@-]+$/i.test(s);

function fallbackSvg(_id:string,size:number){
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect x="1" y="1" width="${size-2}" height="${size-2}" rx="${Math.max(7,Math.round(size*.14))}" fill="#0d1422" stroke="#26344b"/>
  <circle cx="${size/2}" cy="${size/2}" r="${Math.max(6,size*.16)}" fill="#17233a" stroke="#3b4f72"/>
  <path d="M${size*.42} ${size*.5}h${size*.16}M${size*.5} ${size*.42}v${size*.16}" stroke="#7186ad" stroke-width="${Math.max(1,size*.025)}" stroke-linecap="round"/>
  </svg>`;
}

export async function GET(req:NextRequest,{params}:{params:Promise<{id:string}>}){
  const {id}=await params;
  const size=Math.min(160,Math.max(32,Number(req.nextUrl.searchParams.get("size")??80)));
  const quality=Math.min(5,Math.max(1,Number(req.nextUrl.searchParams.get("quality")??1)));
  const itemKey=req.nextUrl.searchParams.get("itemKey");
  if(itemKey!==null&&itemKey!==id)return new Response(fallbackSvg(id,size),{status:400,headers:{"content-type":"image/svg+xml","cache-control":"no-store"}});
  if(!safeId(id)) return new Response(fallbackSvg("ITEM",size),{headers:{"content-type":"image/svg+xml","cache-control":"public,max-age=3600"}});
  try{
    // Never substitute another item/tier when an icon cannot be rendered.
    // A missing icon is safer than showing an image that belongs to a different item.
    const upstream=`https://render.albiononline.com/v1/item/${encodeURIComponent(id)}.png?quality=${quality}&size=${size}`;
    const r=await fetch(upstream,{next:{revalidate:3600}});
    if(!r.ok)throw new Error("render unavailable");
    const ct=r.headers.get("content-type")||"";
    if(!ct.includes("image"))throw new Error("invalid render content type");
    const body=await r.arrayBuffer();
    if(body.byteLength<100)throw new Error("empty render");
    return new Response(body,{headers:{
      "content-type":ct||"image/png",
      "cache-control":"public,max-age=3600,s-maxage=3600"
    }});
  }catch{
    return new Response(fallbackSvg(id,size),{headers:{
      "content-type":"image/svg+xml",
      "cache-control":"public,max-age=900"
    }});
  }
}
