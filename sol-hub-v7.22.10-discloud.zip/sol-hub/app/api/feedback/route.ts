import {NextResponse} from "next/server";
import {APP_VERSION} from "../../../lib/appMeta";

export const runtime="nodejs";

type FeedbackType="bug"|"suggestion"|"calculation"|"ui"|"other";

const typeLabels:Record<FeedbackType,string>={
  bug:"🐛 Report de erro",
  suggestion:"💡 Sugestão",
  calculation:"📊 Dados / cálculo incorreto",
  ui:"🎨 Sugestão de interface",
  other:"💬 Outro"
};

const typeColors:Record<FeedbackType,number>={
  bug:0xED4245,
  suggestion:0xF1C40F,
  calculation:0x5865F2,
  ui:0x9B59B6,
  other:0x95A5A6
};

const MAX_FILES=3;
const MAX_FILE_SIZE=8*1024*1024;
const ALLOWED_TYPES=new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
  "application/pdf",
  "text/plain"
]);
const ALLOWED_EXTENSIONS=new Set(["png","jpg","jpeg","webp","gif","pdf","txt","log"]);

function clean(value:unknown,max=1000){
  return String(value??"").trim().slice(0,max);
}

function field(name:string,value:unknown,inline=false){
  const v=clean(value,1024);
  return v?{name,value:v,inline}:null;
}

function extension(name:string){
  const p=name.toLowerCase().split(".");
  return p.length>1?p.pop()??"":"";
}

function safeFilename(name:string,index:number){
  const cleaned=name
    .replace(/[^\w.\- ()[\]]+/g,"_")
    .slice(0,120)
    .trim();
  return cleaned||`attachment-${index+1}`;
}

export async function POST(req:Request){
  try{
    const form=await req.formData();

    // Honeypot: real users never see/fill this field.
    if(clean(form.get("website"),200))return NextResponse.json({ok:true});

    const type=clean(form.get("type"),30) as FeedbackType;
    const title=clean(form.get("title"),180);
    const description=clean(form.get("description"),3000);

    if(!typeLabels[type]){
      return NextResponse.json({error:"Tipo de feedback inválido."},{status:400});
    }
    if(title.length<4){
      return NextResponse.json({error:"Adiciona um título um pouco mais descritivo."},{status:400});
    }
    if(description.length<10){
      return NextResponse.json({error:"Descreve o feedback com um pouco mais de detalhe."},{status:400});
    }

    const rawFiles=form.getAll("attachments");
    const files=rawFiles.filter((entry):entry is File=>entry instanceof File&&entry.size>0);

    if(files.length>MAX_FILES){
      return NextResponse.json(
        {error:`Podes enviar no máximo ${MAX_FILES} anexos por report.`},
        {status:400}
      );
    }

    for(const file of files){
      const ext=extension(file.name);
      const typeAllowed=ALLOWED_TYPES.has(file.type)||ALLOWED_EXTENSIONS.has(ext);
      if(!typeAllowed){
        return NextResponse.json(
          {error:`O ficheiro "${clean(file.name,100)}" não é suportado. Usa PNG, JPG, WEBP, GIF, PDF, TXT ou LOG.`},
          {status:400}
        );
      }
      if(file.size>MAX_FILE_SIZE){
        return NextResponse.json(
          {error:`O ficheiro "${clean(file.name,100)}" ultrapassa o limite de 8 MB.`},
          {status:400}
        );
      }
    }

    const webhook=process.env.DISCORD_FEEDBACK_WEBHOOK_URL;
    if(!webhook){
      return NextResponse.json(
        {error:"O canal de feedback ainda não está configurado no servidor."},
        {status:503}
      );
    }

    const technical=clean(form.get("includeTechnical"),10)==="true";
    const fields=[
      field("Página afetada",form.get("affectedPage"),true),
      field("Item / referência",form.get("item"),true),
      field("Cidade",form.get("city"),true),
      field("O que esperava",form.get("expected")),
      field("O que aconteceu",form.get("actual")),
      field("Contacto",form.get("contact"),true),
    ].filter(Boolean);

    if(files.length){
      fields.push(field("Anexos",`${files.length} ficheiro${files.length===1?"":"s"} enviado${files.length===1?"":"s"}`,true));
    }

    if(technical){
      fields.push(
        field("Versão",APP_VERSION,true),
        field("Idioma",form.get("language"),true),
        field("Origem",form.get("sourcePage"),true),
        field("Browser",form.get("userAgent"))
      );
    }

    const payload={
      username:"NoTag Feedback",
      allowed_mentions:{parse:[]},
      embeds:[{
        title:`${typeLabels[type]} — ${title}`,
        description,
        color:typeColors[type],
        fields,
        footer:{text:`SOL HUB • V${APP_VERSION}`},
        timestamp:new Date().toISOString()
      }],
      attachments:files.map((file,index)=>({
        id:index,
        filename:safeFilename(file.name,index)
      }))
    };

    const discordForm=new FormData();
    discordForm.append("payload_json",JSON.stringify(payload));

    files.forEach((file,index)=>{
      discordForm.append(`files[${index}]`,file,safeFilename(file.name,index));
    });

    const response=await fetch(webhook,{
      method:"POST",
      body:discordForm,
      cache:"no-store"
    });

    if(!response.ok){
      const discordError=await response.text().catch(()=>"");
      console.error("Discord feedback webhook failed:",response.status,discordError.slice(0,500));
      return NextResponse.json(
        {error:"Não foi possível enviar o feedback para o Discord. Se anexaste ficheiros, confirma também o tamanho dos mesmos e tenta novamente."},
        {status:502}
      );
    }

    return NextResponse.json({ok:true,attachments:files.length});
  }catch(err){
    console.error("Feedback route error:",err);
    return NextResponse.json(
      {error:"Ocorreu um erro inesperado ao enviar o feedback."},
      {status:500}
    );
  }
}
