import {NextRequest,NextResponse} from "next/server";
import {loadMarketPrices,ageMinutes} from "../../../lib/albion";
import {getEuropeDailyBonuses,dailyBonusForItem} from "../../../lib/dailyBonus";
import {focusCostPerCraft,parseCraftingSpecProfile,profileRefiningFce} from "../../../lib/focus";
import {itemLanguage,buildLocalizedNameMap} from "../../../lib/localizedNames";
import {parseCraftResources} from "../../../lib/recipeResources";

export const runtime="nodejs";
export const maxDuration=30;

const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const BUY_CITIES=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const SELL_CITIES=[...BUY_CITIES,"Black Market"];
const DEFS=[
  {key:"metal",suffix:"METALBAR",city:"Thetford",label:"Metal Bars"},
  {key:"wood",suffix:"PLANKS",city:"Fort Sterling",label:"Planks"},
  {key:"leather",suffix:"LEATHER",city:"Martlock",label:"Leather"},
  {key:"cloth",suffix:"CLOTH",city:"Lymhurst",label:"Cloth"},
  {key:"stone",suffix:"STONEBLOCK",city:"Bridgewatch",label:"Stone Blocks"},
] as const;
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];
function bonus(specialty:boolean,focus:boolean,daily:number){const total=18+(specialty?40:0)+(focus?59:0)+Math.max(0,daily||0);return {total,rrr:total/(100+total)}}
function rankRisk(r:string){return r==="Baixo"?1:r==="Médio"?2:3}

export async function GET(req:NextRequest){
 try{
  const p=req.nextUrl.searchParams;
  const lang=itemLanguage(p.get("lang"));
  const tierMin=Math.max(4,Math.min(8,Number(p.get("tierMin")??4)));
  const tierMax=Math.max(tierMin,Math.min(8,Number(p.get("tierMax")??8)));
  const family=p.get("family")??"all";
  const sellCity=p.get("sellCity")??"Thetford";
  const minRoi=Number(p.get("minRoi")??5);
  const maxAgeH=Math.max(1,Number(p.get("maxAgeHours")??8));
  const riskMax=p.get("risk")??"Alto";
  const premium=p.get("premium")!=="false";
  const stationFeeRate=Math.max(0,Number(p.get("stationFee")??0));
  const focusAvailable=Math.min(30000,Math.max(0,Number(p.get("focus")??0)));
  const specProfile=parseCraftingSpecProfile(p.get("specProfile"));
  if(!SELL_CITIES.includes(sellCity))throw Error("Cidade de venda inválida.");

  const [raw,formatted,dailyData]=await Promise.all([
    fetch(FULL,{next:{revalidate:86400}}).then(r=>r.json()),
    fetch(NAMES,{next:{revalidate:86400}}).then(r=>r.json()),
    getEuropeDailyBonuses()
  ]);
  const names=buildLocalizedNameMap(formatted,lang);
  const all=Object.values(raw?.items??{}).flatMap((v:any)=>arr(v));
  const candidates:any[]=[];

  for(const def of DEFS){
   if(family!=="all"&&family!==def.key)continue;
   for(let tier=tierMin;tier<=tierMax;tier++){
    const baseId=`T${tier}_${def.suffix}`;
    const item=all.find((x:any)=>String(x?.["@uniquename"]??"")===baseId);
    if(!item)continue;
    const variants:[number,any][]=[[0,item]];
    if(def.key!=="stone"){
      for(const ev of arr(item?.enchantments?.enchantment)){
        const lv=Number(ev?.["@enchantmentlevel"]??0);
        if(lv>=1&&lv<=3)variants.push([lv,ev]);
      }
    }
    for(const [ench,node] of variants){
      const reqRaw=node===item?item?.craftingrequirements:node?.craftingrequirements;
      const cr=Array.isArray(reqRaw)?reqRaw[0]:reqRaw;
      const mats=parseCraftResources(cr?.craftresource);
      if(!mats.length)continue;
      const id=ench?`${baseId}_LEVEL${ench}@${ench}`:baseId;
      candidates.push({id,baseId,name:names.get(id)??names.get(baseId)??id,family:def.key,specialtyCity:def.city,mats,
        focusBase:Number(cr?.["@craftingfocus"]??0)||0,itemValue:Number(node?.["@itemvalue"]??item?.["@itemvalue"]??0),
        output:Math.max(1,Number(cr?.["@amountcrafted"]??node?.["@amountcrafted"]??item?.["@amountcrafted"]??1)),
        tier,enchant:ench});
    }
   }
  }

  const matIds=[...new Set(candidates.flatMap(c=>c.mats.map((m:any)=>m.id)))];
  const outIds=[...new Set(candidates.map(c=>c.id))];
  const [mp,sp]=await Promise.all([loadMarketPrices(matIds,BUY_CITIES),loadMarketPrices(outIds,[sellCity])]);

  const cheapest=new Map<string,{price:number;city:string;age:number}>();
  for(const x of mp){
    if(x.sell_price_min<=0)continue;
    const age=ageMinutes(x.sell_price_min_date),cur=cheapest.get(x.item_id);
    if(!cur||x.sell_price_min<cur.price)cheapest.set(x.item_id,{price:x.sell_price_min,city:x.city,age});
  }
  const sale=new Map<string,{price:number;age:number}>();
  for(const x of sp){
    const price=sellCity==="Black Market"?x.buy_price_max:x.sell_price_min;
    const date=sellCity==="Black Market"?x.buy_price_max_date:x.sell_price_min_date;
    if(price<=0)continue;
    const cur=sale.get(x.item_id);
    if(!cur||price>cur.price)sale.set(x.item_id,{price,age:ageMinutes(date)});
  }

  const tax=premium?.04:.08,setup=sellCity==="Black Market"?0:.025,rows:any[]=[];
  for(const c of candidates){
    let gross=0,missing=false,maxMatAge=0;const shopping:Record<string,any[]>={};
    for(const m of c.mats){
      const b=cheapest.get(m.id);if(!b){missing=true;break}
      maxMatAge=Math.max(maxMatAge,b.age);
      gross+=m.count*b.price;
      (shopping[b.city]??=[]).push({id:m.id,name:names.get(m.id)??m.id,qty:m.count,unitPrice:b.price,ageMin:b.age});
    }
    if(missing)continue;
    const out=sale.get(c.id);if(!out)continue;
    const daily=dailyBonusForItem(c.id,`resources_${c.family}`,c.family,dailyData.bonuses);
    const eff=profileRefiningFce(c.id,specProfile),focusPer=focusCostPerCraft(c.focusBase,eff);
    const nf=bonus(true,false,daily),wf=bonus(true,true,daily);
    const returned=(rrr:number)=>c.mats.reduce((sum:number,m:any)=>sum+(m.ret?(cheapest.get(m.id)?.price??0)*m.count*rrr:0),0);
    const station=c.itemValue*c.output*0.1125*stationFeeRate/100;
    const invNo=gross-returned(nf.rrr)+station,invFocus=gross-returned(wf.rrr)+station;
    const revenue=out.price*c.output,fees=revenue*(tax+setup);
    const profitNo=revenue-fees-invNo,profitFocus=revenue-fees-invFocus;
    const useFocus=focusPer>0&&focusAvailable>=focusPer;
    const investment=useFocus?invFocus:invNo,profit=useFocus?profitFocus:profitNo;
    if(investment<=0)continue;
    const roi=profit/investment*100;if(profit<=0||roi<minRoi)continue;
    const age=Math.max(maxMatAge,out.age);
    const risk=age<=60&&roi>=15?"Baixo":age<=maxAgeH*60&&roi>=8?"Médio":"Alto";
    if(rankRisk(risk)>rankRisk(riskMax))continue;
    const freshness=Math.max(0,100-Math.min(100,age/(maxAgeH*60)*100));
    const score=Math.round(Math.max(0,Math.min(100,roi*2.4+freshness*.35+(daily?8:0))));
    rows.push({itemId:c.id,name:c.name,family:c.family,tier:c.tier,enchant:c.enchant,specialtyCity:c.specialtyCity,sellCity,
      shopping,daily,focusEfficiency:eff,focusPerRefine:focusPer,useFocus,rrr:useFocus?wf.rrr:nf.rrr,
      investment,profit,roi,risk,score,sellPrice:out.price,dataAgeMin:Math.round(age),output:c.output,
      investmentNoFocus:invNo,profitNoFocus:profitNo,roiNoFocus:invNo?profitNo/invNo*100:0,
      investmentFocus:invFocus,profitFocus:profitFocus,roiFocus:invFocus?profitFocus/invFocus*100:0});
  }
  rows.sort((a,b)=>b.score-a.score||b.roi-a.roi);
  return NextResponse.json({rows:rows.slice(0,100),meta:{scanned:candidates.length,approved:rows.length,dailyBonuses:dailyData.bonuses}});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erro no scanner de refino."},{status:500})}
}
