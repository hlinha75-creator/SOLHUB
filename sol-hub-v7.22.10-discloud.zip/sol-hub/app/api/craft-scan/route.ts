import {parseFocusProfile,parseCraftingSpecProfile,profileFce,focusCostPerCraft} from "../../../lib/focus";import {craftKind,craftCategory,craftCityFor,isSupportedCraftId} from "../../../lib/craftCatalog";import {craftBonusBreakdown} from "../../../lib/albionBonuses";import {getEuropeDailyBonuses,dailyBonusForItem} from "../../../lib/dailyBonus";import {itemLanguage,localizedItemName} from "../../../lib/localizedNames";export const runtime = "nodejs";
export const maxDuration = 30;
import {NextRequest,NextResponse} from "next/server";
import {loadMarketPrices,ageMinutes} from "../../../lib/albion";
const CITIES=["Bridgewatch","Martlock","Lymhurst","Thetford","Fort Sterling","Caerleon","Brecilien"];
const FULL="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/items.json";
const NAMES="https://raw.githubusercontent.com/ao-data/ao-bin-dumps/master/formatted/items.json";
const arr=(x:any)=>!x?[]:Array.isArray(x)?x:[x];
const SUB:Record<string,string>={sword:"Lymhurst",bow:"Lymhurst",arcanestaff:"Lymhurst",axe:"Martlock",quarterstaff:"Martlock",froststaff:"Martlock",mace:"Thetford",firestaff:"Thetford",naturestaff:"Thetford",hammer:"Fort Sterling",spear:"Fort Sterling",holystaff:"Fort Sterling",crossbow:"Bridgewatch",dagger:"Bridgewatch",cursestaff:"Bridgewatch",knuckles:"Caerleon",shapeshifterstaff:"Caerleon",cloth_armor:"Fort Sterling",plate_helmet:"Fort Sterling",leather_helmet:"Lymhurst",leather_shoes:"Lymhurst",plate_armor:"Bridgewatch",cloth_shoes:"Bridgewatch",leather_armor:"Thetford",cloth_helmet:"Thetford",plate_shoes:"Martlock"};
const CAT:Record<string,string>={offhands:"Martlock",bags:"Brecilien",capes:"Brecilien",gathering:"Caerleon"};
function mid(r:any){const id=r?.["@uniquename"]??"",e=r?.["@enchantmentlevel"];return e&&e!=="0"&&!id.includes("@")?`${id}@${e}`:id}
export async function GET(req:NextRequest){try{
 const p=req.nextUrl.searchParams,lang=itemLanguage(p.get("lang")),tmin=Number(p.get("tierMin")??3),tmax=Number(p.get("tierMax")??8),sellCity=p.get("sellCity")??"Black Market",minRoi=Number(p.get("minRoi")??10),focusAvailable=Math.min(30000,Math.max(0,Number(p.get("focus")??0))),focusProfile=parseFocusProfile(p.get("focusProfile")),specProfile=parseCraftingSpecProfile(p.get("specProfile")),premium=p.get("premium")!=="false",stationFeeRate=Math.max(0,Number(p.get("stationFee")??p.get("stationPct")??0)),craftType=p.get("craftType")??"all";
 const [data,formatted]=await Promise.all([fetch(FULL,{next:{revalidate:86400}}).then(r=>r.json()),fetch(NAMES,{next:{revalidate:86400}}).then(r=>r.json())]);
 const names=new Map<string,string>();for(const x of formatted)if(x.UniqueName)names.set(x.UniqueName,localizedItemName(x,lang)||x.UniqueName);
 const candidates:any[]=[];
 const allItems=Object.values(data?.items??{}).flatMap((v:any)=>arr(v));
 for(const it of allItems){
  const id=it?.["@uniquename"]??"",kind=craftKind(id);
  if(!kind||!isSupportedCraftId(id,tmin,tmax))continue;
  const shopcategory=it?.["@shopcategory"]??"",subcategory=it?.["@shopsubcategory1"]??"",category=craftCategory(id,shopcategory);
  if(!category)continue;
  if(craftType!=="all"&&category!==craftType)continue;
  let req=Array.isArray(it.craftingrequirements)?it.craftingrequirements[0]:it.craftingrequirements;
  const mats=arr(req?.craftresource).map((r:any)=>({id:mid(r),count:Number(r?.["@count"]??0),ret:r?.["@maxreturnamount"]!=="0"})).filter((m:any)=>m.id&&m.count);
  if(!mats.length)continue;
  candidates.push({
    id,name:names.get(id)??id,kind,category,
    city:craftCityFor(id,shopcategory,subcategory),
    mats,focusBase:Number(req?.["@craftingfocus"]??0)||0,itemValue:Number(it?.["@itemvalue"]??0),
    outputPerCraft:Math.max(1,Number(req?.["@amountcrafted"]??it?.["@amountcrafted"]??1)),
    shopcategory,subcategory
  });
 }
 const limited=[
  ...candidates.filter(x=>x.kind==="equipment").slice(0,70),
  ...candidates.filter(x=>x.kind==="potion").slice(0,50),
  ...candidates.filter(x=>x.kind==="food").slice(0,80)
 ];
 candidates.length=0;candidates.push(...limited);
 const matIds=[...new Set(candidates.flatMap(x=>x.mats.map((m:any)=>m.id)))];
 const itemIds=candidates.map(x=>x.id);
 const [mp,sp]=await Promise.all([loadMarketPrices(matIds,CITIES),loadMarketPrices(itemIds,[sellCity])]);
 const cheapest=new Map<string,{price:number;age:number;city:string}>();for(const x of mp)if(x.sell_price_min>0&&(!cheapest.get(x.item_id)||x.sell_price_min<(cheapest.get(x.item_id)?.price??Infinity)))cheapest.set(x.item_id,{price:x.sell_price_min,age:ageMinutes(x.sell_price_min_date),city:x.city});
 const sale=new Map<string,{price:number;age:number}>();for(const x of sp){const v=sellCity==="Black Market"?x.buy_price_max:x.sell_price_min,d=sellCity==="Black Market"?x.buy_price_max_date:x.sell_price_min_date,cur=sale.get(x.item_id);if(v>0&&(!cur||v>cur.price))sale.set(x.item_id,{price:v,age:ageMinutes(d)})}
 const dailyData=await getEuropeDailyBonuses();const rows:any[]=[];
 for(const c of candidates){const daily=dailyBonusForItem(c.id,c.shopcategory,c.subcategory,dailyData.bonuses),focusEfficiency=profileFce(c.id,specProfile,c.subcategory)||(focusProfile[c.id]??0),focusPerCraft=focusCostPerCraft(c.focusBase,focusEfficiency),useFocus=focusPerCraft>0&&focusAvailable>=focusPerCraft,production=craftBonusBreakdown({hasSpecialty:true,focus:useFocus,dailyBonus:daily}),rrr=production.rrr;let gross=0,ret=0,missing=false;let maxMatAge=0;const shopping:Record<string,any[]>={};for(const m of c.mats){const b=cheapest.get(m.id);if(!b){missing=true;break}const u=b.price;maxMatAge=Math.max(maxMatAge,b.age);gross+=m.count*u;if(m.ret)ret+=m.count*u*rrr;(shopping[b.city]??=[]).push({id:m.id,name:names.get(m.id)??m.id,qty:m.count,unitPrice:u,ageMin:Math.round(b.age),returnable:m.ret})}if(missing)continue;const station=c.itemValue*c.outputPerCraft*0.1125*stationFeeRate/100,total=gross-ret+station,sellData=sale.get(c.id),sellPrice=sellData?.price??0;if(!sellPrice)continue;const dataAgeMin=Math.round(Math.max(maxMatAge,sellData?.age??0));const revenue=sellPrice*c.outputPerCraft,marketFees=revenue*((premium?0.04:0.08)+(sellCity==="Black Market"?0:0.025)),profit=revenue-marketFees-total,roi=total?profit/total*100:0;if(roi<minRoi)continue;const score=Math.max(0,Math.min(100,Math.round(Math.min(100,roi*2)*.65+Math.min(100,Math.max(0,profit)/500)*.35)));rows.push({itemId:c.id,name:c.name,kind:c.kind,category:c.category,outputPerCraft:c.outputPerCraft,craftCity:c.city,sellCity,buyMaterials:total,sellPrice,profit,roi,rrr,daily,productionBonus:production.total,score,materials:c.mats.length,focus:useFocus,focusAvailable,focusEfficiency,focusPerCraft,dataAgeMin,shopping,grossMaterials:gross,returnedValue:ret,stationFee:station,revenue,marketFees,sellAgeMin:Math.round(sellData?.age??0)})}
 rows.sort((a,b)=>b.score-a.score||b.profit-a.profit);
 return NextResponse.json({rows:rows.slice(0,50),scanned:candidates.length,dailyBonuses:dailyData.bonuses,dailyBonusAvailable:dailyData.available});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Erro no crafting scanner."},{status:500})}}
