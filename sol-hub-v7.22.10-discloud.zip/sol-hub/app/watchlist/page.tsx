"use client";
import {itemImageUrl} from "../../lib/itemImage";
import {useEffect,useMemo,useState} from "react";
import AppSidebar from "../components/AppSidebar";
import LanguageSelector from "../components/LanguageSelector";
import AddToPortfolioButton from "../components/AddToPortfolioButton";
import Link from "next/link";
import {loadAlerts} from "../../lib/alertsClient";
import {ageText,dataHealthLabel,dataHealthLevel,dataHealthSummary} from "../../lib/dataHealth";
import {itemMatchesSearch} from "../../lib/itemSearch";
import {currentSiteLanguage} from "../../lib/languageClient";
import {useSolHubSettings} from "../../lib/settingsClient";
import {conditionLabel,intelligenceBand,watchlistChangeLabel,type IntelligenceCondition,type IntelligenceComponents} from "../../lib/solIntelligence";
import {marketRecommendation} from "../../lib/solRecommendations";
import {WATCHLIST_EVENT,loadWatchlist,removeWatchlist,type WatchlistEntry,type WatchlistType,type WatchlistSource} from "../../lib/watchlistClient";

const fmt=new Intl.NumberFormat("pt-PT"),money=(n:number|null|undefined)=>n==null?"—":fmt.format(Math.round(n||0));
type Quote={buyPrice?:number|null;sellPrice?:number|null;buyAgeMin?:number|null;sellAgeMin?:number|null;currentProfit?:number|null;currentRoi?:number|null;currentIntelligenceScore?:number|null};
type MarketDetail={itemId:string;itemName:string;quality:number;buyCity:string;sellCity:string;buyPrice:number;sellPrice:number;fees:number;profit:number;roi:number;buyAgeMin:number;sellAgeMin:number;score:number;recommendedQty:number;recommendedInvestment:number;recommendedProfit:number;avgDailyVolume:number;historyAvgPrice:number;priceDeviationPct:number;volatilityPct:number;liquidity:"Alta"|"Média"|"Baixa"|"Sem dados";buyHistoryAvgPrice:number;entryAdvantagePct:number;trendPct:number;intelligenceScore:number;intelligenceComponents:IntelligenceComponents;marketCondition:IntelligenceCondition;risk:"Baixo"|"Médio"|"Alto";history:{item_count:number;avg_price:number;timestamp:string}[]};

export default function Watchlist(){
 const {settings}=useSolHubSettings();
 const [rows,setRows]=useState<WatchlistEntry[]>([]);
 const [quotes,setQuotes]=useState<Record<string,Quote>>({});
 const [tab,setTab]=useState<"ALL"|WatchlistType>("ALL");
 const [source,setSource]=useState<"ALL"|WatchlistSource>("ALL");
 const [search,setSearch]=useState("");
 const [sort,setSort]=useState<"recent"|"roi"|"profit"|"name">("recent");
 const [loading,setLoading]=useState(false),[err,setErr]=useState("");
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 const [selected,setSelected]=useState<WatchlistEntry|null>(null);
 const [marketDetail,setMarketDetail]=useState<MarketDetail|null>(null);
 const [detailLoading,setDetailLoading]=useState(false),[detailError,setDetailError]=useState("");

 useEffect(()=>setLang(currentSiteLanguage()),[]);
 useEffect(()=>{
  const sync=()=>setRows(loadWatchlist());
  sync();window.addEventListener(WATCHLIST_EVENT,sync);window.addEventListener("storage",sync);
  return()=>{window.removeEventListener(WATCHLIST_EVENT,sync);window.removeEventListener("storage",sync)};
 },[]);

 async function refresh(){
  if(!rows.length)return;
  setLoading(true);setErr("");
  try{
   const r=await fetch("/api/watchlist/quotes",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({entries:rows,premium:settings.premium,saleMode:settings.saleMode})});
   const j=await r.json();if(!r.ok)throw Error(j.error??(lang==="en"?"Refresh failed.":"Falha ao atualizar."));
   setQuotes(j.quotes??{});
  }catch(e){setErr(e instanceof Error?e.message:(lang==="en"?"Unexpected error.":"Erro inesperado."))}finally{setLoading(false)}
 }

 useEffect(()=>{if(rows.length)refresh();else setQuotes({})},[rows.length,settings.premium,settings.saleMode]);

 const visible=useMemo(()=>{
  let x=rows.filter(r=>(tab==="ALL"||r.type===tab)&&(source==="ALL"||(r.source??"LEGACY")===source)&&itemMatchesSearch(r.itemId,r.name,search));
  return [...x].sort((a,b)=>sort==="roi"?b.roi-a.roi:sort==="profit"?b.profit-a.profit:sort==="name"?a.name.localeCompare(b.name):b.createdAt.localeCompare(a.createdAt));
 },[rows,tab,source,search,sort]);

 const liveAges=rows.map(x=>{const q=quotes[x.id];return q?Math.max(q.buyAgeMin??0,q.sellAgeMin??0):x.dataAgeMin}).filter(x=>x!=null);
 const health=dataHealthSummary(liveAges);
 const counts={FLIP:rows.filter(x=>x.type==="FLIP").length,CRAFT:rows.filter(x=>x.type==="CRAFT").length,REFINE:rows.filter(x=>x.type==="REFINE").length};
 async function openDetail(x:WatchlistEntry){
  setSelected(x);setMarketDetail(null);setDetailError("");
  if(x.type!=="FLIP")return;
  const buy=x.buyCity??x.route.split(" → ")[0],sell=x.sellCity??x.route.split(" → ")[1];
  if(!buy||!sell)return;
  setDetailLoading(true);
  try{const q=new URLSearchParams({itemId:x.itemId,buyCity:buy,sellCity:sell,category:"all",tiers:"4,5,6,7,8",enchants:"0,1,2,3",maxAgeHours:"48",minRoi:"0",minProfit:"0",capital:String(Math.max(500000,x.investment*5)),premium:"true",maxAllocationPct:"30",maxDailyVolumePct:"25",saleMode:"sell_order",lang});const r=await fetch(`/api/flips?${q}`),j=await r.json();if(!r.ok)throw Error(j.error??(lang==="en"?"Could not load opportunity detail.":"Não foi possível carregar os detalhes da oportunidade."));const exact=(j.flips??[]).find((f:MarketDetail)=>f.itemId===x.itemId&&f.buyCity===buy&&f.sellCity===sell&&f.quality===(x.quality??f.quality));if(exact)setMarketDetail(exact);else setDetailError(lang==="en"?"This route is no longer available under the same conditions.":"Esta rota já não está disponível nas mesmas condições.");}catch(e){setDetailError(e instanceof Error?e.message:(lang==="en"?"Unexpected error.":"Erro inesperado."))}finally{setDetailLoading(false)}
 }

 const ui=lang==="en"?{
  subtitle:"Save opportunities before investing, follow current market prices and reopen the full opportunity detail.",total:"Saved total",market:"Market",craft:"Craft",refine:"Refine",all:"All",
  quotesLive:"Quotes refreshed this session",savedAge:"Showing data age saved when favorited",search:"Search: Bag T6.1, Cleric Robe…",recent:"Most recent",roi:"Highest return",profit:"Highest profit",name:"Name A–Z",refresh:"↻ Refresh prices",refreshing:"Refreshing…",
  watched:"⭐ Watched opportunities",snapshot:"Return and profit are the scanner snapshot; Current price is refreshed directly from the market.",hint:"Use View opportunity to inspect the full detail before investing.",engine:"Engine",item:"Item",route:"Route",investment:"Investment",profitLabel:"Profit",return:"Return",current:"Current price",intel:"SOL Intelligence",data:"Data",actions:"Actions",buy:"Buy",sell:"Sell",view:"View opportunity",source:"Source",allSources:"All sources",marketScanner:"Market Scanner",solOptimizer:"SOL Optimizer",dashboard:"Dashboard",craftScanner:"Craft Scanner",refineScanner:"Refine Scanner",legacy:"Legacy",none:"No favorites match the filters.",empty:"You are not watching any opportunities yet. Use the ⭐ star in scanners to add items."
 }:{
  subtitle:"Guarde oportunidades antes de investir, acompanhe os preços atuais e reabra os detalhes completos da oportunidade.",total:"Total guardados",market:"Mercado",craft:"Craft",refine:"Refino",all:"Todos",
  quotesLive:"Cotações atualizadas nesta sessão",savedAge:"Exibindo a idade dos dados guardada no momento do favorito",search:"Pesquisar: Bag T6.1, Cleric Robe…",recent:"Mais recentes",roi:"Maior rentabilidade",profit:"Maior lucro",name:"Nome A–Z",refresh:"↻ Atualizar preços",refreshing:"Atualizando…",
  watched:"⭐ Oportunidades em observação",snapshot:"Rentabilidade e lucro são o snapshot guardado pelo scanner; o Preço atual é atualizado diretamente do mercado.",hint:"Use Ver oportunidade para consultar os detalhes completos antes de investir.",engine:"Motor",item:"Item",route:"Rota",investment:"Investimento",profitLabel:"Lucro",return:"Rentabilidade",current:"Preço atual",intel:"SOL Intelligence",data:"Dados",actions:"Ações",buy:"Compra",sell:"Venda",view:"Ver oportunidade",source:"Origem",allSources:"Todas as origens",marketScanner:"Market Scanner",solOptimizer:"SOL Optimizer",dashboard:"Dashboard",craftScanner:"Craft Scanner",refineScanner:"Refine Scanner",legacy:"Legado",none:"Nenhum favorito corresponde aos filtros.",empty:"Você ainda não está observando nenhuma oportunidade. Use a estrela ⭐ nos scanners para adicionar itens."
 };
 const sourceLabel=(x:WatchlistEntry)=>{
  const v=x.source??"LEGACY";
  return v==="MARKET_SCANNER"?ui.marketScanner:v==="SOL_OPTIMIZER"?ui.solOptimizer:v==="DASHBOARD"?ui.dashboard:v==="CRAFT_SCANNER"?ui.craftScanner:v==="REFINE_SCANNER"?ui.refineScanner:ui.legacy;
 };
 return <main className="shell"><AppSidebar/>
  <header className="hero"><div><div className="eyebrow">SOL HUB • INTELLIGENCE</div><h1>Market <span>Watchlist</span></h1><p>{ui.subtitle}</p></div><div className="headerTools"><LanguageSelector/></div></header>

  <section className="watchlistStats">
   <div className="metricCard"><span>{ui.total}</span><strong>{rows.length}</strong></div>
   <div className="metricCard"><span>{ui.market}</span><strong>{counts.FLIP}</strong></div>
   <div className="metricCard"><span>{ui.craft}</span><strong>{counts.CRAFT}</strong></div>
   <div className="metricCard"><span>{ui.refine}</span><strong>{counts.REFINE}</strong></div>
  </section>

  {rows.length>0&&<section className="dataHealthBar"><div><span className="dataHealthTitle">📡 {lang==="en"?"Watchlist Data Health":"Saúde dos Dados da Watchlist"}</span><strong>{health.healthyPct}% {lang==="en"?"Fresh/Recent":"Atual/Recente"}</strong><small>{quotes&&Object.keys(quotes).length?ui.quotesLive:ui.savedAge}</small></div><div className="dataHealthLegend"><span className="freshNow">{lang==="en"?"Fresh":"Atual"} {health.counts.freshNow}</span><span className="freshOk">{lang==="en"?"Recent":"Recente"} {health.counts.freshOk}</span><span className="freshAging">{lang==="en"?"Aging":"Envelhecendo"} {health.counts.freshAging}</span><span className="freshStale">{lang==="en"?"Stale":"Desatualizado"} {health.counts.freshStale}</span></div></section>}

  {rows.some(x=>x.type==="FLIP"&&x.intelligenceScore!=null)&&<section className="watchIntelBanner"><div><span>☀️ SOL WATCHLIST INTELLIGENCE</span><strong>{lang==="en"?"Saved opportunity vs. current market":"Oportunidade guardada vs. mercado atual"}</strong></div><p>{lang==="en"?"The current score updates price and freshness while preserving the historical context captured when you saved the opportunity. Use it as a change signal, not an execution guarantee.":"O score atual atualiza preço e frescura dos dados, mantendo o contexto histórico capturado quando guardou a oportunidade. Use-o como sinal de mudança, não como garantia de execução."}</p></section>}

  <section className="panel watchlistToolbar">
   <div className="watchlistTabs">
    {(["ALL","FLIP","CRAFT","REFINE"] as const).map(x=><button key={x} className={tab===x?"active":""} onClick={()=>setTab(x)}>{x==="ALL"?ui.all:x==="FLIP"?ui.market:x==="CRAFT"?ui.craft:ui.refine}</button>)}
   </div>
   <div className="watchlistControls">
    <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={ui.search}/>
    <select value={source} onChange={e=>setSource(e.target.value as "ALL"|WatchlistSource)}><option value="ALL">{ui.allSources}</option><option value="MARKET_SCANNER">{ui.marketScanner}</option><option value="SOL_OPTIMIZER">{ui.solOptimizer}</option><option value="DASHBOARD">{ui.dashboard}</option><option value="CRAFT_SCANNER">{ui.craftScanner}</option><option value="REFINE_SCANNER">{ui.refineScanner}</option><option value="LEGACY">{ui.legacy}</option></select>
    <select value={sort} onChange={e=>setSort(e.target.value as any)}><option value="recent">{ui.recent}</option><option value="roi">{ui.roi}</option><option value="profit">{ui.profit}</option><option value="name">{ui.name}</option></select>
    <button className="scan watchlistRefresh" disabled={loading||!rows.length} onClick={refresh}>{loading?ui.refreshing:ui.refresh}</button>
   </div>
  </section>
  {err&&<div className="error">{err}</div>}

  <section className="results">
   <div className="resultsHead"><div><h2>{ui.watched}</h2><p>{ui.snapshot}</p></div><small>{ui.hint}</small></div>
   <div className="tableWrap financeTableWrap"><table className="financeTable"><thead><tr><th>{ui.source}</th><th>{ui.engine}</th><th>{ui.item}</th><th>{ui.route}</th><th>{ui.investment}</th><th>{ui.profitLabel}</th><th>{ui.return}</th><th>{ui.current}</th><th>{ui.intel}</th><th>{ui.data}</th><th>{ui.actions}</th></tr></thead><tbody>
    {visible.map(x=>{const q=quotes[x.id];const age=q?Math.max(q.buyAgeMin??0,q.sellAgeMin??0):x.dataAgeMin;return <tr key={x.id}>
      <td><span className={`watchSource ${(x.source??"LEGACY").toLowerCase()}`}>{sourceLabel(x)}</span></td>
      <td><span className={`engine ${x.type.toLowerCase()}`}>{x.type==="FLIP"?"↔ MARKET":x.type==="CRAFT"?"⚒ CRAFT":"♻ REFINE"}</span></td>
      <td><div className="item"><img src={itemImageUrl(x.itemId,{quality:x.quality??1,size:64})} alt=""/><div><strong>{x.name}</strong><span>{x.itemId}</span></div></div></td>
      <td>{x.route}</td><td>{money(x.investment)}</td><td className={x.profit>=0?"profit":"loss"}>{x.profit>=0?"+":""}{money(x.profit)}</td><td><b>{x.roi.toFixed(1)}%</b></td>
      <td>{x.type==="FLIP"?<div className="watchQuote"><span>{ui.buy} {money(q?.buyPrice??x.buyPrice)}</span><span>{ui.sell} {money(q?.sellPrice??x.sellPrice)}</span></div>:<div className="watchQuote"><span>{ui.sell} {money(q?.sellPrice??x.sellPrice)}</span></div>}</td>
      <td>{x.type==="FLIP"&&x.intelligenceScore!=null?<div className="watchIntel"><div><span>{lang==="en"?"Added":"Adicionado"}</span><b>{x.intelligenceScore}</b></div><span>→</span><div><span>{lang==="en"?"Now":"Agora"}</span><b>{q?.currentIntelligenceScore??"—"}</b></div>{q?.currentIntelligenceScore!=null&&<small className={(q.currentIntelligenceScore-x.intelligenceScore)>=8?"profit":(q.currentIntelligenceScore-x.intelligenceScore)<=-8?"loss":""}>{watchlistChangeLabel(x.intelligenceScore,q.currentIntelligenceScore,lang)}</small>}</div>:<span className="optimizerNotPlanned">—</span>}</td>
      <td>{age!=null?<span className={`dataFreshness ${dataHealthLevel(age)}`} title={dataHealthLabel(age,lang)}><i/>{ageText(age)}</span>:<span className="dataFreshness freshStale"><i/>—</span>}</td>
      <td><div className="watchlistActions"><Link className={loadAlerts().some(a=>a.watchlistId===x.id)?"watchAlert active":"watchAlert"} href={`/alerts?watchlistId=${encodeURIComponent(x.id)}`}>🔔</Link><button className="watchOpenDetail" onClick={()=>openDetail(x)}>{ui.view}</button><button className="danger" onClick={()=>setRows(removeWatchlist(x.id))}>×</button></div></td>
    </tr>})}
    {!visible.length&&<tr><td colSpan={11} className="empty">{rows.length?ui.none:ui.empty}</td></tr>}
   </tbody></table></div>
  </section>
  {selected&&<div className="overlay" onClick={()=>setSelected(null)}><aside className="drawer opportunityDrawer watchOpportunityDrawer" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}>×</button>
   <div className="detailHead"><img src={itemImageUrl(selected.itemId,{quality:selected.quality??1,size:128})} alt=""/><div><div className="eyebrow">{lang==="en"?"OPPORTUNITY DETAIL":"DETALHES DA OPORTUNIDADE"}</div><h2>{selected.name}</h2><p>{selected.route}</p></div></div>
   {selected.type==="FLIP"?(detailLoading?<div className="optimizerDetailLoading">{lang==="en"?"Loading current market detail…":"Carregando detalhes atuais do mercado…"}</div>:marketDetail?(()=>{const rec=marketRecommendation({roi:marketDetail.roi,profit:marketDetail.profit,risk:marketDetail.risk,liquidity:marketDetail.liquidity,volatilityPct:marketDetail.volatilityPct,priceDeviationPct:marketDetail.priceDeviationPct,dataAgeMin:Math.max(marketDetail.buyAgeMin,marketDetail.sellAgeMin),recommendedQty:marketDetail.recommendedQty},lang);return <><div className="detailGrid"><div><span>{lang==="en"?"Buy":"Compra"}</span><strong>{money(marketDetail.buyPrice)}</strong></div><div><span>{lang==="en"?"Sell":"Venda"}</span><strong>{money(marketDetail.sellPrice)}</strong></div><div><span>{lang==="en"?"Fees":"Taxas"}</span><strong>{money(marketDetail.fees)}</strong></div><div><span>{lang==="en"?"Profit / unit":"Lucro / un."}</span><strong className="profit">+{money(marketDetail.profit)}</strong></div><div><span>{lang==="en"?"Return":"Rentabilidade"}</span><strong>{marketDetail.roi.toFixed(1)}%</strong></div><div><span>Score</span><strong>{marketDetail.score}/100</strong></div></div><section className="solIntelScoreCard compactIntel"><div className="solIntelScoreHead"><div><span>☀️ SOL SCORE 2.0</span><strong>{marketDetail.intelligenceScore}/100</strong></div><b>{intelligenceBand(marketDetail.intelligenceScore,lang)}</b></div><div className="solEntryQuality"><div><span>{lang==="en"?"Market condition":"Condição de mercado"}</span><b>{conditionLabel(marketDetail.marketCondition,lang)}</b></div><div><span>{lang==="en"?"Entry vs. buy-city 7d avg":"Entrada vs. média 7d da cidade de compra"}</span><b className={marketDetail.entryAdvantagePct>=0?"profit":"warn"}>{marketDetail.entryAdvantagePct>=0?"+":""}{marketDetail.entryAdvantagePct.toFixed(1)}%</b></div><div><span>{lang==="en"?"7d trend":"Tendência 7d"}</span><b>{marketDetail.trendPct>=0?"+":""}{marketDetail.trendPct.toFixed(1)}%</b></div></div></section><section className={`solRecommendation ${rec.tone}`}><div className="solRecommendationTop"><span>{lang==="en"?"☀️ SOL RECOMMENDS":"☀️ SOL RECOMENDA"}</span><strong>{rec.label}</strong></div><h3>{rec.headline}</h3><p>{rec.reason}</p><b>{rec.action}</b></section><div className="signalGrid"><div><span>{lang==="en"?"Liquidity":"Liquidez"}</span><b>{lang==="en"?({Alta:"High",Média:"Medium",Baixa:"Low","Sem dados":"No data"}[marketDetail.liquidity]??marketDetail.liquidity):marketDetail.liquidity}</b></div><div><span>{lang==="en"?"Risk":"Risco"}</span><b>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[marketDetail.risk]??marketDetail.risk):marketDetail.risk}</b></div><div><span>{lang==="en"?"Volatility":"Volatilidade"}</span><b>{marketDetail.volatilityPct.toFixed(1)}%</b></div><div><span>{lang==="en"?"Price vs. 7d avg":"Preço vs. média 7d"}</span><b>{marketDetail.priceDeviationPct>=0?"+":""}{marketDetail.priceDeviationPct.toFixed(1)}%</b></div><div><span>{lang==="en"?"Average / day":"Média / dia"}</span><b>{marketDetail.avgDailyVolume.toFixed(1)}</b></div><div><span>{lang==="en"?"Data":"Dados"}</span><b>{ageText(Math.max(marketDetail.buyAgeMin,marketDetail.sellAgeMin))}</b></div></div></>})():<div className="optimizerDetailLoading">{detailError}</div>):<><div className="detailGrid"><div><span>{lang==="en"?"Saved investment":"Investimento guardado"}</span><strong>{money(selected.investment)}</strong></div><div><span>{lang==="en"?"Saved profit":"Lucro guardado"}</span><strong className="profit">+{money(selected.profit)}</strong></div><div><span>{lang==="en"?"Saved return":"Rentabilidade guardada"}</span><strong>{selected.roi.toFixed(1)}%</strong></div><div><span>{lang==="en"?"Current sell":"Venda atual"}</span><strong>{money(quotes[selected.id]?.sellPrice??selected.sellPrice)}</strong></div><div><span>{lang==="en"?"Data":"Dados"}</span><strong>{ageText(quotes[selected.id]?.sellAgeMin??selected.dataAgeMin??999)}</strong></div><div><span>{lang==="en"?"Engine":"Motor"}</span><strong>{selected.type}</strong></div></div><p className="drawerNote">{lang==="en"?"Craft/Refine watchlist values are the saved scanner snapshot; the current output sell quote is refreshed separately.":"Os valores de Craft/Refine são o snapshot guardado pelo scanner; a cotação atual de venda do produto é atualizada separadamente."}</p></>}
   <div className="opportunityFooter"><AddToPortfolioButton type={selected.type} itemId={selected.itemId} name={selected.name} route={selected.route} qty={1} investment={selected.investment} expectedProfit={selected.profit}/></div>
  </aside></div>}
  <footer>SOL HUB • by Fate and Ryukk • NoTag Exclusive • 2026 • {lang==="en"?"Not affiliated with Sandbox Interactive.":"Não afiliado à Sandbox Interactive."}</footer>
 </main>
}
