import type {Metadata} from "next";
export const metadata:Metadata={title:"Watchlist • SOL HUB",description:"Favoritos e oportunidades em observação no SOL HUB."};
export default function Layout({children}:{children:React.ReactNode}){return children}
