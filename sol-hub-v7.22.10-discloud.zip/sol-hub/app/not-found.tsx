"use client";
import Link from "next/link";
import {useEffect,useState} from "react";
import {currentSiteLanguage} from "../lib/languageClient";
export default function NotFound(){
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 useEffect(()=>setLang(currentSiteLanguage()),[]);
 return <main className="shell"><section className="panel" style={{marginTop:80,textAlign:"center"}}><div className="eyebrow">404</div><h1>{lang==="en"?"This market does not exist 😅":"Este mercado não existe 😅"}</h1><p>{lang==="en"?"Go back to SOL HUB.":"Volta ao SOL HUB."}</p><Link href="/" className="scan" style={{display:"inline-block",textDecoration:"none"}}>{lang==="en"?"Back to Dashboard":"Voltar à Dashboard"}</Link></section></main>
}
