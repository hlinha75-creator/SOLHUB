import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SOL Optimizer"
};

export default function Layout({children}: Readonly<{children: React.ReactNode}>){
  return children;
}
