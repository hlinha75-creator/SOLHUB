"use client";
import {itemImageUrl} from "../../lib/itemImage";
import LanguageSelector from "../components/LanguageSelector";
import AppSidebar from "../components/AppSidebar";
import SpecsAwareness from "../components/SpecsAwareness";


import AddToPortfolioButton from "../components/AddToPortfolioButton";
import WatchlistButton from "../components/WatchlistButton";
import {currentSiteLanguage} from "../../lib/languageClient";

import Link from "next/link";
import {FormEvent,useEffect,useMemo,useState} from "react";
import SortTh from "../components/SortTh";
import {sortRows,nextSort,type SortDir} from "../../lib/sort";
import {loadFocusProfile,loadCraftingProfile} from "../../lib/focusClient";
import {settingsFormKey,useSolHubSettings} from "../../lib/settingsClient";
import {ageText,dataHealthLabel,dataHealthLevel,dataHealthSummary} from "../../lib/dataHealth";
import {marketRecommendation,craftRecommendation,refineRecommendation} from "../../lib/solRecommendations";
import {conditionLabel,intelligenceBand,type IntelligenceComponents,type IntelligenceCondition} from "../../lib/solIntelligence";
const fmt=new Intl.NumberFormat("pt-PT"),money=(n:number)=>fmt.format(Math.round(n||0));
type O={type:"FLIP"|"CRAFT"|"REFINE";itemId:string;name:string;kind?:"equipment"|"potion"|"food"|"refining";route:string;daily?:number;rrr?:number;productionBonus?:number;shopping?:Record<string,{id:string;name:string;qty:number;unitPrice:number}[]>;outputPerCraft?:number;investment:number;profit:number;roi:number;score:number;decisionScore?:number;risk:"Baixo"|"Médio"|"Alto";qty:number;focusMode?:boolean;focusPerCraft?:number;focusUsed?:number;focusedQty?:number;reason:string;dataAgeMin?:number;unitInvestment?:number;unitProfit?:number;unitInvestmentNoFocus?:number;unitProfitNoFocus?:number;unitInvestmentFocus?:number;unitProfitFocus?:number;focusEfficiency?:number};
type MarketDetail={itemId:string;itemName:string;quality:number;qualityName:string;buyCity:string;sellCity:string;buyPrice:number;sellPrice:number;fees:number;profit:number;roi:number;buyAgeMin:number;sellAgeMin:number;score:number;recommendedQty:number;recommendedInvestment:number;recommendedProfit:number;avgDailyVolume:number;volume7d:number;historyAvgPrice:number;priceDeviationPct:number;volatilityPct:number;liquidity:"Alta"|"Média"|"Baixa"|"Sem dados";buyHistoryAvgPrice:number;entryAdvantagePct:number;trendPct:number;intelligenceScore:number;intelligenceComponents:IntelligenceComponents;marketCondition:IntelligenceCondition;risk:"Baixo"|"Médio"|"Alto";history:{item_count:number;avg_price:number;timestamp:string}[]};

type R={opportunities:O[];plan:O[];summary:{capital:number;invested:number;reserve:number;expectedProfit:number;roi:number;flipInvestment:number;craftInvestment:number;refineInvestment:number;focusUsed:number;focusRemaining:number};meta:{scannedFlips:number;scannedCrafts:number;scannedRefines:number;focusAvailable:number;focusNote:string;enabledStrategies?:{flips:boolean;crafts:boolean;refines:boolean}};error?:string};

function MiniChart({points,lang}:{points:MarketDetail["history"];lang:"pt-BR"|"en"}){
 const data=points.filter(p=>p.avg_price>0);
 if(!data.length)return <div className="noHistory">{lang==="en"?"Not enough history for a chart.":"Sem histórico suficiente para o gráfico."}</div>;
 const max=Math.max(...data.map(p=>p.avg_price)),min=Math.min(...data.map(p=>p.avg_price)),range=Math.max(1,max-min);
 return <div className="chart">{data.map((p,i)=>{const h=22+((p.avg_price-min)/range)*70;return <div className="barWrap" key={`${p.timestamp}-${i}`} title={`${p.timestamp.slice(0,10)} • ${money(p.avg_price)} silver • ${p.item_count}`}><div className="bar" style={{height:`${h}%`}}/><span>{new Date(p.timestamp).toLocaleDateString(lang==="en"?"en-GB":"pt-BR",{day:"2-digit",month:"2-digit"})}</span></div>})}</div>
}

export default function Optimizer(){ const {settings,ready:settingsReady}=useSolHubSettings();
 const [lang,setLang]=useState<"pt-BR"|"en">("en");
 const [r,setR]=useState<R|null>(null),[loading,setLoading]=useState(false),[err,setErr]=useState("");
 const [selected,setSelected]=useState<O|null>(null);
 const [marketDetail,setMarketDetail]=useState<MarketDetail|null>(null);
 const [detailLoading,setDetailLoading]=useState(false);
 const [detailError,setDetailError]=useState("");
 const [strategies,setStrategies]=useState({flips:true,crafts:true,refines:true});
 const [planSort,setPlanSort]=useState<{key:string;dir:SortDir}>({key:"decisionScore",dir:"desc"}),[oppSort,setOppSort]=useState<{key:string;dir:SortDir}>({key:"decisionScore",dir:"desc"});
 const sortPlanBy=(key:string)=>setPlanSort(v=>nextSort(v.key,v.dir,key));const sortOppBy=(key:string)=>setOppSort(v=>nextSort(v.key,v.dir,key));
 const health=dataHealthSummary(r?.opportunities.map(o=>o.dataAgeMin)??[]);
 useEffect(()=>setLang(currentSiteLanguage()),[]);
 useEffect(()=>{try{const saved=JSON.parse(localStorage.getItem("notag-optimizer-strategies-v1")??"null");if(saved&&typeof saved==="object")setStrategies({flips:saved.flips!==false,crafts:saved.crafts!==false,refines:saved.refines!==false})}catch{}},[]);
 function setStrategy(key:"flips"|"crafts"|"refines",value:boolean){setStrategies(prev=>{const next={...prev,[key]:value};localStorage.setItem("notag-optimizer-strategies-v1",JSON.stringify(next));return next})}
 const planMatch=(o:O)=>r?.plan.find(p=>p.type===o.type&&p.itemId===o.itemId&&p.route===o.route)??null;
 async function openOpportunity(o:O){
  setSelected(o);setMarketDetail(null);setDetailError("");
  if(o.type!=="FLIP")return;
  const [buyCity,sellCity]=o.route.split(" → ");
  if(!buyCity||!sellCity)return;
  setDetailLoading(true);
  try{
   const q=new URLSearchParams({
    itemId:o.itemId,buyCity,sellCity,category:"all",tiers:"4,5,6,7,8",enchants:"0,1,2,3",
    maxAgeHours:"48",minRoi:"0",minProfit:"0",capital:String(r?.summary.capital??15000000),
    premium:String(settings.premium),maxAllocationPct:"20",maxDailyVolumePct:"25",saleMode:"sell_order",lang
   });
   const x=await fetch(`/api/flips?${q}`),j=await x.json();
   if(!x.ok)throw Error(j.error??(lang==="en"?"Could not load opportunity detail.":"Não foi possível carregar os detalhes da oportunidade."));
   const exact=(j.flips??[]).find((f:MarketDetail)=>f.itemId===o.itemId&&f.buyCity===buyCity&&f.sellCity===sellCity);
   if(exact)setMarketDetail(exact);else setDetailError(lang==="en"?"The market route is no longer available under the same conditions.":"A rota de mercado já não está disponível nas mesmas condições.");
  }catch(e){setDetailError(e instanceof Error?e.message:(lang==="en"?"Unexpected error.":"Erro inesperado."))}finally{setDetailLoading(false)}
 }
 async function run(e:FormEvent<HTMLFormElement>){e.preventDefault();setErr("");if(!strategies.flips&&!strategies.crafts&&!strategies.refines){setR(null);setErr(lang==="en"?"Select at least one strategy for the Optimizer.":"Selecione pelo menos uma estratégia para o Optimizer.");return}setLoading(true);const f=new FormData(e.currentTarget),q=new URLSearchParams();for(const[k,v]of f.entries())q.set(k,String(v));q.set("includeFlips",String(strategies.flips));q.set("includeCrafts",String(strategies.crafts));q.set("includeRefines",String(strategies.refines));q.set("focusProfile",JSON.stringify(loadFocusProfile()));q.set("specProfile",JSON.stringify(loadCraftingProfile()));q.set("lang",currentSiteLanguage());if(!f.has("premium"))q.set("premium","false");try{const x=await fetch(`/api/optimizer?${q}`),j=await x.json();if(!x.ok)throw Error(j.error??(lang==="en"?"Optimizer failed.":"Falha no Optimizer."));setR(j)}catch(x){setErr(x instanceof Error?x.message:(lang==="en"?"Unexpected error.":"Erro inesperado."))}finally{setLoading(false)}}
 const ui=lang==="en"?{
  considered:"Opportunities considered",consideredDesc:(f:number,c:number,rn:number)=>`${f} flips + ${c} crafts + ${rn} refines passed the filters.`,
  concentration:"The plan limits concentration per opportunity.",engine:"Engine",item:"Item",route:"Route",
  unitCost:"Cost / unit",planQty:"Qty. in plan",planInvestment:"Investment in plan",unitProfit:"Profit / unit",return:"Return",data:"Data",risk:"Risk",why:"Why",decisionScore:"Decision Score",
  notSelected:"Not selected",selected:"In plan",detail:"OPPORTUNITY DETAIL",close:"Close",
  allocation:"Current plan allocation",qty:"Quantity",investment:"Investment",expectedProfit:"Expected profit",
  notInPlan:"This opportunity passed the filters but was not selected for the current plan.",
  unitEconomics:"Unit economics",recommendation:"SOL recommendation",shopping:"Shopping list",focus:"Focus",daily:"Daily Bonus",rrr:"Return Rate",
  chart:"Average daily price — last 7 days",historicalAvg:"Historical average",buy:"Buy",sell:"Sell",fees:"Fees",
  liquidity:"Liquidity",volatility:"Volatility",priceVsAvg:"Price vs. 7d average",avgDay:"Average / day",
  loading:"Loading current market detail…",detailError:"Current market detail could not be loaded.",units:"units",perUnit:"/ unit",
  marketNote:"AODP history is used as a liquidity and stability signal. Always confirm live prices before executing the trade.",
  productionNote:"Material quantities below are shown for the current plan allocation when the opportunity is selected; otherwise they are shown per craft/refine.",
  heroDesc:"Flipping, crafting and refining compete for the same capital. SOL selects only opportunities that pass your filters.", strategiesTitle:"Strategies to include",strategiesDesc:"Choose which economic engines enter the search and compete for your capital.",flipDesc:"Buy and sell between markets",craftDesc:"Production with Return Rate and Focus",refineDesc:"Refining with specializations and Focus",capitalAvailable:"Available capital",focusAvailable:"Available Focus",minReturn:"Minimum return (%)",maxDataAge:"Max data age (hours)",maxPerOpportunity:"Max per opportunity (%)",maxRisk:"Maximum risk",craftDestination:"Crafting destination",refineDestination:"Refining destination",stationFee:"Station Fee (Silver)",perNutrition:"— per 100 nutrition",example:"e.g. 350",planEyebrow:"☀️ SOL PLAN",recommendedAllocation:"Recommended allocation",planDesc:"The Optimizer does not have to spend everything. Capital without an acceptable opportunity remains in reserve.",invested:"invested",potentialProfit:"potential profit",invest:"Invest",reserve:"Reserve",planReturn:"Plan return",inFlips:"In flips",inCrafting:"In crafting",inRefining:"In refining",focusUsed:"Focus used",focusRemaining:"Focus remaining",plan:"Plan",qtyShort:"Qty.",profit:"Profit",noPlan:"SOL did not find enough opportunities to recommend an investment with these filters.",disclaimer:"Potential profit, not guaranteed. Confirm prices and liquidity in-game."
 }:{
  considered:"Oportunidades consideradas",consideredDesc:(f:number,c:number,rn:number)=>`${f} flips + ${c} crafts + ${rn} refinos passaram pelos filtros.`,
  concentration:"O plano limita a concentração por oportunidade.",engine:"Motor",item:"Item",route:"Rota",
  unitCost:"Custo / un.",planQty:"Qtd. no plano",planInvestment:"Investimento no plano",unitProfit:"Lucro / un.",return:"Rentabilidade",data:"Dados",risk:"Risco",why:"Por quê",decisionScore:"Score de decisão",
  notSelected:"Não selecionada",selected:"No plano",detail:"DETALHES DA OPORTUNIDADE",close:"Fechar",
  allocation:"Alocação no plano atual",qty:"Quantidade",investment:"Investimento",expectedProfit:"Lucro esperado",
  notInPlan:"Esta oportunidade passou pelos filtros, mas não foi selecionada para o plano atual.",
  unitEconomics:"Economia por unidade",recommendation:"Recomendação do SOL",shopping:"Lista de compras",focus:"Focus",daily:"Daily Bonus",rrr:"Return Rate",
  chart:"Preço médio diário — últimos 7 dias",historicalAvg:"Média histórica",buy:"Compra",sell:"Venda",fees:"Taxas",
  liquidity:"Liquidez",volatility:"Volatilidade",priceVsAvg:"Preço vs. média 7d",avgDay:"Média / dia",
  loading:"Carregando detalhes atuais do mercado…",detailError:"Não foi possível carregar os detalhes atuais do mercado.",units:"un.",perUnit:"/ un.",
  marketNote:"O histórico do AODP é usado como sinal de liquidez e estabilidade. Sempre confirme os preços ao vivo antes de executar a operação.",
  productionNote:"As quantidades de materiais abaixo são exibidas para a alocação do plano atual quando a oportunidade está selecionada; caso contrário, são mostradas por craft/refino.",
  heroDesc:"Flipping, crafting e refining disputam o mesmo capital. O SOL escolhe apenas as oportunidades que passam os teus filtros.", strategiesTitle:"Estratégias a incluir",strategiesDesc:"Escolhe que motores económicos entram na pesquisa e competem pelo teu capital.",flipDesc:"Compra e venda entre mercados",craftDesc:"Produção com Return Rate e Focus",refineDesc:"Refino com especializações e Focus",capitalAvailable:"Capital disponível",focusAvailable:"Focus disponível",minReturn:"Rentabilidade mínima (%)",maxDataAge:"Dados máx. (horas)",maxPerOpportunity:"Máx. por oportunidade (%)",maxRisk:"Risco máximo",craftDestination:"Destino crafting",refineDestination:"Destino refining",stationFee:"Taxa da Estação (Silver)",perNutrition:"— por 100 de nutrição",example:"Ex.: 350",planEyebrow:"☀️ PLANO DO SOL",recommendedAllocation:"Alocação recomendada",planDesc:"O optimizer não é obrigado a gastar tudo. Capital sem oportunidade aceitável fica em reserva.",invested:"investidos",potentialProfit:"lucro potencial",invest:"Investir",reserve:"Reserva",planReturn:"Rentabilidade do plano",inFlips:"Em flips",inCrafting:"Em crafting",inRefining:"Em refining",focusUsed:"Focus usado",focusRemaining:"Focus restante",plan:"Plano",qtyShort:"Qtd.",profit:"Lucro",noPlan:"O SOL não encontrou oportunidades suficientes para recomendar investimento com estes filtros.",disclaimer:"Lucro potencial, não garantido. Confirma preços e liquidez no jogo."
 };
 return <main className="shell"><AppSidebar/>
 <header className="hero"><div><div className="eyebrow">NOTAG • CAPITAL ALLOCATION</div><h1>SOL <span>Optimizer</span></h1><p>{ui.heroDesc}</p></div><div className="headerTools"><LanguageSelector/></div></header>
 <SpecsAwareness/>

 <section className="panel"><form key={settingsFormKey(settings,settingsReady)} onSubmit={run} className="filters">
 <div className="strategyPicker">
   <div className="strategyPickerHead"><div><strong>{ui.strategiesTitle}</strong><span>{ui.strategiesDesc}</span></div></div>
   <div className="strategyOptions">
     <label className={`strategyToggle ${strategies.flips?"active":""}`}><input type="checkbox" checked={strategies.flips} onChange={e=>setStrategy("flips",e.target.checked)}/><span className="strategyIcon">↔</span><span><b>Flipping</b><small>{ui.flipDesc}</small></span></label>
     <label className={`strategyToggle ${strategies.crafts?"active":""}`}><input type="checkbox" checked={strategies.crafts} onChange={e=>setStrategy("crafts",e.target.checked)}/><span className="strategyIcon">⚒</span><span><b>Crafting</b><small>{ui.craftDesc}</small></span></label>
     <label className={`strategyToggle ${strategies.refines?"active":""}`}><input type="checkbox" checked={strategies.refines} onChange={e=>setStrategy("refines",e.target.checked)}/><span className="strategyIcon">♻️</span><span><b>Refining</b><small>{ui.refineDesc}</small></span></label>
   </div>
 </div>
 <label>{ui.capitalAvailable}<input name="capital" type="number" defaultValue="15000000" min="100000"/></label>
 {(strategies.crafts||strategies.refines)&&<label>{ui.focusAvailable}<input name="focus" type="number" defaultValue={settings.focus} min="0" max="30000" step="1"/></label>}
 <label>{ui.minReturn}<input name="minRoi" type="number" defaultValue="10" min="0"/></label>
 <label>{ui.maxDataAge}<input name="maxAgeHours" type="number" defaultValue={settings.maxAgeHours} min="1" max="48"/></label>
 <label>{ui.maxPerOpportunity}<input name="maxAllocationPct" type="number" defaultValue="20" min="1" max="100"/></label>
 <label>{ui.maxRisk}<select name="risk" defaultValue="Médio"><option value="Baixo">{lang==="en"?"Low":"Baixo"}</option><option value="Médio">{lang==="en"?"Medium":"Médio"}</option><option value="Alto">{lang==="en"?"High":"Alto"}</option></select></label>
 {strategies.crafts&&<label>{ui.craftDestination}<select name="craftSellCity" defaultValue={settings.craftSellCity}><option>Black Market</option><option>Bridgewatch</option><option>Martlock</option><option>Lymhurst</option><option>Thetford</option><option>Fort Sterling</option><option>Caerleon</option></select></label>} {strategies.refines&&<label>{ui.refineDestination}<select name="refineSellCity" defaultValue={settings.refineSellCity}><option>Bridgewatch</option><option>Martlock</option><option>Lymhurst</option><option>Thetford</option><option>Fort Sterling</option><option>Caerleon</option><option>Brecilien</option><option>Black Market</option></select></label>}
 
 {(strategies.crafts||strategies.refines)&&<label>{ui.stationFee} <small className="fieldHint inline">{ui.perNutrition}</small><input name="stationFee" type="number" defaultValue={settings.stationFee} min="0" step="1" placeholder={ui.example}/></label>}
 <label className="check"><input name="premium" type="checkbox" value="true" defaultChecked={settings.premium}/> Premium</label>
 <button className="scan" disabled={loading}>{loading?(lang==="en"?"SOL is calculating…":"O Sol está a fazer contas…"):(lang==="en"?"☀️ MAKE ME SILVER":"☀️ FAZ-ME SILVER")}</button>
 </form></section>{err&&<div className="error">{err}</div>}

 {r&&<><section className="results plan">
 <div className="resultsHead"><div><div className="eyebrow">{ui.planEyebrow}</div><h2>{ui.recommendedAllocation}</h2><p>{ui.planDesc}</p></div>
 <div className="planStats"><strong>{money(r.summary.invested)}</strong><span>{ui.invested}</span><strong className="profit">+{money(r.summary.expectedProfit)}</strong><span>{ui.potentialProfit}</span></div></div>
 <div className="optimizerCards">
   <div className="metricCard"><span>Capital</span><strong>{money(r.summary.capital)}</strong></div>
   <div className="metricCard"><span>{ui.invest}</span><strong>{money(r.summary.invested)}</strong></div>
   <div className="metricCard"><span>{ui.reserve}</span><strong>{money(r.summary.reserve)}</strong></div>
   <div className="metricCard"><span>{ui.planReturn}</span><strong>{r.summary.roi.toFixed(1)}%</strong></div>
   {r.meta.enabledStrategies?.flips!==false&&<div className="metricCard"><span>{ui.inFlips}</span><strong>{money(r.summary.flipInvestment)}</strong></div>}
   {r.meta.enabledStrategies?.crafts!==false&&<div className="metricCard"><span>{ui.inCrafting}</span><strong>{money(r.summary.craftInvestment)}</strong></div>}
   {r.meta.enabledStrategies?.refines!==false&&<div className="metricCard"><span>{ui.inRefining}</span><strong>{money(r.summary.refineInvestment)}</strong></div>}
   {(r.meta.enabledStrategies?.crafts!==false||r.meta.enabledStrategies?.refines!==false)&&<><div className="metricCard"><span>{ui.focusUsed}</span><strong>{money(r.summary.focusUsed)}</strong></div><div className="metricCard"><span>{ui.focusRemaining}</span><strong>{money(r.summary.focusRemaining)}</strong></div></>}
 </div>
 <div className="optimizerDecisionNote"><span>☀️ {ui.decisionScore}</span><p>{lang==="en"?"The Optimizer now ranks opportunities using the scanner score together with data freshness, risk quality and capital efficiency. Market flips receive the full historical SOL Score 2.0 when you open the Opportunity Detail.":"O Optimizer agora ordena as oportunidades usando o score do scanner juntamente com a frescura dos dados, a qualidade do risco e a eficiência de capital. Os flips de mercado recebem o SOL Score 2.0 histórico completo ao abrir os detalhes da oportunidade."}</p></div>
 {health.total>0&&<div className="dataHealthBar"><div><span className="dataHealthTitle">📡 {lang==="en"?"Market Data Health":"Saúde dos Dados de Mercado"}</span><strong>{health.healthyPct}% {lang==="en"?"Fresh/Recent":"Atual/Recente"}</strong><small>{health.total} {lang==="en"?"opportunities • oldest":"oportunidades • mais antigo"} {ageText(health.maxAgeMin)}</small></div><div className="dataHealthLegend"><span className="freshNow">{lang==="en"?"Fresh":"Atual"} {health.counts.freshNow}</span><span className="freshOk">{lang==="en"?"Recent":"Recente"} {health.counts.freshOk}</span><span className="freshAging">{lang==="en"?"Aging":"Envelhecendo"} {health.counts.freshAging}</span><span className="freshStale">{lang==="en"?"Stale":"Desatualizado"} {health.counts.freshStale}</span></div></div>}
 <div className="tableWrap financeTableWrap"><table className="financeTable"><thead><tr><th>#</th><SortTh label={ui.engine} field="type" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.item} field="name" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.plan} field="route" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.qtyShort} field="qty" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.invest} field="investment" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.profit} field="profit" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.return} field="roi" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.data} field="dataAgeMin" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.risk} field="risk" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><SortTh label={ui.decisionScore} field="decisionScore" sortKey={planSort.key} sortDir={planSort.dir} onSort={sortPlanBy}/><th>Watchlist</th><th>Portfolio</th></tr></thead><tbody>
 {sortRows<O>(r.plan,planSort.key,planSort.dir).map((o,i)=><tr className="clickable" onClick={()=>openOpportunity(o)} key={`${o.type}-${o.itemId}-${i}`}><td>{i+1}</td><td><div className="engineCell"><span className={o.type==="FLIP"?"engine flip":o.type==="REFINE"?"engine refine":"engine craft"}>{o.type==="FLIP"?"↔ FLIP":o.type==="REFINE"?"♻ REFINE":"⚒ CRAFT"}</span>{o.type!=="FLIP"&&o.daily?<small className="dailyApplied">Daily +{o.daily}%</small>:null}</div></td><td><div className="item"><img src={itemImageUrl(o.itemId,{size:64})} alt=""/><div><strong>{o.name}</strong><span>{o.itemId}</span></div></div></td><td>{o.type!=="FLIP"?<div className="craftRoute">
 {o.shopping&&Object.entries(o.shopping).map(([city,mats])=><div className="buyStep" key={city}><b>{lang==="en"?"Buy in":"Comprar em"} {city}</b>{mats.map(m=><span key={m.id}>{m.qty*Math.max(1,o.qty)}× {m.name}</span>)}</div>)}
 {o.route.split(" | ").slice(1).map((step,j)=><span key={j}>{step}</span>)}
 </div>:o.route}</td><td><b>{o.qty}</b>{o.type!=="FLIP"&&<small className="qtyHint">{o.kind==="potion"?"🧪 ":o.kind==="food"?"🍲 ":""}{o.type==="REFINE"?(lang==="en"?"refines":"refinos"):(lang==="en"?"crafts":"crafts")}<br/>{o.qty*(o.outputPerCraft??1)} {lang==="en"?"items":"itens"}{(o.focusedQty??0)>0&&<><br/>{o.focusedQty} {lang==="en"?"with Focus":"com Focus"} • {o.focusUsed} Focus</>}</small>}</td><td>{money(o.investment)}</td><td className="profit">+{money(o.profit)}</td><td><b>{o.roi.toFixed(1)}%</b></td><td>{o.dataAgeMin!=null?<span className={`dataFreshness ${dataHealthLevel(o.dataAgeMin)}`} title={dataHealthLabel(o.dataAgeMin,lang)}><i/>{ageText(o.dataAgeMin)}</span>:<span className="dataFreshness freshStale"><i/>—</span>}</td><td><span className={`risk ${o.risk.toLowerCase().replace("é","e")}`}>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[o.risk]??o.risk):o.risk}</span></td><td><span className={(o.decisionScore??o.score)>=85?"score hot":(o.decisionScore??o.score)>=72?"score good":"score"}>{o.decisionScore??o.score}</span></td><td onClick={e=>e.stopPropagation()}><WatchlistButton source="SOL_OPTIMIZER" compact type={o.type} itemId={o.itemId} name={o.name} route={o.route} investment={o.investment} profit={o.profit} roi={o.roi} dataAgeMin={o.dataAgeMin}/></td><td onClick={e=>e.stopPropagation()}><AddToPortfolioButton type={o.type} itemId={o.itemId} name={o.name} route={o.route} qty={o.qty} investment={o.investment} expectedProfit={o.profit} focusUsed={o.focusUsed??0} solScore={o.decisionScore??o.score} source="SOL_OPTIMIZER"/></td></tr>)}
 {!r.plan.length&&<tr><td colSpan={13} className="empty">{ui.noPlan}</td></tr>}
 </tbody></table></div>
 <div className="disclaimer">⚠️ {ui.disclaimer} {r.meta.focusNote}</div>
 </section>

 <section className="results optimizerConsidered"><div className="resultsHead"><div><h2>{ui.considered}</h2><p>{ui.consideredDesc(r.meta.scannedFlips,r.meta.scannedCrafts,r.meta.scannedRefines)}</p></div><small>{ui.concentration}</small></div>
 <div className="tableWrap financeTableWrap"><table className="financeTable"><thead><tr>
  <SortTh label={ui.engine} field="type" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.item} field="name" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.route} field="route" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.unitCost} field="investment" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <th>{ui.planQty}</th><th>{ui.planInvestment}</th>
  <SortTh label={ui.unitProfit} field="profit" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.return} field="roi" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.data} field="dataAgeMin" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/>
  <SortTh label={ui.risk} field="risk" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/><SortTh label={ui.decisionScore} field="decisionScore" sortKey={oppSort.key} sortDir={oppSort.dir} onSort={sortOppBy}/><th>{ui.why}</th><th>Watchlist</th>
 </tr></thead><tbody>
 {sortRows<O>(r.opportunities,oppSort.key,oppSort.dir).slice(0,40).map((o,i)=>{const planned=planMatch(o);const unitCost=o.unitInvestment??o.investment;const unitProfit=o.unitProfit??o.profit;return <tr className="clickable" onClick={()=>openOpportunity(o)} key={`all-${o.type}-${o.itemId}-${i}`}>
   <td><span className={o.type==="FLIP"?"engine flip":o.type==="REFINE"?"engine refine":"engine craft"}>{o.type}</span></td>
   <td><div className="item"><img src={itemImageUrl(o.itemId,{size:56})} alt=""/><div><strong>{o.name}</strong><span>{planned?ui.selected:ui.notSelected}</span></div></div></td>
   <td>{o.type!=="FLIP"?<div className="craftRoute">{o.route.split(" | ").map((step,j)=><span key={j}>{step}</span>)}</div>:o.route}</td>
   <td><b>{money(unitCost)}</b></td>
   <td>{planned?<b>{planned.qty}</b>:<span className="optimizerNotPlanned">—</span>}</td>
   <td>{planned?<b>{money(planned.investment)}</b>:<span className="optimizerNotPlanned">—</span>}</td>
   <td className="profit">+{money(unitProfit)}</td><td>{o.roi.toFixed(1)}%</td>
   <td>{o.dataAgeMin!=null?<span className={`dataFreshness ${dataHealthLevel(o.dataAgeMin)}`} title={dataHealthLabel(o.dataAgeMin,lang)}><i/>{ageText(o.dataAgeMin)}</span>:<span className="dataFreshness freshStale"><i/>—</span>}</td>
   <td><span className={`risk ${o.risk.toLowerCase().replace("é","e")}`}>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[o.risk]??o.risk):o.risk}</span></td>
   <td><span className={(o.decisionScore??o.score)>=85?"score hot":(o.decisionScore??o.score)>=72?"score good":"score"}>{o.decisionScore??o.score}</span></td>
   <td>{o.reason}</td>
   <td onClick={e=>e.stopPropagation()}><WatchlistButton source="SOL_OPTIMIZER" compact type={o.type} itemId={o.itemId} name={o.name} route={o.route} investment={planned?.investment??unitCost} profit={planned?.profit??unitProfit} roi={o.roi} dataAgeMin={o.dataAgeMin}/></td>
  </tr>})}
 </tbody></table></div></section></>}
 {selected&&<div className="overlay" onClick={()=>setSelected(null)}><aside className="drawer opportunityDrawer optimizerOpportunityDrawer" onClick={e=>e.stopPropagation()}>
  <button className="close" aria-label={ui.close} onClick={()=>setSelected(null)}>×</button>
  {(()=>{const planned=planMatch(selected);const qty=planned?.qty??1;const totalInvestment=planned?.investment??(selected.unitInvestment??selected.investment);const totalProfit=planned?.profit??(selected.unitProfit??selected.profit);
   if(selected.type==="FLIP"){
    return <>
     <div className="detailHead"><img src={itemImageUrl(selected.itemId,{quality:marketDetail?.quality??1,size:128})} alt=""/><div><div className="eyebrow">{ui.detail}</div><h2>{selected.name}</h2><p>{selected.route}</p></div></div>
     {detailLoading?<div className="optimizerDetailLoading">{ui.loading}</div>:marketDetail?(()=>{
       const rec=marketRecommendation({roi:marketDetail.roi,profit:marketDetail.profit,risk:marketDetail.risk,liquidity:marketDetail.liquidity,volatilityPct:marketDetail.volatilityPct,priceDeviationPct:marketDetail.priceDeviationPct,dataAgeMin:Math.max(marketDetail.buyAgeMin,marketDetail.sellAgeMin),recommendedQty:planned?.qty??marketDetail.recommendedQty},lang);
       return <>
        <div className="detailGrid"><div><span>{ui.buy}</span><strong>{money(marketDetail.buyPrice)}</strong></div><div><span>{ui.sell}</span><strong>{money(marketDetail.sellPrice)}</strong></div><div><span>{ui.fees}</span><strong>{money(marketDetail.fees)}</strong></div><div><span>{ui.unitProfit}</span><strong className="profit">+{money(marketDetail.profit)}</strong></div><div><span>{ui.return}</span><strong>{marketDetail.roi.toFixed(1)}%</strong></div><div><span>Score</span><strong>{marketDetail.score}/100</strong></div></div><section className="solIntelScoreCard compactIntel"><div className="solIntelScoreHead"><div><span>☀️ SOL SCORE 2.0</span><strong>{marketDetail.intelligenceScore}/100</strong></div><b>{intelligenceBand(marketDetail.intelligenceScore,lang)}</b></div><div className="solEntryQuality"><div><span>{lang==="en"?"Market condition":"Condição de mercado"}</span><b>{conditionLabel(marketDetail.marketCondition,lang)}</b></div><div><span>{lang==="en"?"Entry vs. buy-city 7d avg":"Entrada vs. média 7d da cidade de compra"}</span><b className={marketDetail.entryAdvantagePct>=0?"profit":"warn"}>{marketDetail.entryAdvantagePct>=0?"+":""}{marketDetail.entryAdvantagePct.toFixed(1)}%</b></div><div><span>{lang==="en"?"7d trend":"Tendência 7d"}</span><b>{marketDetail.trendPct>=0?"+":""}{marketDetail.trendPct.toFixed(1)}%</b></div></div></section>
        <section className={`solRecommendation ${rec.tone}`}><div className="solRecommendationTop"><span>{lang==="en"?"☀️ SOL RECOMMENDS":"☀️ SOL RECOMENDA"}</span><strong>{rec.label}</strong></div><h3>{rec.headline}</h3><p>{rec.reason}</p><b>{rec.action}</b></section>
        <div className="signalGrid"><div><span>{ui.avgDay}</span><b>{marketDetail.avgDailyVolume.toFixed(1)}</b></div><div><span>{ui.liquidity}</span><b>{lang==="en"?({Alta:"High",Média:"Medium",Baixa:"Low","Sem dados":"No data"}[marketDetail.liquidity]??marketDetail.liquidity):marketDetail.liquidity}</b></div><div><span>{ui.risk}</span><b>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[marketDetail.risk]??marketDetail.risk):marketDetail.risk}</b></div><div><span>{ui.volatility}</span><b>{marketDetail.volatilityPct.toFixed(1)}%</b></div><div><span>{ui.priceVsAvg}</span><b>{marketDetail.priceDeviationPct>=0?"+":""}{marketDetail.priceDeviationPct.toFixed(1)}%</b></div><div><span>{ui.data}</span><b>{ageText(Math.max(marketDetail.buyAgeMin,marketDetail.sellAgeMin))}</b></div></div>
        <div className="chartBox"><div className="chartTitle"><strong>{ui.chart}</strong><span>{ui.historicalAvg}: {marketDetail.historyAvgPrice?money(marketDetail.historyAvgPrice):"—"}</span></div><MiniChart points={marketDetail.history} lang={lang}/></div>
       </>
     })():<div className="optimizerDetailLoading">{detailError||ui.detailError}</div>}
     <div className="recommend optimizerAllocation"><div><span>{ui.allocation}</span><strong>{planned?ui.selected:ui.notSelected}</strong></div><div><span>{ui.qty}</span><strong>{planned?planned.qty:"—"} {planned?ui.units:""}</strong></div><div><span>{ui.investment}</span><strong>{planned?money(planned.investment):"—"}</strong></div><div><span>{ui.expectedProfit}</span><strong className={planned?"profit":""}>{planned?`+${money(planned.profit)}`:"—"}</strong></div></div>
     {!planned&&<p className="drawerNote">{ui.notInPlan}</p>}
     <div className="opportunityFooter">
      {marketDetail&&<WatchlistButton source="SOL_OPTIMIZER" type="FLIP" itemId={selected.itemId} name={selected.name} route={selected.route} buyCity={marketDetail.buyCity} sellCity={marketDetail.sellCity} quality={marketDetail.quality} investment={planned?.investment??marketDetail.recommendedInvestment??marketDetail.buyPrice} profit={planned?.profit??marketDetail.recommendedProfit??marketDetail.profit} roi={marketDetail.roi} dataAgeMin={Math.max(marketDetail.buyAgeMin,marketDetail.sellAgeMin)} buyPrice={marketDetail.buyPrice} sellPrice={marketDetail.sellPrice} intelligenceScore={marketDetail.intelligenceScore} entryAdvantagePct={marketDetail.entryAdvantagePct} trendPct={marketDetail.trendPct} marketCondition={marketDetail.marketCondition} volatilityPct={marketDetail.volatilityPct} liquidity={marketDetail.liquidity} risk={marketDetail.risk} avgDailyVolume={marketDetail.avgDailyVolume} buyHistoryAvgPrice={marketDetail.buyHistoryAvgPrice}/>}
      <AddToPortfolioButton type="FLIP" itemId={selected.itemId} name={selected.name} route={selected.route} qty={qty} investment={totalInvestment} expectedProfit={totalProfit}/>
     </div>
     <p className="drawerNote">{ui.marketNote}</p>
    </>;
   }
   const roiNoFocus=selected.unitInvestmentNoFocus?((selected.unitProfitNoFocus??0)/selected.unitInvestmentNoFocus*100):selected.roi;
   const roiFocus=selected.unitInvestmentFocus?((selected.unitProfitFocus??0)/selected.unitInvestmentFocus*100):selected.roi;
   const rec=selected.type==="CRAFT"
    ?craftRecommendation({roi:selected.roi,profit:selected.unitProfit??selected.profit,score:selected.score,dataAgeMin:selected.dataAgeMin??999,focus:!!selected.focusMode,daily:selected.daily??0,rrr:selected.rrr??0},lang)
    :refineRecommendation({roi:selected.roi,profit:selected.unitProfit??selected.profit,score:selected.score,risk:selected.risk,dataAgeMin:selected.dataAgeMin??999,useFocus:!!selected.focusMode,roiNoFocus,roiFocus},lang);
   const actionQty=planned?.qty??1;
   return <>
    <div className="detailHead"><img src={itemImageUrl(selected.itemId,{size:128})} alt=""/><div><div className="eyebrow">{ui.detail}</div><h2>{selected.name}</h2><p>{selected.route}</p></div></div>
    <div className="detailGrid"><div><span>{ui.unitCost}</span><strong>{money(selected.unitInvestment??selected.investment)}</strong></div><div><span>{ui.unitProfit}</span><strong className="profit">+{money(selected.unitProfit??selected.profit)}</strong></div><div><span>{ui.return}</span><strong>{selected.roi.toFixed(1)}%</strong></div><div><span>{ui.risk}</span><strong>{lang==="en"?({Baixo:"Low",Médio:"Medium",Alto:"High"}[selected.risk]??selected.risk):selected.risk}</strong></div><div><span>{ui.decisionScore}</span><strong>{selected.decisionScore??selected.score}/100</strong></div><div><span>{ui.data}</span><strong>{selected.dataAgeMin!=null?ageText(selected.dataAgeMin):"—"}</strong></div></div>
    <section className={`solRecommendation ${rec.tone}`}><div className="solRecommendationTop"><span>{lang==="en"?"☀️ SOL RECOMMENDS":"☀️ SOL RECOMENDA"}</span><strong>{rec.label}</strong></div><h3>{rec.headline}</h3><p>{rec.reason}</p><b>{rec.action}</b></section>
    <div className="recommend optimizerAllocation"><div><span>{ui.allocation}</span><strong>{planned?ui.selected:ui.notSelected}</strong></div><div><span>{ui.qty}</span><strong>{planned?planned.qty:"—"} {planned?ui.units:""}</strong></div><div><span>{ui.investment}</span><strong>{planned?money(planned.investment):"—"}</strong></div><div><span>{ui.expectedProfit}</span><strong className={planned?"profit":""}>{planned?`+${money(planned.profit)}`:"—"}</strong></div></div>
    {!planned&&<p className="drawerNote">{ui.notInPlan}</p>}
    <div className="opportunityBreakdown"><div><span>{ui.rrr}</span><b>{selected.rrr!=null?`${(selected.rrr*100).toFixed(1)}%`:"—"}</b></div><div><span>{ui.daily}</span><b>{selected.daily?`+${selected.daily}%`:"—"}</b></div><div><span>{ui.focus}</span><b>{selected.focusMode?(planned?.focusUsed??selected.focusPerCraft??0):"—"}</b></div><div><span>{lang==="en"?"Output / action":"Produção / ação"}</span><b>{selected.outputPerCraft??1}</b></div></div>
    {selected.shopping&&<div className="opportunityMaterials"><h3>{ui.shopping}</h3>{Object.entries(selected.shopping).map(([city,mats])=><div className="materialCity" key={city}><strong>{city}</strong>{mats.map(m=><div className="materialLine" key={`${city}-${m.id}`}><span>{m.qty*actionQty}× {m.name}</span><b>{money(m.unitPrice)} {ui.perUnit}</b></div>)}</div>)}</div>}
    <div className="opportunityFooter">
     <WatchlistButton source="SOL_OPTIMIZER" type={selected.type} itemId={selected.itemId} name={selected.name} route={selected.route} craftCity={selected.type==="CRAFT"?selected.route.split(" | ").find(x=>x.startsWith("Craft: ")||x.startsWith("Craftar: "))?.replace(/^Craft(?:ar)?: /,""):undefined} refineCity={selected.type==="REFINE"?selected.route.split(" | ").find(x=>x.startsWith("Refine: ")||x.startsWith("Refinar: "))?.replace(/^Refin(?:e|ar): /,""):undefined} investment={totalInvestment} profit={totalProfit} roi={selected.roi} dataAgeMin={selected.dataAgeMin}/>
     <AddToPortfolioButton type={selected.type} itemId={selected.itemId} name={selected.name} route={selected.route} qty={qty} investment={totalInvestment} expectedProfit={totalProfit} focusUsed={planned?.focusUsed??0}/>
    </div>
    <p className="drawerNote">{ui.productionNote}</p>
   </>;
  })()}
 </aside></div>}
 <footer>by Fate and Ryukk • NoTag Exclusive • 2026 • {lang==="en"?"Not affiliated with Sandbox Interactive.":"Não afiliado à Sandbox Interactive."}</footer></main>
}